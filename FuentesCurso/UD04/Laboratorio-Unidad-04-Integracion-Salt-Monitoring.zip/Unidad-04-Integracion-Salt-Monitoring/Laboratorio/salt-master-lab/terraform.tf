# Terraform Configuration - UD04 Salt + Monitoring Lab
# Despliega la infraestructura necesaria para la Unidad 04: Integración de Salt con Monitorización.
# Este entorno utiliza Docker como proveedor de infraestructura para simular un clúster de servidores.

terraform {
  required_providers {
    docker = {
      source  = "kreuzwerker/docker"
      version = "~> 3.0"
    }
  }
}

provider "docker" {}

# =============================================================================
# RED VIRTUAL (NETWORK)
# Define una red bridge aislada para que los contenedores se comuniquen entre sí.
# El rango 172.28.0.0/24 se ha elegido para evitar conflictos con otras redes locales.
# Las IPs .40+ corresponden a la Unidad 4.
# =============================================================================
resource "docker_network" "internal_net" {
  name   = "devops_lab_net_ud04"
  driver = "bridge"

  ipam_config {
    subnet  = "172.28.0.0/24"
    gateway = "172.28.0.1"
  }

  options = {
    "com.docker.network.bridge.name" = "LabCEFIRE"
  }
}

# =============================================================================
# VOLÚMENES PERSISTENTES
# Permiten que los datos de configuración y bases de datos sobrevivan al reinicio de los contenedores.
# =============================================================================
resource "docker_volume" "salt_master_data" { name = "ud04_salt_master_data" }
resource "docker_volume" "prometheus_data"  { name = "ud04_prometheus_data" }
resource "docker_volume" "grafana_data"     { name = "ud04_grafana_data" }

# =============================================================================
# VM MASTER: Nodo Central (Salt Master + Prometheus + Grafana)
# Este contenedor actúa como el "cerebro" del laboratorio, gestionando la 
# configuración (Salt) y recolectando/visualizando métricas (Prometheus/Grafana).
# =============================================================================
resource "docker_container" "vm_master" {
  name     = "vm-master"
  image    = "ubuntu:24.04"
  memory   = 2048
  hostname = "master.lab.local"
  init     = true # Necesario para que systemd o procesos zombies se gestionen bien

  networks_advanced {
    name         = docker_network.internal_net.name
    ipv4_address = "172.28.0.40" # IP fija para el Master (Unidad 4 -> .40)
  }

  dns = ["8.8.8.8", "8.8.4.4"]

  capabilities { add = ["NET_ADMIN", "SYS_ADMIN"] }

  # Montaje de volúmenes para persistencia de datos y acceso a scripts locales
  volumes {
    volume_name    = docker_volume.salt_master_data.name
    container_path = "/etc/salt"
  }
  volumes {
    volume_name    = docker_volume.prometheus_data.name
    container_path = "/var/lib/prometheus"
  }
  volumes {
    volume_name    = docker_volume.grafana_data.name
    container_path = "/var/lib/grafana"
  }
  volumes {
    host_path      = "${path.cwd}/../scripts-laboratorio"
    container_path = "/opt/scripts"
  }

  # Subida de archivos de configuración inicial para Prometheus
  upload {
    source = "${path.cwd}/../monitoring-lab/prometheus.yml"
    file   = "/etc/prometheus/prometheus.yml"
  }
  upload {
    source = "${path.cwd}/../monitoring-lab/alerts.yml"
    file   = "/etc/prometheus/alerts.yml"
  }

  command = ["tail", "-f", "/dev/null"]
}

# =============================================================================
# VM MINION 1: Primer Servidor Gestionado (Salt Minion + Node Exporter)
# =============================================================================
resource "docker_container" "vm_minion_1" {
  name     = "vm-minion-1"
  image    = "ubuntu:24.04"
  memory   = 1024
  hostname = "minion-1.lab.local"
  init     = true

  networks_advanced {
    name         = docker_network.internal_net.name
    ipv4_address = "172.28.0.43" # IP fija para el Minion 1
  }

  dns = ["8.8.8.8", "8.8.4.4"]
  env = ["SALT_MASTER=172.28.0.40"] # Variable de entorno para que el minion sepa dónde está el master

  volumes {
    host_path      = "${path.cwd}/../scripts-laboratorio"
    container_path = "/opt/scripts"
  }

  command = ["tail", "-f", "/dev/null"]
}

# =============================================================================
# VM MINION 2: Segundo Servidor Gestionado (Salt Minion + Node Exporter)
# =============================================================================
resource "docker_container" "vm_minion_2" {
  name     = "vm-minion-2"
  image    = "ubuntu:24.04"
  memory   = 1024
  hostname = "minion-2.lab.local"
  init     = true

  networks_advanced {
    name         = docker_network.internal_net.name
    ipv4_address = "172.28.0.44" # IP fija para el Minion 2
  }

  dns = ["8.8.8.8", "8.8.4.4"]
  env = ["SALT_MASTER=172.28.0.40"]

  volumes {
    host_path      = "${path.cwd}/../scripts-laboratorio"
    container_path = "/opt/scripts"
  }

  command = ["tail", "-f", "/dev/null"]
}

# =============================================================================
# cADVISOR: Monitorización de métricas de contenedores Docker
# Analiza el uso de CPU, memoria y red de todos los contenedores en tiempo real.
# =============================================================================
resource "docker_container" "cadvisor" {
  name     = "cadvisor"
  image    = "gcr.io/cadvisor/cadvisor:latest"
  memory   = 512
  hostname = "cadvisor"
  init     = true

  networks_advanced {
    name         = docker_network.internal_net.name
    ipv4_address = "172.28.0.41" # IP fija para cAdvisor (Unidad 4)
  }

  # Montaje de sockets y sistemas de archivos del host para que cadvisor pueda leer las métricas de Docker
  volumes {
    host_path      = "/var/run/docker.sock"
    container_path = "/var/run/docker.sock"
  }
  volumes {
    host_path      = "/sys"
    container_path = "/sys"
  }
  volumes {
    host_path      = "/var/lib/docker"
    container_path = "/var/lib/docker"
  }
  volumes {
    host_path      = "/dev/disk"
    container_path = "/dev/disk"
  }

  command = ["-housekeeping_interval=10s", "-docker_only=true"]
}

# =============================================================================
# BLACKBOX EXPORTER: Monitorización de red y disponibilidad de servicios.
# Permite realizar sondas ICMP (ping), HTTP, TCP, etc., desde "fuera" del nodo.
# =============================================================================
resource "docker_container" "blackbox_exporter" {
  name     = "blackbox-exporter"
  image    = "prom/blackbox-exporter:latest"
  memory   = 256
  hostname = "blackbox-exporter"
  init     = true

  networks_advanced {
    name         = docker_network.internal_net.name
    ipv4_address = "172.28.0.42" # IP fija para Blackbox (Unidad 4)
  }

  volumes {
    host_path      = "${path.cwd}/../monitoring-lab/blackbox-config.yml"
    container_path = "/etc/blackbox_exporter/config.yml"
  }

  command = ["--config.file=/etc/blackbox_exporter/config.yml", "--web.listen-address=:9115"]
}

# =============================================================================
# OUTPUTS
# Estos valores se mostrarán al terminar 'terraform apply' para facilitar el acceso.
# =============================================================================
output "master_url"     { value = "http://172.28.0.40" }
output "prometheus_url" { value = "http://172.28.0.40:9090" }
output "grafana_url"    { value = "http://172.28.0.40:3000" }
output "cadvisor_url"   { value = "http://172.28.0.41:8080" }
output "blackbox_url"   { value = "http://172.28.0.42:9115" }

