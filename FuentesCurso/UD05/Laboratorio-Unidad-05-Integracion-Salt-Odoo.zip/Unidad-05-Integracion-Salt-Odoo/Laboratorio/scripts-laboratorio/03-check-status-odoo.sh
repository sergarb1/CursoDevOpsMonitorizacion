#!/bin/bash
# 03-check-status-odoo.sh - Verifica el estado de todos los servicios (v2)
set -e

RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
CYAN='\033[0;36m'
NC='\033[0m'

progress_bar() {
    local duration=$1
    local message=$2
    local width=40
    local elapsed=0
    echo -ne "${CYAN}${message} ${NC}["
    while [ $elapsed -lt $duration ]; do
        local percent=$((elapsed * 100 / duration))
        local filled=$((percent * width / 100))
        local empty=$((width - filled))
        printf "\r${CYAN}${message} ${NC}["
        printf "${GREEN}%${filled}s${NC}" | tr ' ' '#'
        printf "${YELLOW}%${empty}s${NC}" | tr ' ' '.'
        printf "] ${GREEN}%3d%%${NC}" $percent
        sleep 1
        elapsed=$((elapsed + 1))
    done
    printf "\r${CYAN}${message} ${NC}["
    printf "${GREEN}%${width}s${NC}" | tr ' ' '#'
    printf "] ${GREEN}100%%${NC}\n"
}

check_service_with_retry() {
    local name=$1
    local url=$2
    local wait_time=$3
    local max_attempts=4
    local attempt=1
    echo -n "  $name: "
    while [ $attempt -le $max_attempts ]; do
        local http_code=$(curl -s -o /dev/null -w "%{http_code}" "$url" 2>/dev/null)
        if [[ "$http_code" =~ ^(200|301|302|303|401|403|404|500|503)$ ]]; then
            echo -e "\r  ${GREEN}✓${NC} $name: $url (HTTP $http_code)                    "
            return 0
        fi
        if [ $attempt -eq 1 ]; then
            echo ""; progress_bar $wait_time "  ⏳ Esperando $name (intento $attempt/$max_attempts)"
        else
            progress_bar $wait_time "  🔄 Reintentando $name (intento $attempt/$max_attempts)"
        fi
        attempt=$((attempt + 1))
    done
    echo -e "\r  ${YELLOW}⏳${NC} $name: $url (iniciando)      "
    return 1
}

check_loki() {
    local max_retries=4
    local retry=0
    while [ $retry -lt $max_retries ]; do
        local http_code=$(curl -s -o /dev/null -w "%{http_code}" "http://172.28.0.54:3100/" 2>/dev/null)
        if [[ "$http_code" =~ ^(200|302|303|404)$ ]]; then
            return 0
        fi
        http_code=$(curl -s -o /dev/null -w "%{http_code}" "http://172.28.0.54:3100/ready" 2>/dev/null)
        if [[ "$http_code" = "200" ]]; then
            return 0
        fi
        if curl -s --connect-timeout 3 "http://172.28.0.54:3100/" >/dev/null 2>&1; then
            return 0
        fi
        sleep 3
        retry=$((retry + 1))
    done
    return 1
}

check_cadvisor() {
    local max_retries=4
    local retry=0
    while [ $retry -lt $max_retries ]; do
        if curl -s -f -L "http://172.28.0.52:8080/" >/dev/null 2>&1; then return 0; fi
        if curl -s -f -L "http://172.28.0.52:8080/containers/" >/dev/null 2>&1; then return 0; fi
        if curl -s -f "http://172.28.0.52:8080/metrics" >/dev/null 2>&1; then return 0; fi
        sleep 2
        retry=$((retry + 1))
    done
    return 1
}

check_postgres() {
    local container=$1
    local max_retries=4
    local retry=0
    while [ $retry -lt $max_retries ]; do
        if docker exec "$container" pg_isready -U odoo >/dev/null 2>&1; then return 0; fi
        sleep 2
        retry=$((retry + 1))
    done
    return 1
}

check_salt_master() {
    local max_retries=4
    local retry=0
    while [ $retry -lt $max_retries ]; do
        if docker exec ud05-salt-master pgrep -x "salt-master" >/dev/null 2>&1; then return 0; fi
        if docker exec ud05-salt-master pgrep -x -u salt "salt-master" >/dev/null 2>&1; then return 0; fi
        if docker exec ud05-salt-master ps aux | grep -q "[s]alt-master"; then return 0; fi
        if docker exec ud05-salt-master systemctl is-active salt-master >/dev/null 2>&1; then return 0; fi
        sleep 3
        retry=$((retry + 1))
    done
    return 1
}

check_prometheus() {
    local max_retries=4
    local retry=0
    while [ $retry -lt $max_retries ]; do
        local http_code=$(curl -s -o /dev/null -w "%{http_code}" "http://172.28.0.51:9090/" 2>/dev/null)
        if [[ "$http_code" = "200" ]]; then
            return 0
        fi
        http_code=$(curl -s -o /dev/null -w "%{http_code}" "http://172.28.0.51:9090/-/healthy" 2>/dev/null)
        if [[ "$http_code" = "200" ]]; then
            return 0
        fi
        sleep 2
        retry=$((retry + 1))
    done
    return 1
}

check_blackbox() {
    local max_retries=4
    local retry=0
    while [ $retry -lt $max_retries ]; do
        local http_code=$(curl -s -o /dev/null -w "%{http_code}" "http://172.28.0.53:9115/" 2>/dev/null)
        if [[ "$http_code" =~ ^(200|302)$ ]]; then return 0; fi
        http_code=$(curl -s -o /dev/null -w "%{http_code}" "http://172.28.0.53:9115/metrics" 2>/dev/null)
        if [[ "$http_code" = "200" ]]; then return 0; fi
        sleep 2
        retry=$((retry + 1))
    done
    return 1
}

# Verifica si un contenedor tiene realmente el salt-minion
has_salt_minion() {
    local container=$1
    # Comprobar si el binario salt-minion existe o el fichero de configuración
    if docker exec "$container" test -f /usr/bin/salt-minion 2>/dev/null; then
        return 0
    elif docker exec "$container" test -f /etc/salt/minion 2>/dev/null; then
        return 0
    else
        return 1
    fi
}

echo -e "${BLUE}════════════════════════════════════════════════════════════════${NC}"
echo -e "${BLUE}              ESTADO DE LA INFRAESTRUCTURA                       ${NC}"
echo -e "${BLUE}════════════════════════════════════════════════════════════════${NC}"
echo ""

echo -e "${BLUE}📦 Contenedores:${NC}"
containers=(
    "ud05-salt-master"
    "odoo-pg1" "odoo-pg2"
    "odoo-minion-1" "odoo-minion-2"
    "odoo-prometheus" "odoo-grafana"
    "odoo-loki" "odoo-alloy"
    "odoo-cadvisor" "odoo-blackbox"
)
for container in "${containers[@]}"; do
    if docker ps --format '{{.Names}}' | grep -q "^${container}$"; then
        echo -e "  ${GREEN}✓${NC} $container"
    else
        echo -e "  ${RED}✗${NC} $container"
    fi
done

echo ""
echo -e "${BLUE}🌐 Servicios Web:${NC}"

check_service_with_retry "Odoo 1" "http://172.28.0.57:8069" 15
check_service_with_retry "Odoo 2" "http://172.28.0.58:8069" 15
check_service_with_retry "Grafana" "http://172.28.0.56:3000" 10

echo -n "  Prometheus: "
if check_prometheus; then
    echo -e "\r  ${GREEN}✓${NC} Prometheus: http://172.28.0.51:9090                         "
else
    echo -e "\r  ${YELLOW}⏳${NC} Prometheus: http://172.28.0.51:9090 (iniciando)            "
fi

echo -n "  Loki: "
if check_loki; then
    echo -e "\r  ${GREEN}✓${NC} Loki: http://172.28.0.54:3100 (listo)                       "
else
    echo -e "\r  ${YELLOW}⏳${NC} Loki: http://172.28.0.54:3100 (iniciando)                  "
fi

echo -n "  Blackbox: "
if check_blackbox; then
    echo -e "\r  ${GREEN}✓${NC} Blackbox: http://172.28.0.53:9115                          "
else
    echo -e "\r  ${YELLOW}⏳${NC} Blackbox: http://172.28.0.53:9115 (iniciando)             "
fi

echo -n "  cAdvisor: "
if check_cadvisor; then
    echo -e "\r  ${GREEN}✓${NC} cAdvisor: http://172.28.0.52:8080                          "
else
    echo -e "\r  ${YELLOW}⏳${NC} cAdvisor: http://172.28.0.52:8080 (iniciando)             "
fi

echo ""
echo -e "${BLUE}🔧 Salt Stack:${NC}"

if check_salt_master; then
    echo -e "  ${GREEN}✓${NC} Salt Master está ejecutándose en ud05-salt-master"
    
    echo -e "  ${CYAN}→${NC} Estado de Minions:"
    docker exec ud05-salt-master salt-key --list-all 2>/dev/null || echo "    No se pudieron listar los minions"
    
    # Contar minions aceptados (excluyendo "salt-master")
    accepted=$(docker exec ud05-salt-master salt-key --list acc 2>/dev/null | grep -E '^[a-z]' | grep -v 'salt-master' | wc -l)
    pending=$(docker exec ud05-salt-master salt-key --list un 2>/dev/null | grep -E '^[a-z]' | wc -l)
    
    echo ""
    echo -e "  ${GREEN}✓${NC} Minions aceptados: ${accepted}"
    if [ "$pending" -gt 0 ] 2>/dev/null; then
        echo -e "  ${YELLOW}⏳${NC} Minions pendientes: ${pending}"
    fi
    
    # Verificar conectividad solo si hay minions aceptados
    if [ "$accepted" -gt 0 ] 2>/dev/null; then
        echo -e "  ${CYAN}→${NC} Verificando conectividad:"
        # Parsear salida "minion: True"
        while IFS= read -r line; do
            # Saltarse líneas vacías o que no tengan ": True"
            if [[ "$line" =~ ^[[:space:]]*([^:]+):[[:space:]]*True ]]; then
                minion="${BASH_REMATCH[1]}"
                # Eliminar espacios adicionales
                minion=$(echo "$minion" | xargs)
                echo -e "    ${GREEN}✓${NC} $minion: Conectado"
            fi
        done < <(docker exec ud05-salt-master salt '*' test.ping 2>/dev/null)
    fi
else
    echo -e "  ${RED}✗${NC} Salt Master no está ejecutándose"
    echo -e "  ${YELLOW}→${NC} Verifica con: docker logs ud05-salt-master --tail 20"
fi

# Buscar salt-minions reales (solo contenedores con el binario/configuración)
echo ""
echo -e "${BLUE}🔍 Salt Minions en contenedores:${NC}"

salt_minions_found=false
for container in $(docker ps --format '{{.Names}}'); do
    if has_salt_minion "$container"; then
        salt_minions_found=true
        echo -e "  ${GREEN}✓${NC} $container: Salt Minion instalado"
        
        # Obtener el minion_id de manera fiable
        if docker exec "$container" test -f /etc/salt/minion_id 2>/dev/null; then
            minion_id=$(docker exec "$container" cat /etc/salt/minion_id 2>/dev/null)
        else
            minion_id=$(docker exec "$container" hostname 2>/dev/null)
        fi
        echo -e "    ${CYAN}→${NC} Minion ID: ${minion_id:-desconocido}"
        
        # Master al que se conecta (solo si salt-call existe)
        if docker exec "$container" test -f /usr/bin/salt-call 2>/dev/null; then
            master=$(docker exec "$container" salt-call --local grains.get master 2>/dev/null | grep -v "^$" | tail -1 | xargs)
            echo -e "    ${CYAN}→${NC} Conectado a master: ${master:-desconocido}"
        fi
    fi
done

if [ "$salt_minions_found" = false ]; then
    echo -e "  ${YELLOW}⏳${NC} No se encontraron contenedores con Salt Minion instalado"
    echo -e "  ${CYAN}→${NC} Las claves aceptadas indican que los minions deberían estar en odoo-minion-1/2"
fi

echo ""
echo -e "${BLUE}🐘 PostgreSQL:${NC}"
if check_postgres odoo-pg1; then echo -e "  ${GREEN}✓${NC} PostgreSQL 1 está listo"; else echo -e "  ${RED}✗${NC} PostgreSQL 1 no responde"; fi
if check_postgres odoo-pg2; then echo -e "  ${GREEN}✓${NC} PostgreSQL 2 está listo"; else echo -e "  ${RED}✗${NC} PostgreSQL 2 no responde"; fi

echo ""
echo -e "${BLUE}📊 Exporters y Servicios en Odoo Minions:${NC}"
for instance in odoo-minion-1 odoo-minion-2; do
    echo -e "  ${CYAN}→${NC} $instance:"
    
    if docker exec "$instance" pgrep -x "node_exporter" >/dev/null 2>&1; then
        echo -e "    ${GREEN}✓${NC} Node Exporter activo"
    else
        echo -e "    ${YELLOW}⏳${NC} Node Exporter no detectado"
    fi
    
    if docker exec "$instance" pgrep -f "odoo-exporter.py" >/dev/null 2>&1; then
        echo -e "    ${GREEN}✓${NC} Odoo Exporter activo"
    else
        echo -e "    ${YELLOW}⏳${NC} Odoo Exporter no detectado"
    fi
    
    if docker exec "$instance" pgrep -f "odoo-bin\|odoo.py" >/dev/null 2>&1; then
        echo -e "    ${GREEN}✓${NC} Odoo proceso activo"
    fi
done

echo ""
echo -e "${YELLOW}📝 Notas:${NC}"
echo -e "   • Si los Salt Minions no aparecen como proceso, revisa su instalación en los contenedores Odoo"
echo -e "   • Para aceptar minions pendientes: docker exec ud05-salt-master salt-key -A -y"
echo -e "   • Para probar conectividad: docker exec ud05-salt-master salt '*' test.ping"
echo -e "   • Logs Odoo 1: docker logs -f odoo-minion-1"
echo -e "   • Logs Odoo 2: docker logs -f odoo-minion-2"
echo -e "   • Logs Salt Master: docker logs -f ud05-salt-master"
echo -e "   • Logs Loki: docker logs -f odoo-loki"
echo -e "   • Loki puede devolver HTTP 404 en / pero estar funcionando correctamente"
echo ""
echo -e "${GREEN}════════════════════════════════════════════════════════════════${NC}"