#!/bin/bash
# 05-salt-minion-debian.sh - Instalación de Salt Minion para Debian 12
# Este script permite integrar nodos Debian en el sistema de gestión SaltStack.

set -euo pipefail

echo "--- [SALT-MINION-DEBIAN] Instalando Salt Minion (Debian 12) ---"

# Configuración del repositorio oficial de Salt Project
mkdir -m 755 -p /etc/apt/keyrings
curl -fsSL https://packages.broadcom.com/artifactory/api/security/keypair/SaltProjectKey/public | gpg --dearmor | tee /etc/apt/keyrings/salt-archive-keyring.pgp > /dev/null
curl -fsSL https://github.com/saltstack/salt-install-guide/releases/latest/download/salt.sources | tee /etc/apt/sources.list.d/salt.sources

apt-get update 

# Instalación del servicio Salt Minion
apt-get install -y  salt-minion

# Apuntar al Master centralizado (IP actualizada a .40)
# Esto crea la relación de confianza entre el agente y el servidor.
echo "master: ${SALT_MASTER:-172.28.0.40}" > /etc/salt/minion

# Arranque manual en caso de que el entorno sea un contenedor sin systemd
if ! pgrep salt-minion > /dev/null; then
    echo "Iniciando Salt Minion en modo demonio..."
    nohup /usr/bin/salt-minion -d > /var/log/salt-minion.log 2>&1 &
fi

echo "✅ Salt Minion (Debian) preparado para conectar con ${SALT_MASTER:-172.28.0.40}."
