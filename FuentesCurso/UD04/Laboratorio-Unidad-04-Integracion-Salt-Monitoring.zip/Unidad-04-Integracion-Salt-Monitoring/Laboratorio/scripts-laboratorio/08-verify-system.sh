#!/bin/bash
# 08-verify-system.sh - Verifica la salud y conectividad de todo el laboratorio UD04.
# Este script actúa como una "Suite de Pruebas" automatizada para confirmar que
# la integración entre SaltStack y el stack de monitorización es correcta.

set -euo pipefail

# Colores y Formato
RED='\033[0;31m'; GREEN='\033[0;32m'; YELLOW='\033[1;33m'; BLUE='\033[0;34m'; NC='\033[0m'
ok()   { echo -e "${GREEN}  ✓${NC} $1"; }
fail() { echo -e "${RED}  ✗${NC} $1"; }
warn() { echo -e "${YELLOW}  ⚠${NC} $1"; }

echo -e "${BLUE}╔═══════════════════════════════════════════════════════╗${NC}"
echo -e "${BLUE}║     UD04 - Verificación Integral del Sistema          ║${NC}"
echo -e "${BLUE}║     (Chequeo de Salud y Conectividad .40+)            ║${NC}"
echo -e "${BLUE}╚═══════════════════════════════════════════════════════╝${NC}"

# 1. Containers - Comprueba que los contenedores Docker están en estado 'running'
echo ""
echo -e "${BLUE}[TEST]${NC} 1. Disponibilidad de Contenedores:"
for c in vm-master vm-minion-1 vm-minion-2 cadvisor blackbox-exporter; do
    if docker inspect "$c" --format='{{.State.Running}}' 2>/dev/null | grep -q "true"; then
        ok "Nodo $c: En ejecución (UP)"
    else
        fail "Nodo $c: Detenido o no existe (DOWN)"
    fi
done

# 2. Network - Verifica la conectividad y asignación de IPs en la red bridge
echo ""
echo -e "${BLUE}[TEST]${NC} 2. Direccionamiento de Red (Rango .40+):"
if docker network inspect devops_lab_net_ud04 >/dev/null 2>&1; then
    docker network inspect devops_lab_net_ud04 --format '{{range .Containers}}{{.Name}}: {{.IPv4Address}}{{"\n"}}{{end}}' 2>/dev/null | while read line; do
        ok "IP Asignada -> $line"
    done
else
    fail "Red virtual 'devops_lab_net_ud04' no detectada."
fi

# 3. SaltStack - Verifica el túnel de control entre Master y Minions
echo ""
echo -e "${BLUE}[TEST]${NC} 3. Orquestación con SaltStack:"
if docker exec vm-master pgrep -f '/usr/bin/salt-master' > /dev/null 2>/dev/null; then
    ok "Salt Master: Proceso activo y gestionando llaves."
else
    fail "Salt Master: El proceso no está respondiendo."
fi

# Realiza un 'ping' de Salt (capa de aplicación)
salt_ping=$(docker exec vm-master salt '*' test.ping 2>/dev/null | grep -c "True" || echo "0")
if [ "$salt_ping" -ge 2 ]; then
    ok "Comunicación Salt: $salt_ping minions autenticados y respondiendo."
else
    warn "Comunicación Salt: Solo $salt_ping minions activos. ¿Aceptaste las llaves?"
fi

# 4. Prometheus - Comprueba el servidor de métricas
echo ""
echo -e "${BLUE}[TEST]${NC} 4. Salud de Prometheus Server:"
if docker exec vm-master bash -c 'curl -s http://localhost:9090/-/healthy > /dev/null 2>&1' 2>/dev/null; then
    ok "Prometheus: Saludable en http://172.28.0.40:9090"
else
    fail "Prometheus: No responde al chequeo de salud (API /-/healthy)."
fi

# 5. Grafana - Verifica la interfaz de usuario
echo ""
echo -e "${BLUE}[TEST]${NC} 5. Estado de la Interfaz Grafana:"
if docker exec vm-master bash -c 'curl -s http://localhost:3000/api/health 2>/dev/null | grep -q commit' 2>/dev/null; then
    ok "Grafana: Listo para visualización en http://172.28.0.40:3000"
else
    warn "Grafana: Todavía inicializando servicios... reintenta en unos segundos."
fi

# 6. Node Exporters - Verifica los agentes en los nodos
echo ""
echo -e "${BLUE}[TEST]${NC} 6. Agentes de Métricas (Node Exporters):"
for ip in 172.28.0.40 172.28.0.43 172.28.0.44; do
    if curl -s --connect-timeout 2 "http://$ip:9100/metrics" > /dev/null; then
        ok "Exportador en $ip: EXPONIENDO MÉTRICAS (Puerto 9100)"
    else
        fail "Exportador en $ip: NO RESPONDE"
    fi
done

# 7. cAdvisor y Blackbox - Monitorización avanzada
echo ""
echo -e "${BLUE}[TEST]${NC} 7. Monitorización de Contenedores y Red:"
if curl -s --connect-timeout 3 "http://172.28.0.41:8080/metrics" > /dev/null; then
    ok "cAdvisor (Docker Metrics): Operativo en http://172.28.0.41:8080"
else
    fail "cAdvisor: No se puede obtener métricas de contenedores."
fi

if curl -s --connect-timeout 3 "http://172.28.0.42:9115/health" > /dev/null 2>&1; then
    ok "Blackbox Exporter (Network Probes): Activo en http://172.28.0.42:9115"
    
    # Test sonda ICMP
    if curl -s "http://172.28.0.42:9115/probe?target=172.28.0.40&module=icmp" 2>/dev/null | grep -q "probe_success 1"; then
        ok "Sonda ICMP: Blackbox -> Master (PING EXITOSO)"
    else
        warn "Sonda ICMP: Fallida. Revisa reglas de red o firewall."
    fi
else
    fail "Blackbox Exporter: Servicio no disponible."
fi

echo ""
echo -e "${BLUE}╔═══════════════════════════════════════════════════════╗${NC}"
echo -e "${BLUE}║     RESUMEN DE ACCESOS (Unidad 4 - IPs .40+)          ║${NC}"
echo -e "${BLUE}╠═══════════════════════════════════════════════════════╣${NC}"
echo -e "${BLUE}║${NC} Prometheus:  http://172.28.0.40:9090          ${BLUE}║${NC}"
echo -e "${BLUE}║${NC} Grafana:     http://172.28.0.40:3000          ${BLUE}║${NC}"
echo -e "${BLUE}║${NC} cAdvisor:    http://172.28.0.41:8080          ${BLUE}║${NC}"
echo -e "${BLUE}║${NC} Blackbox:    http://172.28.0.42:9115          ${BLUE}║${NC}"
echo -e "${BLUE}╚═══════════════════════════════════════════════════════╝${NC}"
echo ""
