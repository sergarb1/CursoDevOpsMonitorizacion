#!/bin/bash
# ======================================================================
# 🔧 configurar-equipos.sh - Configurar Golden Image después de desplegar
# Propósito: Asistente interactivo para personalizar la VM después de FOG
# ======================================================================

echo "╔═══════════════════════════════════════════════════════════╗"
echo "║  🔧 Personalización de Equipos - UD02 FOG PXE            ║"
echo "║     Configurar VM después de desplegar con FOG           ║"
echo "╚═══════════════════════════════════════════════════════════╝"
echo ""

# Información actual
echo "📋 CONFIGURACIÓN ACTUAL:"
echo "   ───────────────────────────────────────────────────────"
echo "   Hostname: $(hostname)"
echo "   IP actual: $(ip addr show eth1 2>/dev/null | grep 'inet ' | awk '{print $2}' | cut -d/ -f1 || echo 'No disponible')"
echo "   Usuario: $(whoami)"
echo ""

# Rango de IPs disponibles
echo "📊 RANGO DE IPs DISPONIBLES EN EL LABORATORIO:"
echo "   ───────────────────────────────────────────────────────"
echo "   172.28.0.1   → Gateway (LabCEFIRE en el host)"
echo "   172.28.0.30  → FOG-Server (RESERVADA - NO USAR)"
echo "   172.28.0.31  → Golden-VM (ORIGINAL - NO USAR)"
echo "   172.28.0.32  → Disponible para despliegues"
echo "   172.28.0.33  → Disponible para despliegues"
echo "   ...          → ..."
echo "   172.28.0.254 → Disponible"
echo ""

# Preguntar nuevo hostname
echo "🖥️  HOSTNAME:"
echo "   ───────────────────────────────────────────────────────"
echo "   Ejemplos: pc-aula1, pc-laboratorio2, dev-workstation01"
echo ""
read -p "💡 ¿Qué hostname quieres para este equipo? [$(hostname)]: " NEW_HOSTNAME
NEW_HOSTNAME=${NEW_HOSTNAME:-$(hostname)}

# Validar hostname
if [[ ! $NEW_HOSTNAME =~ ^[a-zA-Z0-9]([a-zA-Z0-9\-]{0,61}[a-zA-Z0-9])?$ ]]; then
    echo "❌ ERROR: Hostname no válido. Solo letras, números y guiones (máx 63 caracteres)."
    exit 1
fi

echo ""

# Preguntar IP
echo "🌐 DIRECCIÓN IP:"
echo "   ───────────────────────────────────────────────────────"
read -p "💡 ¿Qué IP fija quieres asignar? [172.28.0.31]: " IP_ADDRESS
IP_ADDRESS=${IP_ADDRESS:-172.28.0.31}

# Validar formato de IP
if [[ ! $IP_ADDRESS =~ ^172\.28\.0\.([1-9]|[1-9][0-9]|1[0-9][0-9]|2[0-4][0-9]|25[0-4])$ ]]; then
    echo "❌ ERROR: IP no válida. Debe estar en el rango 172.28.0.1 - 172.28.0.254"
    exit 1
fi

# Verificar si la IP ya está en uso
echo ""
echo "🔍 Verificando si la IP $IP_ADDRESS ya está en uso..."
if ping -c 1 -W 1 $IP_ADDRESS > /dev/null 2>&1; then
    echo "⚠️  ADVERTENCIA: La IP $IP_ADDRESS parece estar en uso."
    read -p "   ¿Quieres continuar de todas formas? [s/N]: " CONTINUE
    if [[ ! $CONTINUE =~ ^[Ss]$ ]]; then
        echo "❌ Operación cancelada."
        exit 0
    fi
fi

# Resumen de configuración
echo ""
echo "╔═══════════════════════════════════════════════════════════╗"
echo "║  📋 RESUMEN DE CONFIGURACIÓN                              ║"
echo "╠═══════════════════════════════════════════════════════════╣"
echo "║  Hostname actual:  $(hostname)"
echo "║  Hostname nuevo:   $NEW_HOSTNAME"
echo "║  IP actual:        $(ip addr show eth1 2>/dev/null | grep 'inet ' | awk '{print $2}' | cut -d/ -f1 || echo 'N/A')"
echo "║  IP nueva:         $IP_ADDRESS"
echo "║  Gateway:          172.28.0.1"
echo "║  DNS:              172.28.0.1, 8.8.8.8"
echo "╠═══════════════════════════════════════════════════════════╣"
read -p "║  ¿Confirmas los cambios? [s/N]: " CONFIRM | head -1
echo "╚═══════════════════════════════════════════════════════════╝"

if [[ ! $CONFIRM =~ ^[Ss]$ ]]; then
    echo "❌ Operación cancelada."
    exit 0
fi

# Aplicar cambios
echo ""
echo "⚙️  Aplicando configuración..."
echo "   ───────────────────────────────────────────────────────"

# 1. Cambiar hostname
echo "   🔄 Cambiando hostname..."
hostnamectl set-hostname "$NEW_HOSTNAME"
sed -i "s/127.0.1.1.*/127.0.1.1\t$NEW_HOSTNAME/" /etc/hosts 2>/dev/null || true
echo "      ✓ Hostname cambiado a: $NEW_HOSTNAME"

# 2. Configurar red
echo "   🔄 Configurando red..."
cat > /etc/NetworkManager/system-connections/eth1-static.nmconnection << EOF
[connection]
id=eth1-static
type=ethernet
interface-name=eth1

[ipv4]
address1=$IP_ADDRESS/24,172.28.0.1
dns=172.28.0.1;8.8.8.8;
method=manual

[ipv6]
method=ignore
EOF

chmod 600 /etc/NetworkManager/system-connections/eth1-static.nmconnection
nmcli connection reload
nmcli connection up eth1-static 2>/dev/null || true
echo "      ✓ Red configurada: $IP_ADDRESS"

# 3. Regenerar claves SSH (IMPORTANTE para que sea única)
echo "   🔄 Regenerando claves SSH..."
rm -f /etc/ssh/ssh_host_*
ssh-keygen -A > /dev/null 2>&1
systemctl restart sshd 2>/dev/null || true
echo "      ✓ Claves SSH regeneradas"

# 4. Cambiar contraseña del usuario admin (opcional)
echo ""
echo "🔐 SEGURIDAD:"
echo "   ───────────────────────────────────────────────────────"
read -p "   ¿Quieres cambiar la contraseña del usuario 'admin'? [s/N]: " CHANGE_PASS
if [[ $CHANGE_PASS =~ ^[Ss]$ ]]; then
    passwd admin
fi

# 5. Mostrar nueva configuración
echo ""
echo "╔═══════════════════════════════════════════════════════════╗"
echo "║  ✅ ¡Configuración completada!                            ║"
echo "╠═══════════════════════════════════════════════════════════╣"
echo "║  🖥️  HOSTNAME: $NEW_HOSTNAME"
echo "║  🌐 IP: $IP_ADDRESS"
echo "║  🚪 Gateway: 172.28.0.1"
echo "║  📡 DNS: 172.28.0.1, 8.8.8.8"
echo "╠═══════════════════════════════════════════════════════════╣"
echo "║  ⚠️  IMPORTANTE:                                          ║"
echo "║  • Reinicia para aplicar todos los cambios:               ║"
echo "║    sudo reboot                                            ║"
echo "║  • Después del reinicio, este equipo será único           ║"
echo "║  • Las claves SSH son nuevas (seguridad)                  ║"
echo "╚═══════════════════════════════════════════════════════════╝"

# Guardar log de configuración
LOG_FILE="/var/log/configuracion-equipos.log"
echo "[$(date '+%Y-%m-%d %H:%M:%S')] Hostname: $NEW_HOSTNAME, IP: $IP_ADDRESS, Usuario: $(whoami)" >> "$LOG_FILE"

echo ""
echo "📝 Configuración guardada en: $LOG_FILE"
