#!/bin/bash
# 05-custom-web.sh - Web personalizada
set -e
GREEN='\033[0;32m'; BLUE='\033[0;34m'; NC='\033[0m'

echo -e "${BLUE}[PROVISIÓN]${NC} Desplegando página web personalizada..."
IP_ADDR=$(hostname -I | cut -d' ' -f2)
cat <<EOF > /var/www/html/index.html
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Taller Vagrant Modular - CEFIRE</title>
    <style>
        body { font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; background-color: #e9ecef; text-align: center; padding: 50px; }
        .card { background: white; padding: 40px; border-radius: 15px; box-shadow: 0 4px 6px rgba(0,0,0,0.1); display: inline-block; border-top: 5px solid #0d6efd; }
        h1 { color: #212529; }
        .status { color: #198754; font-weight: bold; background: #d1e7dd; padding: 5px 10px; border-radius: 5px; }
    </style>
</head>
<body>
    <div class="card">
        <h1>🚀 Servidor Web - Unidad 02</h1>
        <p>Configuración realizada mediante <b>Infraestructura como Código (IaC)</b>.</p>
        <hr>
        <p>Hostname: <b>$(hostname)</b></p>
        <p>Dirección IP: <span class="status">$IP_ADDR</span></p>
    </div>
</body>
</html>
EOF
systemctl restart nginx > /dev/null
echo -e "${GREEN}✓${NC} Página web desplegada en http://$IP_ADDR"
