#!/bin/bash
# 98-destroy-infra.sh - Elimina la infraestructura de la UD04 usando Terraform.
# Didáctica: Usar Terraform para el 'destroy' asegura que el estado local (.tfstate)
# se mantenga sincronizado con la realidad de los recursos eliminados.

set -euo pipefail

# Colores y Formato
RED='\033[0;31m'; GREEN='\033[0;32m'; YELLOW='\033[1;33m'; BLUE='\033[0;34m'; NC='\033[0m'
log()  { echo -e "${BLUE}[DESTROY]${NC} $1"; }
ok()   { echo -e "${GREEN}[DESTROY] ✓${NC} $1"; }
warn() { echo -e "${YELLOW}[DESTROY] ⚠${NC} $1"; }

echo -e "${BLUE}╔═══════════════════════════════════════════════════════╗${NC}"
echo -e "${BLUE}║     UD04 - ELIMINACIÓN DE INFRAESTRUCTURA             ║${NC}"
echo -e "${BLUE}║     (Limpieza mediante Terraform + Docker)            ║${NC}"
echo -e "${BLUE}╚═══════════════════════════════════════════════════════╝${NC}"

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
TERRAFORM_DIR="$SCRIPT_DIR/../salt-master-lab"

# 1. Terraform Destroy: El método preferido y limpio
if [ -d "$TERRAFORM_DIR" ]; then
    log "Iniciando 'terraform destroy' para eliminar recursos..."
    cd "$TERRAFORM_DIR"
    if terraform destroy -auto-approve; then
        ok "Recursos eliminados por Terraform correctamente."
    else
        warn "Terraform falló o no encontró estado. Procediendo con limpieza manual de Docker."
    fi
fi

# 2. Docker Safety Clean: Por si Terraform dejó algo atrás o el estado se corrompió
echo ""
log "Limpieza de seguridad (Docker Force Remove)..."
for c in vm-master vm-minion-1 vm-minion-2 cadvisor blackbox-exporter; do
    if docker ps -a --format '{{.Names}}' | grep -q "^${c}$"; then
        docker rm -f "$c" &>/dev/null && ok "Eliminado por seguridad: $c" || true
    fi
done

# Eliminar red si aún existe
if docker network ls --format '{{.Name}}' | grep -q "^devops_lab_net_ud04$"; then
    docker network rm devops_lab_net_ud04 &>/dev/null && ok "Red eliminada manualmente" || true
fi

# Eliminar volúmenes si aún existen
for v in ud04_salt_master_data ud04_prometheus_data ud04_grafana_data; do
    if docker volume ls --format '{{.Name}}' | grep -q "^${v}$"; then
        docker volume rm "$v" &>/dev/null && ok "Volumen eliminado manualmente: $v" || true
    fi
done

# 3. Limpieza de archivos temporales de Terraform
log "Limpiando archivos de estado local..."
rm -rf .terraform .terraform.lock.hcl terraform.tfstate terraform.tfstate.backup 2>/dev/null || true

echo ""
echo -e "${GREEN}╔═══════════════════════════════════════════════════════╗${NC}"
echo -e "${GREEN}║     ✅ Limpieza de UD04 completada con éxito        ║${NC}"
echo -e "${GREEN}╚═══════════════════════════════════════════════════════╝${NC}"
echo ""
echo "IPs liberadas: 172.28.0.40, 172.28.0.41, 172.28.0.42, 172.28.0.43, 172.28.0.44"
echo "Nota: La interfaz LabCEFIRE en el host sigue activa. Usa 99-destroy-network.sh para borrarla."
echo ""
