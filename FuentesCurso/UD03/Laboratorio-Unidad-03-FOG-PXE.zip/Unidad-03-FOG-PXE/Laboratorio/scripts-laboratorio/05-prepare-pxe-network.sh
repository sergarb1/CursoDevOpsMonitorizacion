#!/bin/bash
# fix-golden-network-order.sh - Configura la VM para captura PXE
set -e

# Colores
RED='\033[0;31m'; GREEN='\033[0;32m'; BLUE='\033[0;34m'; YELLOW='\033[1;33m'; NC='\033[0m'

echo -e "${BLUE}╔═══════════════════════════════════════════════════════╗${NC}"
echo -e "${BLUE}║     UD03 - Preparación para Captura PXE            ║${NC}"
echo -e "${BLUE}╚═══════════════════════════════════════════════════════╝${NC}"

VM_NAME=$1
if [ -z "$VM_NAME" ]; then
    echo -e "${YELLOW}Uso: $0 <Nombre-de-la-VM-en-VirtualBox>${NC}"
    echo "Ejemplo: $0 Golden-VM-UD03"
    exit 1
fi

echo -e "${BLUE}[PXE]${NC} Configurando '$VM_NAME' para arranque por red..."

# 1. Apagar VM si está encendida
if VBoxManage showvminfo "$VM_NAME" --machinereadable | grep -q "VMState=\"running\""; then
    echo -e "${YELLOW}[PXE]${NC} Apagando VM..."
    VBoxManage controlvm "$VM_NAME" poweroff
    sleep 2
fi

# 2. Desactivar NIC1 (NAT)
echo -e "${BLUE}[PXE]${NC} Desactivando Adapter 1 (NAT)..."
VBoxManage modifyvm "$VM_NAME" --nic1 none

# 3. Asegurar NIC2 (Bridge) con booteo PXE
echo -e "${BLUE}[PXE]${NC} Configurando Adapter 2 (Bridge) como primario..."
VBoxManage modifyvm "$VM_NAME" --nic2 bridged --bridgeadapter2 LabCEFIRE --nicpromisc2 allow-all --cableconnected2 on

# 4. Cambiar orden de arranque
echo -e "${BLUE}[PXE]${NC} Estableciendo Red como primer dispositivo de arranque..."
VBoxManage modifyvm "$VM_NAME" --boot1 net --boot2 disk

echo -e "${GREEN}✓${NC} Proceso completado. Ya puedes iniciar la VM para capturar con FOG."
echo -e "${YELLOW}NOTA: Recuerda reactivar la NIC1 después de la captura para recuperar SSH.${NC}"
