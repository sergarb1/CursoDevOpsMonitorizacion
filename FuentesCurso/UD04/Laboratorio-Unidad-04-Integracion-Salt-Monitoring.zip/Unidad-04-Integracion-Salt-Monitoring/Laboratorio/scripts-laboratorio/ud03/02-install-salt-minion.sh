#!/bin/bash
# 02-install-salt-minion.sh - Instala Salt Minion en una VM Debian 12
# Este script automatiza el registro de una máquina como 'agente' en el sistema SaltStack.
# Uso: vagrant ssh <VM> -c "sudo bash /path/to/01-install-salt-minion.sh"
# O:   bash 01-install-salt-minion.sh <master-ip>

set -euo pipefail

# Parámetro 1: IP del Salt Master (por defecto .40 si no se indica)
SALT_MASTER="${1:-172.28.0.40}"
RED='\033[0;31m'; GREEN='\033[0;32m'; BLUE='\033[0;34m'; NC='\033[0m'
log()  { echo -e "${BLUE}[SALT]${NC} $1"; }
ok()   { echo -e "${GREEN}[SALT] ✓${NC} $1"; }

log "Instalando Salt Minion (master: $SALT_MASTER)..."

export DEBIAN_FRONTEND=noninteractive

# Comprobación de si ya está instalado para evitar redundancia
if command -v salt-minion &>/dev/null; then
    ok "Salt Minion ya se encuentra instalado en el sistema."
else
    # Configuración de repositorios oficiales
    apt-get update 
    apt-get install -y  curl gnupg > /dev/null 2>&1
    mkdir -m 755 -p /etc/apt/keyrings
    curl -fsSL https://packages.broadcom.com/artifactory/api/security/keypair/SaltProjectKey/public | gpg --dearmor | tee /etc/apt/keyrings/salt-archive-keyring.pgp > /dev/null
    curl -fsSL https://github.com/saltstack/salt-install-guide/releases/latest/download/salt.sources | tee /etc/apt/sources.list.d/salt.sources
    apt-get update 
    apt-get install -y  salt-minion > /dev/null 2>&1
    ok "Paquete salt-minion instalado correctamente."
fi

# Configuración del archivo de identidad del Minion
# El 'id' suele ser el hostname, lo que permite identificarlo fácilmente en el Master.
cat > /etc/salt/minion << EOF
master: $SALT_MASTER
id: $(hostname)
EOF

# Reinicio del servicio para aplicar los cambios de configuración
log "Reiniciando el servicio para conectar con el Master..."
systemctl daemon-reload 2>/dev/null || true
systemctl restart salt-minion 2>/dev/null || {
    # Fallback si no hay systemd (entornos de contenedor o VMs mínimas)
    pkill salt-minion 2>/dev/null || true
    sleep 1
    nohup /usr/bin/salt-minion -d > /var/log/salt-minion.log 2>&1 &
}

sleep 2
ok "Salt Minion configurado y en ejecución. Recuerda aceptar su llave en el Master."
