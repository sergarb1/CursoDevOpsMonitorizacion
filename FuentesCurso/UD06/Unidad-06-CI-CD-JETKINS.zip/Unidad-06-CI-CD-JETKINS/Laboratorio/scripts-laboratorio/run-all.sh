#!/bin/bash
# run-all.sh - Orquestador completo para UD06 (Refined)
set -euo pipefail

RED='\033[0;31m'; GREEN='\033[0;32m'; YELLOW='\033[1;33m'; BLUE='\033[0;34m'; NC='\033[0m'
log()  { echo -e "${BLUE}[INFO]${NC} $1"; }
ok()   { echo -e "${GREEN}[SUCCESS] ✓${NC} $1"; }
warn() { echo -e "${YELLOW}[WARN] ⚠️  $1${NC}"; }

echo ""
echo -e "${BLUE}╔═══════════════════════════════════════════════════════╗${NC}"
echo -e "${BLUE}║     UD06 - Despliegue Completo (Jenkins CI/CD)     ║${NC}"
echo -e "${BLUE}╚═══════════════════════════════════════════════════════╝${NC}"
echo ""
echo "  Este script realizará el despliegue TOTAL del laboratorio:"
echo "    ✓ Descarga de imágenes base (Modo Offline/Local)"
echo "    ✓ Creación de red aislada LabCEFIRE (172.28.0.0/24)"
echo "    ✓ Despliegue de Infraestructura (Jenkins, Gitea, Prometheus, Grafana)"
echo "    ✓ Configuración de Jobs y Pipelines"
echo "    ✓ Verificación del estado de salud del sistema"
echo ""

# Silencioso si se pasa flag -y
if [[ "${1:-}" != "-y" ]]; then
    read -p "  ¿Deseas continuar con el despliegue? (s/N): " confirm
    if [[ ! "$confirm" =~ ^[sS]$ ]]; then
        echo "  Operación cancelada por el usuario."
        exit 0
    fi
fi

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

echo ""
log "═══════ Fase 1/5: Configuración de Red LabCEFIRE ═══════"
bash "$SCRIPT_DIR/01-setup-network.sh"

echo ""
log "═══════ Fase 2/5: Descarga de Imágenes (Pre-cache) ═══════"
bash "$SCRIPT_DIR/02-pull-images.sh"

echo ""
log "═══════ Fase 3/5: Despliegue de Infraestructura (Terraform) ═══════"
bash "$SCRIPT_DIR/03-deploy-infrastructure.sh"

echo ""
log "═══════ Fase 4/5: Configuración de Herramientas y Gitea ═══════"
bash "$SCRIPT_DIR/04-configure-tools.sh"

echo ""
log "═══════ Fase 5/5: Verificación Final del Sistema ═══════"
bash "$SCRIPT_DIR/07-verify-status.sh"

echo ""
echo -e "${GREEN}╔═══════════════════════════════════════════════════════╗${NC}"
echo -e "${GREEN}║     ✅ LABORALORIO UD06 LISTO PARA USAR             ║${NC}"
echo -e "${GREEN}╚═══════════════════════════════════════════════════════╝${NC}"
echo ""
echo -e "  🚀 Accesos vía Red Interna:"
echo -e "  💾 Gitea:      http://172.28.0.64:3000"
echo -e "  🔧 Jenkins:    http://172.28.0.61:8080"
echo -e "  🧪 Staging:    http://172.28.0.62:3000"
echo -e "  🌐 Production: http://172.28.0.63:3000"
echo -e "  📊 Prometheus: http://172.28.0.65:9090"
echo -e "  📈 Grafana:    http://172.28.0.66:3000"
echo ""
echo "  Procesos de actualización sugeridos:"
echo "    1. Lanzar V1:   bash $SCRIPT_DIR/05-launch-example-app-v1.sh"
echo "    2. Upgrade V2:  bash $SCRIPT_DIR/06-upgrade-to-v2.sh"
echo "    3. Verificar:   bash $SCRIPT_DIR/07-verify-status.sh"
echo ""
echo "  Destrucción:"
echo "    - Infra:  bash $SCRIPT_DIR/98-destroy-infra.sh"
echo "    - Red:    bash $SCRIPT_DIR/99-destroy-network.sh"
echo ""
