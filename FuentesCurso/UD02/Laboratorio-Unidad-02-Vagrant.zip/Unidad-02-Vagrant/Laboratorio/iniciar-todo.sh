#!/bin/bash
# iniciar-todo.sh - Orquestador completo para la Unidad 02
set -e

RED='\033[0;31m'; GREEN='\033[0;32m'; YELLOW='\033[1;33m'; BLUE='\033[0;34m'; NC='\033[0m'

echo -e "\n${BLUE}╔═══════════════════════════════════════════════════════╗${NC}"
echo -e "${BLUE}║     🚀 UD02 - DESPLIEGUE COMPLETO (Vagrant)        ║${NC}"
echo -e "${BLUE}╚═══════════════════════════════════════════════════════╝${NC}"

# 1. Preparación de red (Fase 1)
bash scripts-laboratorio/01-setup-network.sh

# 2. Despliegue de infraestructura (Fase 2)
bash scripts-laboratorio/02-deploy-infra.sh

# 3. Verificación (Fase 3)
bash scripts-laboratorio/03-verify-lab.sh

echo -e "${GREEN}═══════════════════════════════════════════════════════════${NC}"
echo -e "${GREEN}✅ Laboratorio UD02 listo y verificado.${NC}"
echo -e "${GREEN}═══════════════════════════════════════════════════════════${NC}\n"
