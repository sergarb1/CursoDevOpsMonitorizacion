#!/bin/bash
# ======================================================================
# 📋 info-sistema.sh - Mostrar información del sistema
# Propósito: Verificar configuración de la Golden Image antes de capturar
# ======================================================================

echo "╔═══════════════════════════════════════════════════════════╗"
echo "║  📋 Información del Sistema - Golden Image               ║"
echo "╚═══════════════════════════════════════════════════════════╝"
echo ""

# Información del sistema
echo "🖥️  SISTEMA:"
echo "   ───────────────────────────────────────────────────────"
echo "   Hostname: $(hostname)"
echo "   Kernel: $(uname -r)"
echo "   Arquitectura: $(uname -m)"
echo "   Uptime: $(uptime -p 2>/dev/null || uptime)"
echo ""

# CPU y RAM
echo "💾 RECURSOS:"
echo "   ───────────────────────────────────────────────────────"
echo "   CPU: $(nproc) núcleo(s)"
echo "   RAM Total: $(free -h | awk '/^Mem:/ {print $2}')"
echo "   RAM Libre: $(free -h | awk '/^Mem:/ {print $7}')"
echo ""

# ZRAM
echo "⚡ ZRAM:"
echo "   ───────────────────────────────────────────────────────"
if command -v zramctl &> /dev/null; then
    zramctl 2>/dev/null || echo "   ZRAM no activo (reinicia para activar)"
else
    echo "   zram-tools no instalado"
fi
echo ""

# Discos
echo "💽 DISCOS:"
echo "   ───────────────────────────────────────────────────────"
lsblk -o NAME,SIZE,TYPE,MOUNTPOINT 2>/dev/null | grep -v "^loop" || df -h
echo ""

# Red
echo "🌐 RED:"
echo "   ───────────────────────────────────────────────────────"
echo "   Interfaces:"
ip -br addr show 2>/dev/null | grep -v "lo" || echo "   No hay interfaces disponibles"
echo ""
echo "   Ruta por defecto:"
ip route | grep default || echo "   Sin ruta por defecto"
echo ""
echo "   DNS:"
cat /etc/resolv.conf 2>/dev/null | grep nameserver || echo "   Sin DNS configurado"
echo ""

# Usuarios
echo "👤 USUARIOS:"
echo "   ───────────────────────────────────────────────────────"
echo "   Usuarios con shell:"
cut -d: -f1,7 /etc/passwd | grep -E "(bash|sh)$" | grep -v nologin | grep -v false
echo ""

# Software instalado
echo "📦 SOFTWARE INSTALADO:"
echo "   ───────────────────────────────────────────────────────"
echo "   Entorno gráfico:"
dpkg -l | grep -E "^ii.*(lxde|lxde-core)" && echo "   ✓ LXDE instalado" || echo "   ✗ LXDE no instalado"
echo ""
echo "   Navegador:"
dpkg -l | grep -E "^ii.*falkon" && echo "   ✓ Falkon instalado" || echo "   ✗ Falkon no instalado"
echo ""
echo "   Herramientas:"
dpkg -l | grep -E "^ii.*(nano|vim|htop|sudo)" | awk '{print "   ✓ " $2 " " $3}'
echo ""

# Servicios
echo "🔧 SERVICIOS:"
echo "   ───────────────────────────────────────────────────────"
systemctl is-active zramswap.service 2>/dev/null && echo "   ✓ ZRAM activo" || echo "   ⚠️  ZRAM inactivo"
echo ""

# Espacio en disco
echo "📊 ESPACIO EN DISCO:"
echo "   ───────────────────────────────────────────────────────"
df -h / /home 2>/dev/null | tail -n +2
echo ""

echo "╔═══════════════════════════════════════════════════════════╗"
echo "║  ✅ Información recopilada                                ║"
echo "╠═══════════════════════════════════════════════════════════╣"
echo "║  Antes de capturar la imagen:                             ║"
echo "║    1. Verifica que todo el software está instalado        ║"
echo "║    2. Limpia logs y caché:                                ║"
echo "║       sudo bash /home/admin/limpiar-imagen.sh             ║"
echo "║    3. Apaga la VM: sudo poweroff                          ║"
echo "║    4. Inicia captura desde FOG Panel                      ║"
echo "╚═══════════════════════════════════════════════════════════╝"
