# ── Volúmenes Docker persistentes ──
# Gitea usa PostgreSQL (más rápido que SQLite en overlayfs)
# Jenkins necesita volumen Docker para persistencia de plugins y config
# PostgreSQL necesita volumen para datos de la BD

resource "docker_volume" "jenkins_data" {
  name = "jenkins-data"
}

resource "docker_volume" "postgres_data" {
  name = "postgres-data"
}