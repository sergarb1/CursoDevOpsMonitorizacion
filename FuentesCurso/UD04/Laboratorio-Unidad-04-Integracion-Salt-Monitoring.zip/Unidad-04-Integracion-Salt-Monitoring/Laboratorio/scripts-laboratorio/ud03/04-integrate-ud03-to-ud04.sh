#!/bin/bash
# 03-integrate-ud03-to-ud04.sh - Integra VMs de UD03 en el stack de UD04
# Este script permite que las máquinas virtuales creadas en la Unidad 03 (Vagrant)
# sean monitorizadas y gestionadas por el sistema central de la Unidad 04 (Docker).

set -euo pipefail

# Colores para legibilidad
RED='\033[0;31m'; GREEN='\033[0;32m'; YELLOW='\033[1;33m'; BLUE='\033[0;34m'; NC='\033[0m'
log()  { echo -e "${BLUE}[INTEGRATE]${NC} $1"; }
ok()   { echo -e "${GREEN}[INTEGRATE] ✓${NC} $1"; }
fail() { echo -e "${RED}[INTEGRATE] ✗${NC} $1"; }
warn() { echo -e "${YELLOW}[INTEGRATE] ⚠${NC} $1"; }

# IP del Salt Master (actualizada de .10 a .40)
SALT_MASTER="172.28.0.40"

# Verificación de que estamos en el directorio correcto de UD03
[ -f "Vagrantfile" ] || { fail "Error: Ejecuta este script desde el directorio UD03/Laboratorio/Taller-FOG"; exit 1; }

echo ""
echo -e "${BLUE}╔═══════════════════════════════════════════════╗${NC}"
echo -e "${BLUE}║     Integración UD03 (Vagrant) → UD04 (Docker) ║${NC}"
echo -e "${BLUE}╚═══════════════════════════════════════════════╝${NC}"

# Obtener directorio del script
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

# Comprobar estado de las VMs de Vagrant
log "Verificando estado de las máquinas virtuales de UD03..."
FOG_STATUS=$(vagrant status FOG-Server 2>/dev/null | grep -o "running" || echo "")
GOLDEN_STATUS=$(vagrant status Golden-VM 2>/dev/null | grep -o "running" || echo "")
echo "  FOG-Server:  ${FOG_STATUS:-detenida}"
echo "  Golden-VM:   ${GOLDEN_STATUS:-detenida}"

# Instalación en FOG-Server mediante 'vagrant ssh'
if [ "$FOG_STATUS" = "running" ]; then
    log "Instalando agentes en FOG-Server..."
    # Intenta ejecutar el script de instalación del minion pasándole la nueva IP del master
    vagrant ssh FOG-Server -c "sudo bash '$SCRIPT_DIR/01-install-salt-minion.sh' $SALT_MASTER" 2>/dev/null || \
    vagrant ssh FOG-Server -c "sudo bash -c '
        export DEBIAN_FRONTEND=noninteractive
        apt-get update  && apt-get install -y  curl gnupg > /dev/null 2>&1
        mkdir -m 755 -p /etc/apt/keyrings
        curl -fsSL https://packages.broadcom.com/artifactory/api/security/keypair/SaltProjectKey/public | gpg --dearmor | tee /etc/apt/keyrings/salt-archive-keyring.pgp > /dev/null
        curl -fsSL https://github.com/saltstack/salt-install-guide/releases/latest/download/salt.sources | tee /etc/apt/sources.list.d/salt.sources
        apt-get update  && apt-get install -y  salt-minion > /dev/null 2>&1
        echo \"master: $SALT_MASTER\" > /etc/salt/minion
        systemctl restart salt-minion 2>/dev/null || nohup /usr/bin/salt-minion -d > /var/log/salt-minion.log 2>&1 &
    '"
    ok "Salt Minion en FOG-Server configurado"

    log "Instalando Node Exporter en FOG-Server para monitorización..."
    vagrant ssh FOG-Server -c "sudo bash '$SCRIPT_DIR/02-install-node-exporter.sh'" 2>/dev/null || \
    vagrant ssh FOG-Server -c "sudo bash -c '
        export DEBIAN_FRONTEND=noninteractive
        apt-get update  && apt-get install -y  prometheus-node-exporter > /dev/null 2>&1
        systemctl restart prometheus-node-exporter 2>/dev/null || nohup /usr/bin/prometheus-node-exporter --web.listen-address=:9100 > /var/log/node-exporter.log 2>&1 &
    '"
    ok "Node Exporter en FOG-Server activo"
else
    warn "Aviso: FOG-Server no está encendida, se omite su integración."
fi

# Instalación en Golden-VM
if [ "$GOLDEN_STATUS" = "running" ]; then
    log "Instalando agentes en Golden-VM..."
    vagrant ssh Golden-VM -c "sudo bash '$SCRIPT_DIR/02-install-salt-minion.sh' $SALT_MASTER" 2>/dev/null || \
    vagrant ssh Golden-VM -c "sudo bash -c '
        export DEBIAN_FRONTEND=noninteractive
        apt-get update  && apt-get install -y  curl gnupg > /dev/null 2>&1
        mkdir -m 755 -p /etc/apt/keyrings
        curl -fsSL https://packages.broadcom.com/artifactory/api/security/keypair/SaltProjectKey/public | gpg --dearmor | tee /etc/apt/keyrings/salt-archive-keyring.pgp > /dev/null
        curl -fsSL https://github.com/saltstack/salt-install-guide/releases/latest/download/salt.sources | tee /etc/apt/sources.list.d/salt.sources
        apt-get update  && apt-get install -y  salt-minion > /dev/null 2>&1
        echo \"master: $SALT_MASTER\" > /etc/salt/minion
        systemctl restart salt-minion 2>/dev/null || nohup /usr/bin/salt-minion -d > /var/log/salt-minion.log 2>&1 &
    '"
    ok "Salt Minion en Golden-VM configurado"

    log "Instalando Node Exporter en Golden-VM..."
    vagrant ssh Golden-VM -c "sudo bash '$SCRIPT_DIR/02-install-node-exporter.sh'" 2>/dev/null || \
    vagrant ssh Golden-VM -c "sudo bash -c '
        export DEBIAN_FRONTEND=noninteractive
        apt-get update  && apt-get install -y  prometheus-node-exporter > /dev/null 2>&1
        systemctl restart prometheus-node-exporter 2>/dev/null || nohup /usr/bin/prometheus-node-exporter --web.listen-address=:9100 > /var/log/node-exporter.log 2>&1 &
    '"
    ok "Node Exporter en Golden-VM activo"
else
    warn "Aviso: Golden-VM no está encendida, se omite su integración."
fi

# Aceptación de llaves en el Master central (Docker)
log "Esperando a que los Minions se registren (10s)..."
sleep 10

log "Aceptando llaves pendientes en el Salt Master (Contenedor Docker)..."
if command -v docker &>/dev/null && docker inspect vm-master &>/dev/null; then
    docker exec vm-master salt-key -A -y 2>/dev/null || true
    sleep 3
    log "Resultado del ping de SaltStack:"
    docker exec vm-master salt '*' test.ping 2>/dev/null | head -10
else
    warn "Salt Master no accesible por Docker. Por favor, acepta las claves manualmente: salt-key -A -y"
fi

echo ""
ok "Integración UD03 → UD04 completada. Ahora puedes ver estas VMs en el panel de Grafana."
