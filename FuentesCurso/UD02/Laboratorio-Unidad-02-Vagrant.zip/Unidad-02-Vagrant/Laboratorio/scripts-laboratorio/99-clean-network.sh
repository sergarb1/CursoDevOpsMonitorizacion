#!/bin/bash
# 99-clean-network.sh - Destruye la red LabCEFIRE en el Host
set -e

RED='\033[0;31m'; GREEN='\033[0;32m'; YELLOW='\033[1;33m'; BLUE='\033[0;34m'; NC='\033[0m'

echo -e "${RED}╔═══════════════════════════════════════════════════════╗${NC}"
echo -e "${RED}║     ⚠️  UD02 - ELIMINACIÓN DE RED CEFIRE             ║${NC}"
echo -e "${RED}╚═══════════════════════════════════════════════════════╝${NC}"

BRIDGE_NAME="LabCEFIRE"
DUMMY_NAME="cefire-dummy"

if ip link show $BRIDGE_NAME > /dev/null 2>&1; then
    echo -e "${RED}[RED]${NC} Eliminando interfaz dummy '${DUMMY_NAME}'..."
    sudo ip link delete $DUMMY_NAME 2>/dev/null || true
    echo -e "${RED}[RED]${NC} Destruyendo bridge '${BRIDGE_NAME}'..."
    sudo ip link set $BRIDGE_NAME down
    sudo ip link delete $BRIDGE_NAME
    echo -e "${GREEN}✓${NC} Red eliminada con éxito."
else
    echo -e "${YELLOW}!${NC} La red '${BRIDGE_NAME}' no existe."
fi
echo ""
