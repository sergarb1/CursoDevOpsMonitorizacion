#!/bin/bash
# 02-deploy-odoo-containers.sh - Despliega la infraestructura usando Terraform con verificación de servicios

RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
CYAN='\033[0;36m'
NC='\033[0m'

log()      { echo -e "${BLUE}[TF]${NC} $1"; }
ok()       { echo -e "${GREEN}✓${NC} $1"; }
warn()     { echo -e "${YELLOW}⚠${NC} $1"; }
error()    { echo -e "${RED}✗${NC} $1"; }
info()     { echo -e "${CYAN}→${NC} $1"; }
success()  { echo -e "${GREEN}✅${NC} $1"; }

# Barra de progreso interrumpible con Ctrl+C
progress_bar() {
    local duration=$1
    local message=$2
    local width=40
    local elapsed=0
    local interrupted=0

    trap 'interrupted=1; echo ""; warn "Progreso interrumpido por el usuario"' INT

    echo -ne "${CYAN}${message} ${NC}["
    while [ $elapsed -lt $duration ] && [ $interrupted -eq 0 ]; do
        local percent=$((elapsed * 100 / duration))
        local filled=$((percent * width / 100))
        local empty=$((width - filled))
        printf "\r${CYAN}${message} ${NC}["
        printf "${GREEN}%${filled}s${NC}" | tr ' ' '#'
        printf "${YELLOW}%${empty}s${NC}" | tr ' ' '.'
        printf "] ${GREEN}%3d%%${NC}" $percent
        sleep 1
        elapsed=$((elapsed + 1))
    done
    if [ $interrupted -eq 0 ]; then
        printf "\r${CYAN}${message} ${NC}["
        printf "${GREEN}%${width}s${NC}" | tr ' ' '#'
        printf "] ${GREEN}100%%${NC}\n"
    fi
    trap - INT
    return $interrupted
}

echo -e "${BLUE}╔════════════════════════════════════════════════════════════════╗${NC}"
echo -e "${BLUE}║              UD05 - Despliegue con Terraform                   ║${NC}"
echo -e "${BLUE}╚════════════════════════════════════════════════════════════════╝${NC}"
echo ""

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
TF_DIR="$SCRIPT_DIR/../terraform"

cd "$TF_DIR"

if [ ! -d ".terraform" ]; then
    log "Inicializando Terraform..."
    terraform init
    ok "Terraform inicializado"
fi

log "Aplicando cambios en la infraestructura..."
terraform apply -auto-approve

if [ $? -eq 0 ]; then
    success "Infraestructura desplegada correctamente"
else
    error "Error en el despliegue de Terraform"
    exit 1
fi

echo ""
info "Esperando a que todos los servicios estén listos..."
echo ""

# =============================================================================
# ESPERA GLOBAL INICIAL - 10 MINUTOS (600 segundos)
# =============================================================================
echo -e "${YELLOW}════════════════════════════════════════════════════════════════${NC}"
echo -e "${YELLOW}     ⏱️  ESPERA GLOBAL: 600 segundos (10 minutos)${NC}"
echo -e "${YELLOW}     (Pulsa Ctrl+C para interrumpir la espera)${NC}"
echo -e "${YELLOW}════════════════════════════════════════════════════════════════${NC}"
if ! progress_bar 600 "Espera global"; then
    warn "Espera global interrumpida. Continuando con verificaciones..."
fi
echo ""

# =============================================================================
# FUNCIONES DE VERIFICACIÓN (sin cambios)
# =============================================================================

check_postgres() {
    local container=$1
    local max_retries=3
    local retry=0
    while [ $retry -lt $max_retries ]; do
        if docker exec "$container" pg_isready -U odoo >/dev/null 2>&1; then
            return 0
        fi
        sleep 2
        retry=$((retry + 1))
    done
    return 1
}

check_odoo() {
    local container=$1
    local max_retries=3
    local retry=0
    while [ $retry -lt $max_retries ]; do
        local http_code=$(docker exec "$container" curl -s -o /dev/null -w "%{http_code}" http://localhost:8069 2>/dev/null)
        if [[ "$http_code" =~ ^[2-5][0-9]{2}$ ]]; then
            return 0
        fi
        sleep 2
        retry=$((retry + 1))
    done
    return 1
}

check_salt_master() {
    local max_retries=3
    local retry=0
    while [ $retry -lt $max_retries ]; do
        if docker exec ud05-salt-master pgrep -x "salt-master" >/dev/null 2>&1; then return 0; fi
        if docker exec ud05-salt-master pgrep -x -u salt "salt-master" >/dev/null 2>&1; then return 0; fi
        if docker exec ud05-salt-master ps aux | grep -q "[s]alt-master"; then return 0; fi
        if docker exec ud05-salt-master systemctl is-active salt-master >/dev/null 2>&1; then return 0; fi
        sleep 2
        retry=$((retry + 1))
    done
    return 1
}

check_http() {
    local url=$1
    local max_retries=3
    local retry=0
    while [ $retry -lt $max_retries ]; do
        local http_code=$(curl -s -o /dev/null -w "%{http_code}" "$url" 2>/dev/null)
        if [[ "$http_code" =~ ^(200|301|302|303|401|403)$ ]]; then
            return 0
        fi
        sleep 2
        retry=$((retry + 1))
    done
    return 1
}

check_cadvisor() {
    local max_retries=3
    local retry=0
    while [ $retry -lt $max_retries ]; do
        local http_code=$(curl -s -o /dev/null -w "%{http_code}" http://172.28.0.52:8080/ 2>/dev/null)
        if [[ "$http_code" =~ ^(200|301|302|303|304|307)$ ]]; then return 0; fi
        http_code=$(curl -s -o /dev/null -w "%{http_code}" http://172.28.0.52:8080/containers/ 2>/dev/null)
        if [[ "$http_code" =~ ^(200|301|302|303|304|307)$ ]]; then return 0; fi
        sleep 2
        retry=$((retry + 1))
    done
    return 1
}

check_blackbox() {
    local max_retries=3
    local retry=0
    while [ $retry -lt $max_retries ]; do
        local http_code=$(curl -s -o /dev/null -w "%{http_code}" http://172.28.0.53:9115 2>/dev/null)
        if [[ "$http_code" =~ ^(200|302)$ ]]; then return 0; fi
        sleep 2
        retry=$((retry + 1))
    done
    return 1
}

check_loki() {
    local max_retries=3
    local retry=0
    while [ $retry -lt $max_retries ]; do
        local http_code=$(curl -s -o /dev/null -w "%{http_code}" http://172.28.0.54:3100/ 2>/dev/null)
        if [[ "$http_code" =~ ^(200|302|303|404)$ ]]; then
            return 0
        fi
        http_code=$(curl -s -o /dev/null -w "%{http_code}" http://172.28.0.54:3100/ready 2>/dev/null)
        if [[ "$http_code" = "200" ]]; then
            return 0
        fi
        sleep 2
        retry=$((retry + 1))
    done
    return 1
}

# =============================================================================
# VERIFICAR CONTENEDORES
# =============================================================================
info "Verificando estado de los contenedores..."

containers=(
    "ud05-salt-master"
    "odoo-pg1" "odoo-pg2"
    "odoo-minion-1" "odoo-minion-2"
    "odoo-prometheus" "odoo-grafana"
    "odoo-loki" "odoo-alloy"
    "odoo-cadvisor" "odoo-blackbox"
)

for container in "${containers[@]}"; do
    if docker ps --format '{{.Names}}' | grep -q "^${container}$"; then
        ok "Contenedor $container está corriendo"
    else
        warn "Contenedor $container no está ejecutándose"
    fi
done

echo ""

# =============================================================================
# COMPROBACIÓN INICIAL RÁPIDA
# =============================================================================
echo -e "${CYAN}╔════════════════════════════════════════════════════════════════╗${NC}"
echo -e "${CYAN}║     🔍 COMPROBACIÓN INICIAL DE SERVICIOS (rápida)             ║${NC}"
echo -e "${CYAN}╚════════════════════════════════════════════════════════════════╝${NC}"
echo ""

quick_check() {
    local name=$1
    local check_func=$2
    
    echo -ne "  ${CYAN}→${NC} Verificando ${name}... "
    if eval $check_func 2>/dev/null; then
        echo -e "${GREEN}✓ LISTO${NC}"
        return 0
    else
        echo -e "${YELLOW}⚠ NO LISTO - se verificará con reintentos${NC}"
        return 1
    fi
}

quick_check "PostgreSQL 1" "check_postgres odoo-pg1"
quick_check "PostgreSQL 2" "check_postgres odoo-pg2"
quick_check "Odoo 1" "check_odoo odoo-minion-1"
quick_check "Odoo 2" "check_odoo odoo-minion-2"
quick_check "Salt Master" "check_salt_master"
quick_check "Grafana" "check_http http://172.28.0.56:3000"
quick_check "Prometheus" "check_http http://172.28.0.51:9090"
quick_check "Loki" "check_loki"
quick_check "cAdvisor" "check_cadvisor"
quick_check "Blackbox Exporter" "check_blackbox"

echo ""

# =============================================================================
# VERIFICACIÓN CON REINTENTOS
# =============================================================================
echo -e "${CYAN}╔════════════════════════════════════════════════════════════════╗${NC}"
echo -e "${CYAN}║     🔄 VERIFICACIÓN EXHAUSTIVA (con reintentos)               ║${NC}"
echo -e "${CYAN}╚════════════════════════════════════════════════════════════════╝${NC}"

verify_service_with_retry() {
    local name=$1
    local check_func=$2
    local wait_time=$3
    local max_attempts=3
    local attempt=1

    echo -e "\n${CYAN}────────────────────────────────────────────────────────────────${NC}"
    echo -e "${CYAN}  🔍 Verificando: ${name}${NC}"
    echo -e "${CYAN}────────────────────────────────────────────────────────────────${NC}"

    while [ $attempt -le $max_attempts ]; do
        echo -e "${YELLOW}📌 Intento $attempt de $max_attempts${NC}"
        progress_bar $wait_time "  ⏳ Esperando respuesta de ${name}" || {
            warn "Verificación interrumpida para ${name}, continuando..."
            return 0
        }

        if eval $check_func; then
            echo -e "${GREEN}✓ ${name} está listo!${NC}"
            return 0
        else
            echo -e "${RED}✗ ${name} no responde${NC}"
            if [ $attempt -lt $max_attempts ]; then
                echo -e "${YELLOW}🔄 Reintentando en 10 segundos...${NC}"
                sleep 10
            fi
        fi
        attempt=$((attempt + 1))
    done
    return 0
}

verify_service_with_retry "PostgreSQL 1" "check_postgres odoo-pg1" 15
verify_service_with_retry "PostgreSQL 2" "check_postgres odoo-pg2" 15
verify_service_with_retry "Odoo 1" "check_odoo odoo-minion-1" 30
verify_service_with_retry "Odoo 2" "check_odoo odoo-minion-2" 30
verify_service_with_retry "Salt Master" "check_salt_master" 20
verify_service_with_retry "Grafana" "check_http http://172.28.0.56:3000" 15
verify_service_with_retry "Prometheus" "check_http http://172.28.0.51:9090" 15
verify_service_with_retry "Loki" "check_loki" 15
verify_service_with_retry "cAdvisor" "check_cadvisor" 15
verify_service_with_retry "Blackbox Exporter" "check_blackbox" 10

# =============================================================================
# RESUMEN FINAL CON IPs y PASSWORDS
# =============================================================================
echo ""
echo -e "${GREEN}╔════════════════════════════════════════════════════════════════╗${NC}"
echo -e "${GREEN}║                    🎉 DEPLOYMENT COMPLETADO 🎉                 ║${NC}"
echo -e "${GREEN}╚════════════════════════════════════════════════════════════════╝${NC}"
echo ""
echo -e "${CYAN}📍 INFRAESTRUCTURA DESPLEGADA:${NC}"
echo -e "   • ${GREEN}Salt Master${NC}:       172.28.0.50"
echo -e "   • ${GREEN}Prometheus${NC}:        172.28.0.51:9090"
echo -e "   • ${GREEN}cAdvisor${NC}:          172.28.0.52:8080"
echo -e "   • ${GREEN}Blackbox Exporter${NC}: 172.28.0.53:9115"
echo -e "   • ${GREEN}Loki${NC}:              172.28.0.54:3100"
echo -e "   • ${GREEN}Alloy${NC}:             172.28.0.55:12345"
echo -e "   • ${GREEN}Grafana${NC}:           http://172.28.0.56:3000"
echo -e "   • ${GREEN}Odoo 1${NC}:            http://172.28.0.57:8069"
echo -e "   • ${GREEN}Odoo 2${NC}:            http://172.28.0.58:8069"
echo -e "   • ${GREEN}PostgreSQL 1${NC}:      172.28.0.59:5432"
echo -e "   • ${GREEN}PostgreSQL 2${NC}:      172.28.0.60:5432"
echo ""
echo -e "${CYAN}🔑 CREDENCIALES POR DEFECTO:${NC}"
echo -e "   • ${YELLOW}Grafana${NC}:           usuario: ${GREEN}admin${NC} / contraseña: ${GREEN}admin${NC}"
echo -e "   • ${YELLOW}Odoo (ambos)${NC}:      usuario: ${GREEN}admin${NC} / contraseña: ${GREEN}admin${NC}"
echo -e "   • ${YELLOW}PostgreSQL${NC}:        usuario: ${GREEN}odoo${NC} / contraseña: ${GREEN}odoo${NC}"
echo -e "   • ${YELLOW}Salt Master${NC}:       sin autenticación (minions aceptados automáticamente)"
echo ""
echo -e "${CYAN}📊 ENDPOINTS DE MÉTRICAS:${NC}"
echo -e "   • ${GREEN}Node Exporter (Odoo1)${NC}: http://172.28.0.57:9100/metrics"
echo -e "   • ${GREEN}Node Exporter (Odoo2)${NC}: http://172.28.0.58:9100/metrics"
echo -e "   • ${GREEN}Node Exporter (Salt)${NC}:  http://172.28.0.50:9100/metrics"
echo -e "   • ${GREEN}Odoo Exporter (Odoo1)${NC}: http://172.28.0.57:9090/metrics"
echo -e "   • ${GREEN}Odoo Exporter (Odoo2)${NC}: http://172.28.0.58:9090/metrics"
echo ""
echo -e "${YELLOW}📝 NOTAS:${NC}"
echo -e "   • Los Salt Minions se conectan automáticamente al Master (172.28.0.50)"
echo -e "   • Alloy recolecta logs de todos los contenedores hacia Loki"
echo -e "   • Los exporters de métricas están integrados en cada Odoo"
echo -e "   • Para ver logs: docker logs <nombre_contenedor>"
echo ""
echo -e "${GREEN}✅ ¡Infraestructura lista para trabajar!${NC}"
echo ""