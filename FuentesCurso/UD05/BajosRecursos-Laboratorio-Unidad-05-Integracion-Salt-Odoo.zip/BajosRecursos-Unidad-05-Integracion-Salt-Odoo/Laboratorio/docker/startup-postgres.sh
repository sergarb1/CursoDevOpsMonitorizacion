#!/bin/bash
# startup-postgres.sh
set -u
log() { echo "[POSTGRES] $1"; }

POSTGRES_USER="${POSTGRES_USER:-odoo}"
POSTGRES_PASSWORD="${POSTGRES_PASSWORD:-odoo}"

log "Iniciando PostgreSQL..."
docker-entrypoint.sh postgres &

log "Esperando a que PostgreSQL esté listo..."
until pg_isready -h localhost -p 5432 >/dev/null 2>&1; do sleep 2; done

log "Otorgando permisos CREATEDB a ${POSTGRES_USER}..."
PGPASSWORD="${POSTGRES_PASSWORD}" psql -h localhost -U "${POSTGRES_USER}" -d postgres -c "ALTER USER ${POSTGRES_USER} CREATEDB;" 2>/dev/null

log "PostgreSQL listo."
tail -f /dev/null