#!/bin/bash
# startup-salt-master.sh - UD05 (usa binario local de node_exporter)
set -uo pipefail
log() { echo "[ARRANQUE:salt-master] $1"; }
export DEBIAN_FRONTEND=noninteractive

# ------------------------------------------------------------------
# 1. Herramientas base
# ------------------------------------------------------------------
log "Instalando herramientas base..."
apt-get update -qq 2>/dev/null || true
apt-get install -y -qq wget curl gnupg 2>/dev/null || true

# ------------------------------------------------------------------
# 2. Node Exporter desde binario local
# ------------------------------------------------------------------
NODE_BIN="/usr/local/bin/node_exporter"
if [ -f "$NODE_BIN" ]; then
    if ! pgrep -x "node_exporter" >/dev/null; then
        log "Iniciando Node Exporter desde binario local..."
        $NODE_BIN --web.listen-address=:9100 > /tmp/node_exporter.log 2>&1 &
        sleep 2
        pgrep -x "node_exporter" >/dev/null && log "✓ Node Exporter activo" || log "⚠ Fallo Node Exporter"
    else
        log "✓ Node Exporter ya activo"
    fi
else
    log "⚠ Binario node_exporter no encontrado en $NODE_BIN"
fi

# ------------------------------------------------------------------
# 3. Instalación de Salt (background)
# ------------------------------------------------------------------
(
    log "Instalando Salt Master 3006 LTS..."
    mkdir -m 755 -p /etc/apt/keyrings
    curl -fsSL https://packages.broadcom.com/artifactory/api/security/keypair/SaltProjectKey/public | gpg --dearmor -o /etc/apt/keyrings/salt-archive-keyring.pgp
    curl -fsSL https://github.com/saltstack/salt-install-guide/releases/latest/download/salt.sources | tee /etc/apt/sources.list.d/salt.sources > /dev/null
    echo 'Package: salt-*
Pin: version 3006.*
Pin-Priority: 1001' | tee /etc/apt/preferences.d/salt-pin-1001 > /dev/null
    apt-get update -qq && apt-get install -y -qq salt-master salt-minion salt-common >/dev/null 2>&1
    
    salt-master -d 2>/dev/null || true
    mkdir -p /etc/salt
    echo "master: 172.28.0.50" > /etc/salt/minion
    echo "id: salt-master" >> /etc/salt/minion
    salt-minion -d 2>/dev/null || true
    
    (while true; do salt-key -A -y >/dev/null 2>&1 || true; sleep 15; done) &
) &

log "Servicios principales en marcha. Tailing /dev/null"
tail -f /dev/null