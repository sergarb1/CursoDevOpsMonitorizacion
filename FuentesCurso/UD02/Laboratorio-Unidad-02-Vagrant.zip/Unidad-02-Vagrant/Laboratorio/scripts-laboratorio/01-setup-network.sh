#!/bin/bash
# 01-setup-network.sh - Configura el bridge LabCEFIRE en el Host
set -e

# Colores
RED='\033[0;31m'; GREEN='\033[0;32m'; BLUE='\033[0;34m'; YELLOW='\033[1;33m'; NC='\033[0m'

echo -e "${BLUE}╔═══════════════════════════════════════════════════════╗${NC}"
echo -e "${BLUE}║     UD02 - Configuración de Red Bridge (Host)       ║${NC}"
echo -e "${BLUE}╚═══════════════════════════════════════════════════════╝${NC}"

BRIDGE_NAME="LabCEFIRE"
DUMMY_NAME="cefire-dummy"
BRIDGE_IP="172.28.0.1"

# 1. Limpieza de residuos
if ip link show $BRIDGE_NAME > /dev/null 2>&1; then
    echo -e "${YELLOW}[RED]${NC} Limpiando configuración previa..."
    sudo ip link set $BRIDGE_NAME down >/dev/null 2>&1
    sudo ip link delete $BRIDGE_NAME >/dev/null 2>&1
    [ -d /sys/class/net/$DUMMY_NAME ] && sudo ip link delete $DUMMY_NAME >/dev/null 2>&1
fi

echo -e "${BLUE}[RED]${NC} Creando bridge '${BRIDGE_NAME}'..."
sudo modprobe dummy > /dev/null 2>&1
sudo ip link add name $BRIDGE_NAME type bridge
sudo ip addr add $BRIDGE_IP/24 dev $BRIDGE_NAME

echo -e "${BLUE}[RED]${NC} Forzando estado UP con interfaz dummy..."
sudo ip link add $DUMMY_NAME type dummy
sudo ip link set $DUMMY_NAME master $BRIDGE_NAME
sudo ip link set $DUMMY_NAME up
sudo ip link set $BRIDGE_NAME up

echo -e "${GREEN}✓${NC} Red configurada con éxito."
echo -e "  IP del Host (Gateway): ${GREEN}${BRIDGE_IP}${NC}"
echo -e "  Estado: $(ip addr show $BRIDGE_NAME | grep -oP 'state \K\w+')"
echo ""
