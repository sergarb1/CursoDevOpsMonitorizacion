#!/bin/bash
# 01-base.sh - Configuración base común para todos los nodos
# Funciona en Ubuntu 24.04 y Debian 12

set -euo pipefail

echo "--- [BASE] Configuración base ---"

# Actualizar repositorios
apt-get update 

# Instalar herramientas básicas
export DEBIAN_FRONTEND=noninteractive && \
apt-get update  && \
apt-get install -y  --no-install-recommends \
    curl ca-certificates \
    wget git \
    vim-tiny nano \
    htop net-tools \
    iproute2 dnsutils \
    gnupg

# Configurar usuario admin
if ! id "admin" &>/dev/null; then
    useradd -m -s /bin/bash -G sudo admin
    echo "admin:Admin1234" | chpasswd
    echo "   ✅ Usuario admin creado admin con password Admin1234"
else
    echo "   ℹ️  Usuario admin ya existe"
fi

# Habilitar SSH root login (para debugging)
sed -i 's/#PermitRootLogin prohibit-password/PermitRootLogin yes/' /etc/ssh/sshd_config 2>/dev/null || true
sed -i 's/PermitRootLogin prohibit-password/PermitRootLogin yes/' /etc/ssh/sshd_config 2>/dev/null || true

echo "✅ Base configuration OK."
