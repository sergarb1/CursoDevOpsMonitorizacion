#!/bin/bash
# 99-destroy-network.sh - Elimina solo la red LabCEFIRE
# ======================================================
# NOTA: 98-destroy-infra.sh ya incluye la eliminación de la red.
# Este script es útil si solo quieres eliminar la red después
# de que 98 haya limpiado los contenedores.
# ======================================================
set -uo pipefail

BOLD='\033[1m'
RED='\033[0;31m'; GREEN='\033[0;32m'; YELLOW='\033[1;33m'
BLUE='\033[0;34m'; CYAN='\033[0;36m'; NC='\033[0m'
CHECK="${GREEN}✓${NC}"; CROSS="${RED}✗${NC}"; INFO="${CYAN}ℹ${NC}"

NETWORK_NAME="LabCEFIRE"

echo -e "${RED}${BOLD}"
echo "╔══════════════════════════════════════════════════════════════╗"
echo "║     ⚠️  UD06 - ELIMINACIÓN DE RED LabCEFIRE                ║"
echo "╚══════════════════════════════════════════════════════════════╝"
echo -e "${NC}"

# ── Verificar si la red existe ──
if ! docker network inspect "$NETWORK_NAME" >/dev/null 2>&1; then
  echo -e "  ${INFO} La red '${NETWORK_NAME}' no existe. Nada que hacer."
  exit 0
fi

# ── Verificar si hay contenedores conectados ──
CONNECTED=$(docker network inspect "$NETWORK_NAME" --format '{{json .Containers}}' 2>/dev/null)
if [[ "$CONNECTED" != "{}" && -n "$CONNECTED" ]]; then
  echo -e "  ${YELLOW}⚠  Aún hay contenedores conectados a la red:${NC}"
  docker network inspect "$NETWORK_NAME" --format '{{range $k, $v := .Containers}}{{.Name}}{{"\n"}}{{end}}' 2>/dev/null
  echo ""
  echo -e "  ${YELLOW}⚠  Ejecuta primero 98-destroy-infra.sh para eliminar los contenedores.${NC}"
  echo -e "     O fuerza la eliminación manual: ${BOLD}docker network rm $NETWORK_NAME${NC}"
  exit 1
fi

read -p "  ¿Eliminar la red '$NETWORK_NAME'? (s/N): " confirm

if [[ ! "$confirm" =~ ^[sS]$ ]]; then
  echo "  Operación cancelada."
  exit 0
fi

echo -e "\n${BLUE}[RED]${NC} Eliminando red '${NETWORK_NAME}'..."
docker network rm "$NETWORK_NAME" >/dev/null 2>&1
echo -e "  ${CHECK} Red '${NETWORK_NAME}' eliminada correctamente."
echo ""
echo -e "  ${YELLOW}💡 Para redesplegar:${NC} bash 01-setup-network.sh"
