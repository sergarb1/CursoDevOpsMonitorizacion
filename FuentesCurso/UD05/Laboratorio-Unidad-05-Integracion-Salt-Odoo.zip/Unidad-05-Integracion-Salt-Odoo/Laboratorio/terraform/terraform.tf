# main.tf
terraform {
  required_providers {
    docker = {
      source  = "kreuzwerker/docker"
      version = "~> 3.0"
    }
  }
}

provider "docker" {}

locals {
  lab_base_path = abspath("${path.module}/..")
}

variable "odoo_image" { default = "odoo:17" }
variable "postgres_image" { default = "postgres:15" }

variable "odoo_admin_user" { default = "admin" }
variable "odoo_admin_password" { default = "admin" }
variable "odoo_db_name" { default = "odoo_db" }
variable "exporter_port_1" { default = "9090" }
variable "exporter_port_2" { default = "9090" }

data "docker_network" "ud05_net" { name = "LabCEFIRE" }

# ---------------------------------------------------------------------------
# VOLÚMENES
# ---------------------------------------------------------------------------
resource "docker_volume" "odoo_pgsql_1" { name = "ud05_odoo_pgsql_1" }
resource "docker_volume" "odoo_pgsql_2" { name = "ud05_odoo_pgsql_2" }
resource "docker_volume" "odoo_data_1"   { name = "ud05_odoo_data_1" }
resource "docker_volume" "odoo_data_2"   { name = "ud05_odoo_data_2" }
resource "docker_volume" "prometheus_data" { name = "ud05_prometheus_data" }
resource "docker_volume" "grafana_data"   { name = "ud05_grafana_data" }
resource "docker_volume" "loki_data"      { name = "ud05_loki_data" }

# ---------------------------------------------------------------------------
# ODOO MINION 1
# ---------------------------------------------------------------------------
resource "docker_container" "pg1" {
  name     = "odoo-pg1"
  image    = var.postgres_image
  memory   = 512
  hostname = "odoo-pg1"
  restart  = "unless-stopped"
  networks_advanced {
    name         = data.docker_network.ud05_net.name
    ipv4_address = "172.28.0.59"
  }
  env = [
    "POSTGRES_USER=odoo",
    "POSTGRES_PASSWORD=odoo",
    "POSTGRES_DB=postgres"
  ]
  volumes {
    volume_name    = docker_volume.odoo_pgsql_1.name
    container_path = "/var/lib/postgresql/data"
  }
  healthcheck {
    test     = ["CMD-SHELL", "pg_isready -U odoo"]
    interval = "5s"
    timeout  = "5s"
    retries  = 10
  }
}

resource "docker_container" "odoo_minion_1" {
  name     = "odoo-minion-1"
  image    = var.odoo_image
  memory   = 1536
  hostname = "odoo-minion-1"
  restart  = "unless-stopped"
  networks_advanced {
    name         = data.docker_network.ud05_net.name
    ipv4_address = "172.28.0.57"
  }
  env = [
    "POSTGRES_HOST=172.28.0.59",
    "POSTGRES_USER=odoo",
    "POSTGRES_PASSWORD=odoo",
    "ODOO_ADMIN_USER=${var.odoo_admin_user}",
    "ODOO_ADMIN_PASSWORD=${var.odoo_admin_password}",
    "ODOO_DB_NAME=${var.odoo_db_name}",
    "EXPORTER_PORT=${var.exporter_port_1}"
  ]
  volumes {
    volume_name    = docker_volume.odoo_data_1.name
    container_path = "/var/lib/odoo"
  }
  volumes {
    host_path      = "${local.lab_base_path}/config/odoo-1.conf"
    container_path = "/etc/odoo/odoo.conf"
  }
  upload {
    source     = "${local.lab_base_path}/docker/startup-odoo.sh"
    file       = "/opt/startup-odoo.sh"
    executable = true
  }
  upload {
    source = "${local.lab_base_path}/docker/odoo-exporter/odoo-exporter.py"
    file   = "/opt/odoo-exporter.py"
  }
    upload {
    source     = "${local.lab_base_path}/docker/bin/node_exporter"
    file       = "/usr/local/bin/node_exporter"
    executable = true
  }
  user = "root"
  entrypoint = ["/bin/bash", "/opt/startup-odoo.sh"]
  depends_on = [docker_container.pg1, docker_container.alloy]
  healthcheck {
    test     = ["CMD-SHELL", "curl -f http://localhost:8069/web/login || exit 1"]
    interval = "10s"
    timeout  = "10s"
    retries  = 15
    start_period = "30s"
  }
}

# ---------------------------------------------------------------------------
# ODOO MINION 2
# ---------------------------------------------------------------------------
resource "docker_container" "pg2" {
  name     = "odoo-pg2"
  image    = var.postgres_image
  memory   = 512
  hostname = "odoo-pg2"
  restart  = "unless-stopped"
  networks_advanced {
    name         = data.docker_network.ud05_net.name
    ipv4_address = "172.28.0.60"
  }
  env = [
    "POSTGRES_USER=odoo",
    "POSTGRES_PASSWORD=odoo",
    "POSTGRES_DB=postgres"
  ]
  volumes {
    volume_name    = docker_volume.odoo_pgsql_2.name
    container_path = "/var/lib/postgresql/data"
  }
  healthcheck {
    test     = ["CMD-SHELL", "pg_isready -U odoo"]
    interval = "5s"
    timeout  = "5s"
    retries  = 10
  }
}

resource "docker_container" "odoo_minion_2" {
  name     = "odoo-minion-2"
  image    = var.odoo_image
  memory   = 1536
  hostname = "odoo-minion-2"
  restart  = "unless-stopped"
  networks_advanced {
    name         = data.docker_network.ud05_net.name
    ipv4_address = "172.28.0.58"
  }
  env = [
    "POSTGRES_HOST=172.28.0.60",
    "POSTGRES_USER=odoo",
    "POSTGRES_PASSWORD=odoo",
    "ODOO_ADMIN_USER=${var.odoo_admin_user}",
    "ODOO_ADMIN_PASSWORD=${var.odoo_admin_password}",
    "ODOO_DB_NAME=${var.odoo_db_name}",
    "EXPORTER_PORT=${var.exporter_port_2}"
  ]
  volumes {
    volume_name    = docker_volume.odoo_data_2.name
    container_path = "/var/lib/odoo"
  }
  volumes {
    host_path      = "${local.lab_base_path}/config/odoo-2.conf"
    container_path = "/etc/odoo/odoo.conf"
  }
  upload {
    source     = "${local.lab_base_path}/docker/startup-odoo.sh"
    file       = "/opt/startup-odoo.sh"
    executable = true
  }
  upload {
    source = "${local.lab_base_path}/docker/odoo-exporter/odoo-exporter.py"
    file   = "/opt/odoo-exporter.py"
  }
    upload {
    source     = "${local.lab_base_path}/docker/bin/node_exporter"
    file       = "/usr/local/bin/node_exporter"
    executable = true
  }
  user = "root"
  entrypoint = ["/bin/bash", "/opt/startup-odoo.sh"]
  depends_on = [docker_container.pg2, docker_container.alloy]
  healthcheck {
    test     = ["CMD-SHELL", "curl -f http://localhost:8069/web/login || exit 1"]
    interval = "10s"
    timeout  = "10s"
    retries  = 15
    start_period = "30s"
  }
}

# ---------------------------------------------------------------------------
# MONITORING (Prometheus, Grafana, Loki, Alloy, cAdvisor, Blackbox)
# Se mantienen igual pero sin node_exporter innecesario
# ---------------------------------------------------------------------------
resource "docker_container" "prometheus" {
  name     = "odoo-prometheus"
  image    = "prom/prometheus:v2.51.0"
  memory   = 512
  hostname = "odoo-prometheus"
  restart  = "unless-stopped"
  networks_advanced {
    name         = data.docker_network.ud05_net.name
    ipv4_address = "172.28.0.51"
  }
  volumes {
    volume_name    = docker_volume.prometheus_data.name
    container_path = "/prometheus"
  }
  upload {
    source = "${local.lab_base_path}/docker/prometheus/prometheus-odoo.yml"
    file   = "/etc/prometheus/prometheus.yml"
  }
  entrypoint = ["/bin/prometheus", "--config.file=/etc/prometheus/prometheus.yml", "--storage.tsdb.path=/prometheus"]
}

resource "docker_container" "grafana" {
  name     = "odoo-grafana"
  image    = "grafana/grafana:10.4.0"
  memory   = 256
  hostname = "odoo-grafana"
  restart  = "unless-stopped"
  networks_advanced {
    name         = data.docker_network.ud05_net.name
    ipv4_address = "172.28.0.56"
  }
  env = [ "GF_SECURITY_ADMIN_USER=admin", "GF_SECURITY_ADMIN_PASSWORD=admin" ]
  upload {
    source = "${local.lab_base_path}/docker/grafana/datasources.yml"
    file   = "/etc/grafana/provisioning/datasources/datasources.yml"
  }
  upload {
    source = "${local.lab_base_path}/docker/grafana/dashboards.yml"
    file   = "/etc/grafana/provisioning/dashboards/dashboards.yml"
  }
  volumes {
    host_path      = "${local.lab_base_path}/docker/grafana/dashboards"
    container_path = "/var/lib/grafana/dashboards"
  }
  entrypoint = ["/run.sh"]
}

resource "docker_container" "loki" {
  name     = "odoo-loki"
  image    = "grafana/loki:2.9.5"
  memory   = 256
  hostname = "odoo-loki"
  restart  = "unless-stopped"
  networks_advanced {
    name         = data.docker_network.ud05_net.name
    ipv4_address = "172.28.0.54"
  }
  volumes {
    volume_name    = docker_volume.loki_data.name
    container_path = "/loki"
  }
  upload {
    source = "${local.lab_base_path}/docker/loki/loki-config.yml"
    file   = "/etc/loki/local-config.yaml"
  }
  entrypoint = ["/usr/bin/loki", "-config.file=/etc/loki/local-config.yaml"]
}

resource "docker_container" "alloy" {
  name     = "odoo-alloy"
  image    = "grafana/alloy:latest"
  memory   = 256
  hostname = "odoo-alloy"
  restart  = "unless-stopped"
  networks_advanced {
    name         = data.docker_network.ud05_net.name
    ipv4_address = "172.28.0.55"
  }
  volumes {
    host_path      = "/var/run/docker.sock"
    container_path = "/var/run/docker.sock"
  }
  upload {
    source = "${local.lab_base_path}/docker/alloy/config.alloy"
    file   = "/etc/alloy/config.alloy"
  }
  entrypoint = ["/bin/alloy", "run", "/etc/alloy/config.alloy", "--server.http.listen-addr=0.0.0.0:12345"]
}

resource "docker_container" "cadvisor" {
  name     = "odoo-cadvisor"
  image    = "gcr.io/cadvisor/cadvisor:latest"
  memory   = 256
  hostname = "odoo-cadvisor"
  privileged = true
  restart  = "unless-stopped"
  networks_advanced {
    name         = data.docker_network.ud05_net.name
    ipv4_address = "172.28.0.52"
  }
  volumes {
    host_path      = "/"
    container_path = "/rootfs"
    read_only      = true
  }
  volumes {
    host_path      = "/var/run"
    container_path = "/var/run"
  }
  volumes {
    host_path      = "/sys"
    container_path = "/sys"
    read_only      = true
  }
  volumes {
    host_path      = "/var/lib/docker"
    container_path = "/var/lib/docker"
    read_only      = true
  }
  entrypoint = ["/usr/bin/cadvisor", "-logtostderr", "--docker_only"]
}

resource "docker_container" "blackbox_exporter" {
  name     = "odoo-blackbox"
  image    = "prom/blackbox-exporter:v0.25.0"
  memory   = 128
  hostname = "odoo-blackbox"
  restart  = "unless-stopped"
  networks_advanced {
    name         = data.docker_network.ud05_net.name
    ipv4_address = "172.28.0.53"
  }
  upload {
    source = "${local.lab_base_path}/docker/blackbox-config.yml"
    file   = "/etc/blackbox/blackbox.yml"
  }
  entrypoint = ["/bin/blackbox_exporter", "--config.file=/etc/blackbox/blackbox.yml"]
}

resource "docker_container" "vm_master" {
  name     = "ud05-salt-master"
  image    = "ubuntu:24.04"
  memory   = 512
  hostname = "salt-master"
  restart  = "unless-stopped"
  networks_advanced {
    name         = data.docker_network.ud05_net.name
    ipv4_address = "172.28.0.50"
  }
  dns      = ["8.8.8.8", "8.8.4.4"]
  capabilities { add = ["NET_ADMIN"] }
  upload {
    source     = "${local.lab_base_path}/docker/startup-salt-master.sh"
    file       = "/opt/startup-salt-master.sh"
    executable = true
  }
    upload {
    source     = "${local.lab_base_path}/docker/bin/node_exporter"
    file       = "/usr/local/bin/node_exporter"
    executable = true
  }
  entrypoint = ["bash", "/opt/startup-salt-master.sh"]
}

output "infrastructure_summary" {
  value = <<EOT
...
EOT
}