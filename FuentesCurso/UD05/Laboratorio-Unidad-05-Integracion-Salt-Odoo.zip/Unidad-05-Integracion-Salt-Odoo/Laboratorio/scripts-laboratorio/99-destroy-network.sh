#!/bin/bash
# 99-destroy-network.sh - Elimina la red LabCEFIRE
set -uo pipefail

# ------------------------------------------------------------------
# Colores
# ------------------------------------------------------------------
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
CYAN='\033[0;36m'
NC='\033[0m'

# ------------------------------------------------------------------
# Cabecera
# ------------------------------------------------------------------
echo -e "${RED}╔═══════════════════════════════════════════════════════╗${NC}"
echo -e "${RED}║     ⚠️  UD05 - ELIMINACIÓN DE RED LabCEFIRE         ║${NC}"
echo -e "${RED}╚═══════════════════════════════════════════════════════╝${NC}"
echo ""

NETWORK_NAME="LabCEFIRE"

# Verificar si la red existe
if docker network inspect "$NETWORK_NAME" >/dev/null 2>&1; then
    echo -e "${CYAN}ℹ${NC}  Se eliminará la red '${YELLOW}${NETWORK_NAME}${NC}'."
    echo -e "${CYAN}ℹ${NC}  Esta acción no se puede deshacer."
    echo ""
    
    # Confirmación interactiva (s/N)
    read -p "$(echo -e "${YELLOW}¿Continuar? (s/N): ${NC}")" confirm
    echo ""

    if [[ "$confirm" =~ ^[sS]$ ]]; then
        echo -e "${BLUE}[RED]${NC} Eliminando red '${NETWORK_NAME}'..."
        if docker network rm "$NETWORK_NAME" 2>/dev/null; then
            echo -e "${GREEN}✓${NC} Red '${NETWORK_NAME}' eliminada exitosamente."
        else
            echo -e "${RED}✗${NC} Error al eliminar la red. Verifica que no haya contenedores usándola."
            exit 1
        fi
    else
        echo -e "${YELLOW}Operación cancelada.${NC}"
        exit 0
    fi
else
    echo -e "${YELLOW}!${NC} La red '${NETWORK_NAME}' no existe."
    exit 0
fi