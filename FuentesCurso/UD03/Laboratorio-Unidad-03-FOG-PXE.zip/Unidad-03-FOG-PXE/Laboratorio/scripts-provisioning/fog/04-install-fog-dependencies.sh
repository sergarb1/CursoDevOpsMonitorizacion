#!/bin/bash
# 04-install-fog-dependencies.sh - Instalar dependencias para FOG Project
set -e

echo "=========================================="
echo "📦 [FOG] Instalando dependencias de FOG..."
echo "=========================================="

apt-get install -y git isc-dhcp-server apache2 default-mysql-server default-libmysqlclient-dev nfs-kernel-server tftpd-hpa php php-mysql nano htop vim

echo "✅ [FOG] Dependencias instaladas correctamente"
