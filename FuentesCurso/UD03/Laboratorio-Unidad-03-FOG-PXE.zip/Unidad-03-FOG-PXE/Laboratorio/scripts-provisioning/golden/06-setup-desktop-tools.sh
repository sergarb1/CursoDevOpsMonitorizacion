#!/bin/bash
# 06-setup-desktop-tools.sh - Copiar scripts y documentación al escritorio
set -e

DESKTOP_DIR="/home/admin/Escritorio"
SCRIPTS_DIR="/vagrant/scripts-provisioning/golden/utils"

echo "=========================================="
echo "📋 [GOLDEN] Copiando scripts y LEEME al escritorio..."
echo "=========================================="

# 1. Preparar directorios
mkdir -p "$DESKTOP_DIR/scripts"

# 2. Copiar scripts de utilidad numerados
if [ -d "$SCRIPTS_DIR" ]; then
    for script in 01-configurar-red.sh 02-info-sistema.sh 03-limpiar-imagen.sh; do
        if [ -f "$SCRIPTS_DIR/$script" ]; then
            cp "$SCRIPTS_DIR/$script" "$DESKTOP_DIR/scripts/"
            chmod +x "$DESKTOP_DIR/scripts/$script"
            echo "   ✓ $script copiado"
        fi
    done
fi

# 3. Crear archivo LEEME en el escritorio
cat > "$DESKTOP_DIR/LEEME.txt" << 'EOF'
╔═══════════════════════════════════════════════════════════════╗
║  🎉 ¡Bienvenido a la Golden Image - UD03 FOG PXE!            ║
╠═══════════════════════════════════════════════════════════════╣
║                                                               ║
║  Esta es la imagen base que se capturará con FOG Project.     ║
║                                                               ║
║  📋 SOFTWARE INSTALADO:                                       ║
║    ✓ LXDE (entorno de escritorio ligero)                      ║
║    ✓ Falkon (navegador web)                                   ║
║    ✓ ZRAM (optimización de memoria)                           ║
║    ✓ nano, vim, htop, sudo                                    ║
║                                                               ║
║  🔧 SCRIPTS DE UTILIDAD (en carpeta scripts/):                ║
║    • 01-configurar-red.sh → Configurar DESPUÉS de desplegar   ║
║                           (cambia hostname, IP, SSH, pass)    ║
║    • 02-info-sistema.sh   → Ver información del sistema       ║
║    • 03-limpiar-imagen.sh → Limpiar antes de capturar         ║
║    • EJECUTAR-LIMPIEZA.desktop → Acceso directo (doble clic)  ║
║                                                               ║
║  📝 FLUJO DE TRABAJO:                                         ║
║                                                               ║
║  ANTES DE CAPTURAR (Golden-VM original):                      ║
║    1. Personaliza el escritorio (fondos, iconos, etc.)        ║
║    2. Instala software adicional si es necesario              ║
║    3. Ejecuta: scripts/03-limpiar-imagen.sh                   ║
║    4. Apaga: sudo poweroff                                    ║
║    5. Captura desde el panel de FOG                           ║
║                                                               ║
║  DESPUÉS DE DESPLEGAR (en las VMs clonadas):                  ║
║    1. Inicia sesión (admin / AdminCEFIRE1234)                 ║
║    2. Ejecuta: scripts/01-configurar-red.sh                   ║
║    3. Cambia el hostname (ej: pc-aula1)                       ║
║    4. Cambia la IP (ej: 172.28.0.31+)                         ║
║    5. Reinicia: sudo reboot                                   ║
║                                                               ║
║  🌐 RED:                                                      ║
║    • Gateway: 172.28.0.1 (LabCEFIRE)                          ║
║    • FOG-Server: 172.28.0.30                                  ║
║    • Golden-VM: 172.28.0.31                                   ║
║    • PCs desplegados: 172.28.0.32 - 172.28.0.254              ║
║                                                               ║
╚═══════════════════════════════════════════════════════════════╝
EOF

# 4. Asegurar permisos para el usuario admin
chown -R admin:admin "$DESKTOP_DIR"

echo "✅ [GOLDEN] Scripts y LEEME listos en el escritorio"
