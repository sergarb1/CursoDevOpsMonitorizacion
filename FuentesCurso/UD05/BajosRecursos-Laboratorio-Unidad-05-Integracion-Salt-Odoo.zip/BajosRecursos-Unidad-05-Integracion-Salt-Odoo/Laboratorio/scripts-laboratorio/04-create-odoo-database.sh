#!/bin/bash
# 04-create-odoo-database.sh - CREACIÓN POR JSON-RPC (compatible Odoo 17)
# Versión para un solo Odoo (bajos recursos) con reinicio del exporter


# ------------------------------------------------------------------
# CONFIGURACIÓN (se puede sobreescribir con variables de entorno)
# ------------------------------------------------------------------
ODOO_HOST="${ODOO_HOST:-172.28.0.57}"
ODOO_PORT="${ODOO_PORT:-8069}"
MASTER_PWD="${MASTER_PWD:-admin}"
DB_NAME="${DB_NAME:-odoo_db}"
ADMIN_EMAIL="${ADMIN_EMAIL:-admin}"
ADMIN_PASSWORD="${ADMIN_PASSWORD:-admin}"
LANGUAGE="${LANGUAGE:-es_ES}"
COUNTRY="${COUNTRY:-ES}"

# Nombres de contenedores (ajústalos si cambian)
ODOO_CONTAINER="${ODOO_CONTAINER:-odoo-minion-1}"
PG_CONTAINER="${PG_CONTAINER:-odoo-pg1}"
PG_USER="${PG_USER:-odoo}"

# Colores mejorados
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
CYAN='\033[0;36m'
BLUE='\033[0;34m'
MAGENTA='\033[0;35m'
BOLD='\033[1m'
NC='\033[0m'

ok()   { echo -e "  ${GREEN}✓${NC} $1"; }
info() { echo -e "  ${CYAN}ℹ${NC} $1"; }
warn() { echo -e "  ${YELLOW}⚠${NC} $1"; }
err()  { echo -e "  ${RED}✗${NC} $1"; }
title() { echo -e "\n${BOLD}${MAGENTA}════════════════════════════════════════════════════════════════${NC}"; echo -e "${BOLD}${BLUE}  $1${NC}"; echo -e "${BOLD}${MAGENTA}════════════════════════════════════════════════════════════════${NC}"; }

# ------------------------------------------------------------------
# BARRA DE PROGRESO (con colores)
# ------------------------------------------------------------------
progress_bar() {
    local duration=$1
    local message=$2
    local width=50
    local elapsed=0
    echo -ne "  ${CYAN}${message} ${NC}["
    while [ $elapsed -lt $duration ]; do
        local percent=$((elapsed * 100 / duration))
        local filled=$((percent * width / 100))
        local empty=$((width - filled))
        printf "\r  ${CYAN}${message} ${NC}["
        printf "${GREEN}%${filled}s${NC}" | tr ' ' '#'
        printf "${YELLOW}%${empty}s${NC}" | tr ' ' '.'
        printf "] ${GREEN}%3d%%${NC}" $percent
        sleep 1
        elapsed=$((elapsed + 1))
    done
    printf "\r  ${CYAN}${message} ${NC}["
    printf "${GREEN}%${width}s${NC}" | tr ' ' '#'
    printf "] ${GREEN}100%%${NC}\n"
}

# ------------------------------------------------------------------
# GUÍA MANUAL (si falla la creación automática)
# ------------------------------------------------------------------
guia_manual() {
    echo ""
    echo -e "${YELLOW}════════════════════════════════════════════════════════════════${NC}"
    echo -e "${YELLOW}              CREACIÓN MANUAL DE BASE DE DATOS${NC}"
    echo -e "${YELLOW}════════════════════════════════════════════════════════════════${NC}"
    echo ""
    echo -e "  ${CYAN}1.${NC} Abre: ${GREEN}http://${ODOO_HOST}:${ODOO_PORT}/web/database/manager${NC}"
    echo -e "  ${CYAN}2.${NC} Master Password: ${GREEN}${MASTER_PWD}${NC}"
    echo -e "  ${CYAN}3.${NC} Database Name:   ${GREEN}${DB_NAME}${NC}"
    echo -e "  ${CYAN}4.${NC} Email:           ${GREEN}${ADMIN_EMAIL}${NC}"
    echo -e "  ${CYAN}5.${NC} Password:        ${GREEN}${ADMIN_PASSWORD}${NC}"
    echo -e "  ${CYAN}6.${NC} Language:        ${GREEN}Español${NC}"
    echo -e "  ${CYAN}7.${NC} Country:         ${GREEN}Spain${NC}"
    echo -e "  ${CYAN}8.${NC} Demo data:       ${GREEN}[X] MARCAR${NC}"
    echo -e "  ${CYAN}9.${NC} Click ${GREEN}[Continue]${NC}"
    echo ""
    echo -e "  URL final: ${GREEN}http://${ODOO_HOST}:${ODOO_PORT}/web/login?db=${DB_NAME}${NC}"
    echo ""
    echo -e "${YELLOW}════════════════════════════════════════════════════════════════${NC}"
}

# ------------------------------------------------------------------
# FUNCIÓN PARA REINICIAR EL ODOO EXPORTER (MEJORADA)
# ------------------------------------------------------------------
restart_odoo_exporter() {
    info "Reiniciando Odoo Exporter dentro del contenedor ${ODOO_CONTAINER}..."
    docker exec "$ODOO_CONTAINER" pkill -f odoo-exporter.py 2>/dev/null || true
    sleep 2
    docker exec "$ODOO_CONTAINER" pip3 install prometheus-client > /dev/null 2>&1 || true
    # Usar nohup dentro del contenedor
    docker exec "$ODOO_CONTAINER" bash -c "nohup python3 /opt/odoo-exporter.py --odoo-url 'http://localhost:8069' --db '${DB_NAME}' --user '${ADMIN_EMAIL}' --password '${ADMIN_PASSWORD}' --port 9090 > /tmp/odoo_exporter.log 2>&1 &"
    sleep 3
    if docker exec "$ODOO_CONTAINER" pgrep -f odoo-exporter.py >/dev/null; then
        ok "Odoo Exporter reiniciado correctamente"
    else
        warn "El Odoo Exporter no se reinició automáticamente. Revisa logs:"
        docker exec "$ODOO_CONTAINER" tail -5 /tmp/odoo_exporter.log 2>/dev/null | while read line; do echo "  $line"; done
    fi
}
# ------------------------------------------------------------------
# INICIO DEL SCRIPT
# ------------------------------------------------------------------
echo ""
echo -e "${BOLD}${BLUE}╔════════════════════════════════════════════════════════════════╗${NC}"
echo -e "${BOLD}${BLUE}║         CREACIÓN DE BASE DE DATOS ODOO (CON DEMO)           ║${NC}"
echo -e "${BOLD}${BLUE}╚════════════════════════════════════════════════════════════════╝${NC}"
echo ""
echo -e "  ${CYAN}Odoo:${NC}  http://${ODOO_HOST}:${ODOO_PORT}"
echo -e "  ${CYAN}BD:${NC}    ${DB_NAME}"
echo -e "  ${CYAN}Login:${NC} ${ADMIN_EMAIL} / ${ADMIN_PASSWORD}"
echo ""

# 1. Permisos CREATEDB
title "PASO 1/5 - Configurando PostgreSQL"
echo -n "  ${CYAN}→${NC} Dando permisos CREATEDB al usuario ${PG_USER}... "
docker exec -i "$PG_CONTAINER" psql -U "$PG_USER" -d postgres -c "ALTER USER ${PG_USER} CREATEDB;" >/dev/null 2>&1
echo -e "${GREEN} OK${NC}"
ok "Permisos CREATEDB configurados"

# 2. Esperar Odoo
title "PASO 2/5 - Esperando a Odoo"
MAX_WAIT=60
WAITED=0
while [ $WAITED -lt $MAX_WAIT ]; do
    HTTP_CODE=$(curl -s -o /dev/null -w "%{http_code}" --connect-timeout 3 "http://${ODOO_HOST}:${ODOO_PORT}" 2>/dev/null)
    if [ "$HTTP_CODE" = "200" ] || [ "$HTTP_CODE" = "302" ] || [ "$HTTP_CODE" = "303" ]; then
        ok "Odoo responde (HTTP $HTTP_CODE)"
        break
    fi
    sleep 2
    WAITED=$((WAITED + 2))
done
if [ $WAITED -ge $MAX_WAIT ]; then
    err "Odoo no respondió tras ${MAX_WAIT}s"
    guia_manual
    exit 1
fi

# 3. Comprobar BD existente
title "PASO 3/5 - Verificando base de datos existente"
DB_LIST=$(curl -s "http://${ODOO_HOST}:${ODOO_PORT}/web/database/list" 2>/dev/null)
if echo "$DB_LIST" | grep -q "\"${DB_NAME}\""; then
    warn "La base de datos '${DB_NAME}' ya existe. No se creará de nuevo."
    echo ""
    echo -e "  URL: ${GREEN}http://${ODOO_HOST}:${ODOO_PORT}/web/login?db=${DB_NAME}${NC}"
    exit 0
fi

# 4. Crear BD con JSON‑RPC
title "PASO 4/5 - Creando base de datos (JSON‑RPC)"
info "Esto puede tardar 2-3 minutos..."
JSON_DATA=$(cat <<EOF
{
    "jsonrpc": "2.0",
    "method": "call",
    "params": {
        "service": "db",
        "method": "create_database",
        "args": [
            "${MASTER_PWD}",
            "${DB_NAME}",
            true,
            "${LANGUAGE}",
            "${ADMIN_EMAIL}",
            "${ADMIN_PASSWORD}",
            "${COUNTRY}"
        ]
    }
}
EOF
)
RESP=$(curl -s -X POST "http://${ODOO_HOST}:${ODOO_PORT}/jsonrpc" \
    -H "Content-Type: application/json" \
    --connect-timeout 10 \
    --max-time 300 \
    -d "$JSON_DATA")
if echo "$RESP" | grep -q '"result":true' || echo "$RESP" | grep -q '"result": true'; then
    ok "Base de datos creada correctamente"
else
    sleep 5
    DB_LIST=$(curl -s "http://${ODOO_HOST}:${ODOO_PORT}/web/database/list" 2>/dev/null)
    if echo "$DB_LIST" | grep -q "\"${DB_NAME}\""; then
        ok "Base de datos verificada en la lista (creación confirmada)"
    else
        err "Fallo en la creación por JSON‑RPC"
        echo -e "  Respuesta: ${RED}$(echo "$RESP" | head -c 200)${NC}"
        guia_manual
        exit 1
    fi
fi

# 5. Instalación de módulos demo (2 minutos)
title "PASO 5/5 - Instalando módulos demo"
info "Este proceso puede tomar unos 2 minutos..."
progress_bar 120 "  Instalando módulos y datos demo"

# 6. Reiniciar Odoo Exporter
echo ""
restart_odoo_exporter

# 7. Verificar autenticación
title "VERIFICACIÓN FINAL"
info "Comprobando autenticación..."
sleep 10
AUTH=$(curl -s "http://${ODOO_HOST}:${ODOO_PORT}/jsonrpc" \
    -H "Content-Type: application/json" \
    -d "{
        \"jsonrpc\":\"2.0\",
        \"method\":\"call\",
        \"params\":{
            \"service\":\"common\",
            \"method\":\"authenticate\",
            \"args\":[\"${DB_NAME}\",\"${ADMIN_EMAIL}\",\"${ADMIN_PASSWORD}\",{}]
        }
    }")
if echo "$AUTH" | grep -q '"result":' && ! echo "$AUTH" | grep -q '"result":false'; then
    ok "Login verificado correctamente"
else
    warn "Login no verificado automáticamente (puede necesitar más tiempo)"
fi

# ------------------------------------------------------------------
# RESUMEN FINAL
# ------------------------------------------------------------------
echo ""
echo -e "${BOLD}${GREEN}╔════════════════════════════════════════════════════════════════╗${NC}"
echo -e "${BOLD}${GREEN}║                    🎉 ODOO LISTO 🎉                           ║${NC}"
echo -e "${BOLD}${GREEN}╚════════════════════════════════════════════════════════════════╝${NC}"
echo ""
echo -e "  ${CYAN}URL:${NC}      ${GREEN}http://${ODOO_HOST}:${ODOO_PORT}/web/login?db=${DB_NAME}${NC}"
echo -e "  ${CYAN}Usuario:${NC}  ${GREEN}${ADMIN_EMAIL}${NC}"
echo -e "  ${CYAN}Password:${NC} ${GREEN}${ADMIN_PASSWORD}${NC}"
echo -e "  ${CYAN}Demo:${NC}     ${GREEN}SÍ (datos de demostración instalados)${NC}"
echo ""
echo -e "  ${CYAN}Métricas Odoo:${NC} ${GREEN}http://${ODOO_HOST}:9090/metrics${NC}"
echo ""