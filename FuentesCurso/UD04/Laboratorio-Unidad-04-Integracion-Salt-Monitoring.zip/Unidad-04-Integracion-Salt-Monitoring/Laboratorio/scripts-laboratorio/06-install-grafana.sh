#!/bin/bash
# 06-install-grafana.sh - Instala el panel de visualización Grafana en vm-master.
# Grafana se conecta a Prometheus para mostrar los datos en forma de gráficas y dashboards.
set -euo pipefail

# Colores y Formato
RED='\033[0;31m'; GREEN='\033[0;32m'; YELLOW='\033[1;33m'; BLUE='\033[0;34m'; NC='\033[0m'
log()  { echo -e "${BLUE}[STEP]${NC} $1"; }
ok()   { echo -e "${GREEN}✓${NC} $1"; }
fail() { echo -e "${RED}✗${NC} $1"; }
warn() { echo -e "${YELLOW}⚠${NC} $1"; }

echo -e "${BLUE}╔═══════════════════════════════════════════════════════╗${NC}"
echo -e "${BLUE}║     UD04 - Instalación de Grafana                     ║${NC}"
echo -e "${BLUE}║     (Plataforma de Visualización y Observabilidad)    ║${NC}"
echo -e "${BLUE}╚═══════════════════════════════════════════════════════╝${NC}"

docker inspect vm-master &>/dev/null || { fail "vm-master no encontrado"; exit 1; }

# ---------- GRAFANA ----------
# Grafana requiere una base de datos interna (SQLite por defecto) para guardar usuarios y dashboards.
# El proceso de arranque inicial puede tardar mientras se crean las tablas de la BD.
check_grafana() {
    docker exec vm-master bash -c 'curl -sf http://localhost:3000/api/health > /dev/null 2>&1' 2>/dev/null
}

if check_grafana; then
    ok "Grafana: Ya está operativo en el puerto 3000."
else
    log "Instalando servidor Grafana (vía OSS)..."
    docker exec vm-master bash -c '
        export DEBIAN_FRONTEND=noninteractive
        bash /opt/scripts/lib/07-grafana.sh
    '
    # Grafana tarda un poco más que otros servicios en estar listo (migraciones de BD).
    log "Esperando a que Grafana inicialice sus servicios internos..."
    sleep 8
    
    if check_grafana; then
        ok "Grafana: Instalado y en ejecución."
    else
        warn "Grafana: Aún arrancando. Podrás acceder en unos segundos a http://172.28.0.40:3000"
    fi
fi

echo -e "\n${YELLOW}Nota Didáctica:${NC} Grafana es 'agnóstico' a los datos; puede visualizar métricas de Prometheus, logs de Loki o trazas de Tempo."
echo ""
