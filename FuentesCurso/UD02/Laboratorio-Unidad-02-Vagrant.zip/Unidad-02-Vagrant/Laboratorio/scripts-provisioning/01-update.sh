#!/bin/bash
# 01-update.sh - Actualización de repositorios
set -e
GREEN='\033[0;32m'; BLUE='\033[0;34m'; NC='\033[0m'

echo -e "${BLUE}[PROVISIÓN]${NC} Actualizando índices de paquetes (apt-get update)..."
apt-get update -qq
echo -e "${GREEN}✓${NC} Repositorios actualizados."
