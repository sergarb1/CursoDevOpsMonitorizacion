#!/bin/bash
# check-status.sh - Verifica el estado de todos los servicios (versión conservadora)
set -e

RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
CYAN='\033[0;36m'
NC='\033[0m'

# Barra de progreso
progress_bar() {
    local duration=$1
    local message=$2
    local width=40
    local elapsed=0
    
    echo -ne "${CYAN}${message} ${NC}["
    
    while [ $elapsed -lt $duration ]; do
        local percent=$((elapsed * 100 / duration))
        local filled=$((percent * width / 100))
        local empty=$((width - filled))
        
        printf "\r${CYAN}${message} ${NC}["
        printf "${GREEN}%${filled}s${NC}" | tr ' ' '#'
        printf "${YELLOW}%${empty}s${NC}" | tr ' ' '.'
        printf "] ${GREEN}%3d%%${NC}" $percent
        
        sleep 1
        elapsed=$((elapsed + 1))
    done
    
    printf "\r${CYAN}${message} ${NC}["
    printf "${GREEN}%${width}s${NC}" | tr ' ' '#'
    printf "] ${GREEN}100%%${NC}\n"
}

# Función para verificar servicio con reintentos y espera
check_service_with_retry() {
    local name=$1
    local url=$2
    local wait_time=$3
    local max_attempts=4
    local attempt=1
    
    echo -n "  $name: "
    
    while [ $attempt -le $max_attempts ]; do
        local http_code=$(curl -s -o /dev/null -w "%{http_code}" "$url" 2>/dev/null)
        
        if [[ "$name" == "cAdvisor" ]]; then
            # Aceptar también 307 (Temporary Redirect)
            if [[ "$http_code" =~ ^(200|301|302|303|304|307|308)$ ]]; then
                echo -e "\r  ${GREEN}✓${NC} $name: $url (HTTP $http_code)                    "
                return 0
            fi
        else
            if [[ "$http_code" =~ ^(200|301|302|303|500|503)$ ]]; then
                echo -e "\r  ${GREEN}✓${NC} $name: $url (HTTP $http_code)                    "
                return 0
            fi
        fi
        
        if [ $attempt -eq 1 ]; then
            echo ""
            progress_bar $wait_time "  ⏳ Esperando $name (intento $attempt/$max_attempts)"
        else
            progress_bar $wait_time "  🔄 Reintentando $name (intento $attempt/$max_attempts)"
        fi
        
        attempt=$((attempt + 1))
    done
    
    echo -e "\r  ${YELLOW}⏳${NC} $name: $url (iniciando)      "
    return 1
}

# Función específica para cAdvisor (con follow redirects)
check_cadvisor() {
    local max_retries=4
    local retry=0
    
    while [ $retry -lt $max_retries ]; do
        # Usar curl con -L para seguir redirecciones automáticamente
        if curl -s -f -L "http://172.28.0.52:8080/" >/dev/null 2>&1; then
            return 0
        fi
        if curl -s -f -L "http://172.28.0.52:8080/containers/" >/dev/null 2>&1; then
            return 0
        fi
        sleep 2
        retry=$((retry + 1))
    done
    return 1
}

# Función específica para PostgreSQL
check_postgres() {
    local max_retries=4
    local retry=0
    
    while [ $retry -lt $max_retries ]; do
        if docker exec odoo-pg1 pg_isready -U odoo >/dev/null 2>&1; then
            return 0
        fi
        sleep 2
        retry=$((retry + 1))
    done
    return 1
}

# Función específica para Salt Master (mejorada)
check_salt_master() {
    local max_retries=4
    local retry=0
    
    while [ $retry -lt $max_retries ]; do
        # Buscar el proceso salt-master (puede ejecutarse como salt, no solo root)
        if docker exec ud05-salt-master pgrep -x "salt-master" >/dev/null 2>&1; then
            return 0
        fi
        # Buscar también como usuario salt
        if docker exec ud05-salt-master pgrep -x -u salt "salt-master" >/dev/null 2>&1; then
            return 0
        fi
        # Buscar en los procesos de todos los usuarios
        if docker exec ud05-salt-master ps aux | grep -q "[s]alt-master"; then
            return 0
        fi
        sleep 3
        retry=$((retry + 1))
    done
    return 1
}

# Cabecera
echo -e "${BLUE}════════════════════════════════════════════════════════════════${NC}"
echo -e "${BLUE}              ESTADO DE LA INFRAESTRUCTURA                       ${NC}"
echo -e "${BLUE}════════════════════════════════════════════════════════════════${NC}"
echo ""

# Verificar contenedores
echo -e "${BLUE}📦 Contenedores:${NC}"
containers=("ud05-salt-master" "odoo-pg1" "odoo-minion-1" "odoo-prometheus" "odoo-grafana" "odoo-cadvisor" "odoo-blackbox")

for container in "${containers[@]}"; do
    if docker ps --format '{{.Names}}' | grep -q "^${container}$"; then
        echo -e "  ${GREEN}✓${NC} $container"
    else
        echo -e "  ${RED}✗${NC} $container"
    fi
done

echo ""
echo -e "${BLUE}🌐 Servicios Web:${NC}"

# Verificar servicios
check_service_with_retry "Odoo" "http://172.28.0.57:8069" 15
check_service_with_retry "Grafana" "http://172.28.0.56:3000" 10
check_service_with_retry "Prometheus" "http://172.28.0.51:9090" 10

# Verificar cAdvisor
echo -n "  cAdvisor: "
if check_cadvisor; then
    echo -e "\r  ${GREEN}✓${NC} cAdvisor: http://172.28.0.52:8080                         "
else
    echo -e "\r  ${YELLOW}⏳${NC} cAdvisor: http://172.28.0.52:8080 (iniciando)            "
fi

echo ""
echo -e "${BLUE}🔧 Salt Stack:${NC}"
if check_salt_master; then
    echo -e "  ${GREEN}✓${NC} Salt Master está ejecutándose"
    minions=$(docker exec ud05-salt-master salt-key --list-all 2>/dev/null | grep -c "accepted" || echo "0")
    echo -e "  ${GREEN}✓${NC} Minions aceptados: $minions"
    if [ $minions -gt 0 ]; then
        echo -e "  ${CYAN}→${NC} Minions:"
        docker exec ud05-salt-master salt-key --list-all 2>/dev/null | grep "accepted" | sed 's/^/    /' || true
    fi
else
    echo -e "  ${RED}✗${NC} Salt Master no está ejecutándose"
    echo -e "  ${YELLOW}→${NC} Verifica con: docker logs ud05-salt-master --tail 20"
fi

echo ""
echo -e "${BLUE}🐘 PostgreSQL:${NC}"
if check_postgres; then
    echo -e "  ${GREEN}✓${NC} PostgreSQL está listo"
else
    echo -e "  ${RED}✗${NC} PostgreSQL no responde"
fi

echo ""
echo -e "${BLUE}📊 Exporters (integrados en Odoo):${NC}"
if docker exec odoo-minion-1 pgrep -x "node_exporter" >/dev/null 2>&1; then
    echo -e "  ${GREEN}✓${NC} Node Exporter activo"
else
    echo -e "  ${YELLOW}⏳${NC} Node Exporter iniciando..."
fi

if docker exec odoo-minion-1 pgrep -f "odoo-exporter.py" >/dev/null 2>&1; then
    echo -e "  ${GREEN}✓${NC} Odoo Exporter activo"
else
    echo -e "  ${YELLOW}⏳${NC} Odoo Exporter iniciando..."
fi

if docker exec odoo-minion-1 pgrep -x "salt-minion" >/dev/null 2>&1; then
    echo -e "  ${GREEN}✓${NC} Salt Minion activo"
else
    echo -e "  ${YELLOW}⏳${NC} Salt Minion iniciando..."
fi

echo ""
echo -e "${YELLOW}📝 Notas:${NC}"
echo -e "   • Si Odoo no responde, espera 1-2 minutos mas"
echo -e "   • Logs Odoo: docker logs -f odoo-minion-1"
echo -e "   • Logs Salt: docker logs -f ud05-salt-master"
echo -e "   • Logs cAdvisor: docker logs -f odoo-cadvisor"
echo ""
echo -e "${GREEN}════════════════════════════════════════════════════════════════${NC}"