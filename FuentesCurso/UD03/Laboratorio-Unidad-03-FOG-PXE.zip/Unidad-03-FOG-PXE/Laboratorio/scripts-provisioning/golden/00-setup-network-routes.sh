#!/bin/bash
# 00-setup-network-routes.sh - Configurar rutas de red para Golden-VM
# El bridge es para FOG, NAT es para internet

set -e

echo "=========================================="
echo "🌐 [GOLDEN] Configurando rutas de red..."
echo "=========================================="

# Identificar interfaces
BRIDGE_IF=$(ip route | grep "172.28.0.0/24" | awk '{print $1}')
NAT_IF=$(ip route | grep "default" | awk '{print $5}' | head -1)

echo "Bridge interface: $BRIDGE_IF"
echo "NAT interface: $NAT_IF"

# Si no hay ruta por defecto, añadirla por NAT
if ! ip route | grep -q "^default"; then
    echo "Añadiendo ruta por defecto por NAT..."
    ip route add default via 10.0.2.2 dev $NAT_IF 2>/dev/null || true
fi

# DNS de Google como backup
if ! grep -q "8.8.8.8" /etc/resolv.conf; then
    echo "nameserver 8.8.8.8" >> /etc/resolv.conf
fi

echo "✅ Rutas configuradas"
ip route show
