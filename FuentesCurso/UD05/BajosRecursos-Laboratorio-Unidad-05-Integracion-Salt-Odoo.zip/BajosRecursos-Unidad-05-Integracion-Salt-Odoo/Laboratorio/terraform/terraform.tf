# Terraform Configuration - UD05 Salt + Odoo + Monitoring (Optimizado 8GB RAM)
# Node Exporter solo en Odoo y Salt Master

terraform {
  required_providers {
    docker = {
      source  = "kreuzwerker/docker"
      version = "~> 3.0"
    }
  }
}

provider "docker" {}

# =============================================================================
# LOCALS - Rutas relativas desde terraform/ a los recursos
# =============================================================================
locals {
  # path.module = ./terraform  ->  nos movemos un nivel arriba para llegar a Laboratorio
  lab_base_path = abspath("${path.module}/..")
}

# =============================================================================
# VARIABLES
# =============================================================================
variable "odoo_image" {
  description = "Imagen de Odoo"
  type        = string
  default     = "odoo:17"
}

variable "postgres_image" {
  description = "Imagen de PostgreSQL"
  type        = string
  default     = "postgres:15"
}

# =============================================================================
# RED EXISTENTE
# =============================================================================
data "docker_network" "ud05_net" {
  name = "LabCEFIRE"
}

# =============================================================================
# VOLÚMENES PERSISTENTES
# =============================================================================
resource "docker_volume" "odoo_pgsql_1" { name = "ud05_odoo_pgsql_1" }
resource "docker_volume" "odoo_data_1"   { name = "ud05_odoo_data_1" }
resource "docker_volume" "prometheus_data" { name = "ud05_prometheus_data" }
resource "docker_volume" "grafana_data"   { name = "ud05_grafana_data" }

# =============================================================================
# POSTGRESQL
# =============================================================================
resource "docker_container" "pg1" {
  name     = "odoo-pg1"
  image    = var.postgres_image
  memory   = 512
  hostname = "odoo-pg1"
  user     = "root"
  init     = true
  restart  = "unless-stopped"
  networks_advanced {
    name         = data.docker_network.ud05_net.name
    ipv4_address = "172.28.0.59"
  }
  env = [
    "POSTGRES_USER=odoo",
    "POSTGRES_PASSWORD=odoo",
    "POSTGRES_DB=postgres"
  ]
  volumes {
    volume_name    = docker_volume.odoo_pgsql_1.name
    container_path = "/var/lib/postgresql/data"
  }
  upload {
    source     = "${local.lab_base_path}/docker/startup-postgres.sh"
    file       = "/opt/startup-postgres.sh"
    executable = true
  }
  entrypoint = ["bash", "/opt/startup-postgres.sh"]
  healthcheck {
    test     = ["CMD-SHELL", "pg_isready -U odoo"]
    interval = "10s"
    timeout  = "5s"
    retries  = 5
  }
}

# =============================================================================
# ODOO MINION (con Node Exporter y Odoo Exporter)
# =============================================================================
resource "docker_container" "odoo_minion_1" {
  name     = "odoo-minion-1"
  image    = var.odoo_image
  memory   = 1024
  hostname = "odoo-minion-1"
  user     = "root"
  init     = true
  restart  = "unless-stopped"
  networks_advanced {
    name         = data.docker_network.ud05_net.name
    ipv4_address = "172.28.0.57"
  }
  dns = ["8.8.8.8", "8.8.4.4"]
  env = [
    "POSTGRES_HOST=172.28.0.59",
    "POSTGRES_USER=odoo",
    "POSTGRES_PASSWORD=odoo",
    "ODOO_ADMIN_USER=admin",
    "ODOO_ADMIN_PASSWORD=admin",
    "ODOO_DB_NAME=odoo_db",
    "EXPORTER_PORT=9090"
  ]
  volumes {
    volume_name    = docker_volume.odoo_data_1.name
    container_path = "/var/lib/odoo"
  }
  volumes {
    host_path      = "${local.lab_base_path}/config/odoo-1.conf"
    container_path = "/etc/odoo/odoo.conf"
  }
  # Node Exporter binario
  upload {
    source     = "${local.lab_base_path}/docker/bin/node_exporter"
    file       = "/usr/local/bin/node_exporter"
    executable = true
  }
  # Odoo Exporter
  upload {
    source = "${local.lab_base_path}/docker/odoo-exporter/odoo-exporter.py"
    file   = "/opt/odoo-exporter.py"
  }
  # Script de arranque
  upload {
    source     = "${local.lab_base_path}/docker/startup-odoo.sh"
    file       = "/opt/startup-odoo.sh"
    executable = true
  }
  depends_on = [docker_container.pg1]
  entrypoint = ["/bin/bash", "/opt/startup-odoo.sh"]
  healthcheck {
    test     = ["CMD-SHELL", "curl -f http://localhost:8069/web/login || exit 1"]
    interval = "30s"
    timeout  = "10s"
    retries  = 5
    start_period = "60s"
  }
}

# =============================================================================
# SALT MASTER (con Node Exporter)
# =============================================================================
resource "docker_container" "vm_master" {
  name     = "ud05-salt-master"
  image    = "ubuntu:24.04"
  memory   = 512
  hostname = "salt-master"
  user     = "root"
  init     = true
  restart  = "unless-stopped"
  networks_advanced {
    name         = data.docker_network.ud05_net.name
    ipv4_address = "172.28.0.50"
  }
  dns      = ["8.8.8.8", "8.8.4.4"]
  capabilities { add = ["NET_ADMIN"] }
  upload {
    source     = "${local.lab_base_path}/docker/bin/node_exporter"
    file       = "/usr/local/bin/node_exporter"
    executable = true
  }
  upload {
    source     = "${local.lab_base_path}/docker/startup-salt-master.sh"
    file       = "/opt/startup-salt-master.sh"
    executable = true
  }
  entrypoint = ["bash", "/opt/startup-salt-master.sh"]
  healthcheck {
    test     = ["CMD-SHELL", "pgrep -x salt-master || exit 1"]
    interval = "30s"
    timeout  = "10s"
    retries  = 3
  }
}

# =============================================================================
# MONITORING: Prometheus
# =============================================================================
resource "docker_container" "prometheus" {
  name     = "odoo-prometheus"
  image    = "prom/prometheus:v2.51.0"
  memory   = 512
  hostname = "odoo-prometheus"
  user     = "root"
  init     = true
  restart  = "unless-stopped"
  networks_advanced {
    name         = data.docker_network.ud05_net.name
    ipv4_address = "172.28.0.51"
  }
  ports {
    internal = 9090
    external = 9090
  }
  volumes {
    volume_name    = docker_volume.prometheus_data.name
    container_path = "/prometheus"
  }
  upload {
    source = "${local.lab_base_path}/docker/prometheus/prometheus-odoo.yml"
    file   = "/etc/prometheus/prometheus.yml"
  }
  upload {
    source     = "${local.lab_base_path}/docker/startup-monitoring.sh"
    file       = "/opt/startup-monitoring.sh"
    executable = true
  }
  entrypoint = ["sh", "/opt/startup-monitoring.sh", "Prometheus", "/bin/prometheus --config.file=/etc/prometheus/prometheus.yml --storage.tsdb.path=/prometheus"]
}

# =============================================================================
# MONITORING: Grafana
# =============================================================================
resource "docker_container" "grafana" {
  name     = "odoo-grafana"
  image    = "grafana/grafana:10.4.0"
  memory   = 256
  hostname = "odoo-grafana"
  user     = "root"
  init     = true
  restart  = "unless-stopped"
  networks_advanced {
    name         = data.docker_network.ud05_net.name
    ipv4_address = "172.28.0.56"
  }
  ports {
    internal = 3000
    external = 3000
  }
  env = [
    "GF_SECURITY_ADMIN_USER=admin",
    "GF_SECURITY_ADMIN_PASSWORD=admin"
  ]
  upload {
    source = "${local.lab_base_path}/docker/grafana/datasources.yml"
    file   = "/etc/grafana/provisioning/datasources/datasources.yml"
  }
  upload {
    source = "${local.lab_base_path}/docker/grafana/dashboards.yml"
    file   = "/etc/grafana/provisioning/dashboards/dashboards.yml"
  }
  volumes {
    host_path      = "${local.lab_base_path}/docker/grafana/dashboards"
    container_path = "/var/lib/grafana/dashboards"
  }
  upload {
    source     = "${local.lab_base_path}/docker/startup-monitoring.sh"
    file       = "/opt/startup-monitoring.sh"
    executable = true
  }
  entrypoint = ["bash", "/opt/startup-monitoring.sh", "Grafana", "/run.sh"]
}

# =============================================================================
# MONITORING: cAdvisor
# =============================================================================
resource "docker_container" "cadvisor" {
  name     = "odoo-cadvisor"
  image    = "gcr.io/cadvisor/cadvisor:latest"
  memory   = 256
  hostname = "odoo-cadvisor"
  user     = "root"
  privileged = true
  init     = true
  restart  = "unless-stopped"
  networks_advanced {
    name         = data.docker_network.ud05_net.name
    ipv4_address = "172.28.0.52"
  }
  ports {
    internal = 8080
    external = 8080
  }
  volumes {
    host_path      = "/"
    container_path = "/rootfs"
    read_only      = true
  }
  volumes {
    host_path      = "/var/run"
    container_path = "/var/run"
  }
  volumes {
    host_path      = "/sys"
    container_path = "/sys"
    read_only      = true
  }
  volumes {
    host_path      = "/var/lib/docker"
    container_path = "/var/lib/docker"
    read_only      = true
  }
  upload {
    source     = "${local.lab_base_path}/docker/startup-monitoring.sh"
    file       = "/opt/startup-monitoring.sh"
    executable = true
  }
  entrypoint = ["sh", "/opt/startup-monitoring.sh", "cAdvisor", "/usr/bin/cadvisor -logtostderr --docker_only"]
}

# =============================================================================
# MONITORING: Blackbox Exporter
# =============================================================================
resource "docker_container" "blackbox_exporter" {
  name     = "odoo-blackbox"
  image    = "prom/blackbox-exporter:v0.25.0"
  memory   = 128
  hostname = "odoo-blackbox"
  user     = "root"
  init     = true
  restart  = "unless-stopped"
  networks_advanced {
    name         = data.docker_network.ud05_net.name
    ipv4_address = "172.28.0.53"
  }
  ports {
    internal = 9115
    external = 9115
  }
  upload {
    source = "${local.lab_base_path}/docker/prometheus/blackbox-config.yml"
    file   = "/etc/blackbox/blackbox.yml"
  }
  upload {
    source     = "${local.lab_base_path}/docker/startup-monitoring.sh"
    file       = "/opt/startup-monitoring.sh"
    executable = true
  }
  entrypoint = ["sh", "/opt/startup-monitoring.sh", "Blackbox", "/bin/blackbox_exporter --config.file=/etc/blackbox/blackbox.yml"]
}

# =============================================================================
# OUTPUTS
# =============================================================================
output "infrastructure_summary" {
  value = <<EOT

╔══════════════════════════════════════════════════════════════════════════════╗
║              🎉 INFRAESTRUCTURA OPTIMIZADA (Límite 8GB RAM)                 ║
╚══════════════════════════════════════════════════════════════════════════════╝

  📊 Consumo estimado: ~3.1 GB RAM

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

📍 IPs Asignadas:
   • Salt Master:    172.28.0.50
   • Prometheus:     172.28.0.51
   • cAdvisor:       172.28.0.52
   • Blackbox:       172.28.0.53
   • Grafana:        172.28.0.56
   • Odoo 1:         172.28.0.57
   • PostgreSQL 1:   172.28.0.59

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

🌐 Acceso Web (Puertos expuestos):

   • Odoo 17:        http://172.28.0.57:8069  (o http://localhost:8069)
   • Grafana:        http://172.28.0.56:3000  (o http://localhost:3000)
   • Prometheus:     http://172.28.0.51:9090  (o http://localhost:9090)
   • cAdvisor:       http://172.28.0.52:8080  (o http://localhost:8080)
   • Blackbox:       http://172.28.0.53:9115  (o http://localhost:9115)

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

🔑 CREDENCIALES:

   • Odoo 17:        usuario: admin     contraseña: admin
   • Grafana:        usuario: admin     contraseña: admin

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

📝 NOTAS IMPORTANTES:

   • Los Salt Minions (Odoo) se conectarán automáticamente al Master (172.28.0.50)
   • Node Exporter (métricas de sistema) está activo solo en Odoo y Salt Master
   • Odoo Exporter (métricas de negocio) está integrado en Odoo
   • La base de datos se crea automáticamente al primer arranque (datos demo incluidos)
   • Si algún servicio no responde, espera 1-2 minutos más

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

EOT
}