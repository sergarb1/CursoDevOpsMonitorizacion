#!/bin/bash
# 01-setup-network.sh - Crea la red Docker compartida LabCEFIRE
# ============================================================
set -euo pipefail

# ── Colores ──
BOLD='\033[1m'
RED='\033[0;31m'; GREEN='\033[0;32m'; YELLOW='\033[1;33m'
BLUE='\033[0;34m'; CYAN='\033[0;36m'; NC='\033[0m'
CHECK="${GREEN}✓${NC}"; CROSS="${RED}✗${NC}"; INFO="${CYAN}ℹ${NC}"

# ── Barra de progreso ──
progress_bar() {
    local duration=$1
    local message=$2
    local width=40
    local elapsed=0
    
    echo -ne "${CYAN}${message} ${NC}["
    
    while [ $elapsed -lt $duration ]; do
        local percent=$((elapsed * 100 / duration))
        local filled=$((percent * width / 100))
        local empty=$((width - filled))
        
        printf "\r${CYAN}${message} ${NC}["
        printf "${GREEN}%${filled}s${NC}" | tr ' ' '#'
        printf "${YELLOW}%${empty}s${NC}" | tr ' ' '.'
        printf "] ${GREEN}%3d%%${NC}" $percent
        
        sleep 1
        elapsed=$((elapsed + 1))
    done
    
    printf "\r${CYAN}${message} ${NC}["
    printf "${GREEN}%${width}s${NC}" | tr ' ' '#'
    printf "] ${GREEN}100%%${NC}\n"
}

echo -e "${BLUE}${BOLD}"
echo "╔══════════════════════════════════════════════════════════════╗"
echo "║   🌐 UD06 - Paso 1: Red LabCEFIRE (El Puente Virtual)     ║"
echo "╚══════════════════════════════════════════════════════════════╝"
echo -e "${NC}"

echo -e "${YELLOW}${BOLD}📘 ¿Qué vamos a hacer?${NC}"
echo "  Crearemos un segmento de red aislado (172.28.0.0/24) donde"
echo "  convivirán Jenkins, Gitea, Prometheus, Grafana y nuestra app."
echo "  Es como construir la 'carretera' antes de poner los coches."
echo ""

NETWORK_NAME="LabCEFIRE"
SUBNET="172.28.0.0/24"
GATEWAY="172.28.0.1"

echo -e "${BLUE}${BOLD}[1/2]${NC} Verificando si la red '${NETWORK_NAME}' ya existe..."

if docker network inspect "$NETWORK_NAME" >/dev/null 2>&1; then
    echo -e "  ${INFO} La red '${NETWORK_NAME}' ya existe. No hay nada que hacer."
else
    echo -e "  ${INFO} No encontrada. Creando red '${NETWORK_NAME}'..."
    progress_bar 5 "Creando red Docker"
    docker network create \
      --driver bridge \
      --subnet "$SUBNET" \
      --gateway "$GATEWAY" \
      --label "proyecto=ud06" \
      "$NETWORK_NAME"
    echo -e "  ${CHECK} Red '${NETWORK_NAME}' creada correctamente."
fi

echo -e "${BLUE}${BOLD}[2/2]${NC} Verificando conectividad..."
echo ""

NET_ID=$(docker network ls --filter name="$NETWORK_NAME" --format "{{.ID}}")
echo -e "  ${INFO} ID de red: ${CYAN}${NET_ID}${NC}"
SUBNET_OK=$(docker network inspect "$NETWORK_NAME" --format "{{range .IPAM.Config}}{{.Subnet}}{{end}}")
echo -e "  ${INFO} Subred:    ${CYAN}${SUBNET_OK}${NC}"
echo ""

echo -e "${GREEN}${BOLD}✅ ¡Red LabCEFIRE operativa!${NC}"
echo ""
echo -e "  ${CYAN}Resumen de red:${NC}"
docker network ls --filter name="$NETWORK_NAME" --format "table {{.Name}}\t{{.Driver}}\t{{.Scope}}"
echo ""
echo -e "${YELLOW}${BOLD}📘 ¿Qué acabamos de hacer?${NC}"
echo -e "  Hemos creado la red virtual ${BOLD}LabCEFIRE${NC} (subred 172.28.0.0/24)."
echo -e "  Todos los contenedores del laboratorio se conectarán a esta red"
echo -e "  con IPs fijas, como si estuvieran en su propia oficina."
echo ""
echo -e "${YELLOW}${BOLD}🏗️  ¿Qué contiene esta red (cuando esté completa)?${NC}"
echo -e "  ${CYAN}172.28.0.61${NC} — Jenkins        (CI/CD — orquestador)"
echo -e "  ${CYAN}172.28.0.62${NC} — Staging        (app — pruebas)"
echo -e "  ${CYAN}172.28.0.63${NC} — Producción     (app — usuarios reales)"
echo -e "  ${CYAN}172.28.0.64${NC} — Gitea          (código fuente)"
echo -e "  ${CYAN}172.28.0.65${NC} — Prometheus     (métricas)"
echo -e "  ${CYAN}172.28.0.66${NC} — Grafana        (visualización)"
echo -e "  ${CYAN}172.28.0.67${NC} — cAdvisor       (monitor Docker)"
echo ""
echo -e "${YELLOW}${BOLD}🔍 COMPROBACIONES:${NC}"
echo -e "  docker network ls        → debe aparecer ${BOLD}LabCEFIRE${NC}"
echo -e "  docker network inspect LabCEFIRE  → muestra subred 172.28.0.0/24"
echo ""
echo -e "${YELLOW}${BOLD}💡 Dato didáctico — Staging vs Producción:${NC}"
echo -e "  Cuando despleguemos la app, ten en cuenta:"
echo -e "    • ${BOLD}Staging${NC} (172.28.0.62) → aquí llega PRIMERO el código"
echo -e "    • ${BOLD}Producción${NC} (172.28.0.63) → aquí llega TRAS aprobación"
echo -e "  Este \"viaje en dos etapas\" es un patrón CI/CD clásico:"
echo -e "  primero pruebas en staging, luego despliegas a producción."
echo ""
echo -e "${YELLOW}${BOLD}🔐 Credenciales del laboratorio (próximos pasos):${NC}"
echo -e "    ${BOLD}Jenkins:${NC} admin / admin  (en paso 03 se despliega)"
echo -e "    ${BOLD}Gitea:${NC}   gitea-admin / admin  (en paso 03)"
echo -e "    ${BOLD}Grafana:${NC} admin / admin  (en paso 03)"
echo ""

echo -e "  ${YELLOW}💡 Próximo paso:${NC} bash 02-pull-images.sh"
echo ""
