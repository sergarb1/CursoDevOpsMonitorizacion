const express = require('express');
const router = express.Router();

// In-memory data store
const projects = [
  { id: 1, name: 'Backend API', status: 'active', builds: 42, lastBuild: 'success' },
  { id: 2, name: 'Frontend App', status: 'active', builds: 38, lastBuild: 'success' },
  { id: 3, name: 'Mobile App', status: 'active', builds: 15, lastBuild: 'failed' }
];

const builds = [
  { id: 1, project: 'Backend API', status: 'success', duration: 45, timestamp: '2026-04-05T10:00:00Z' },
  { id: 2, project: 'Frontend App', status: 'success', duration: 62, timestamp: '2026-04-05T10:15:00Z' },
  { id: 3, project: 'Mobile App', status: 'failed', duration: 30, timestamp: '2026-04-05T10:30:00Z' }
];

// Dashboard
router.get('/', (req, res) => {
  const html = `
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>DevOps Dashboard</title>
  <style>
    * { margin: 0; padding: 0; box-sizing: border-box; }
    body { font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; background: #0d1117; color: #c9d1d9; }
    .header { background: #161b22; padding: 20px; border-bottom: 1px solid #30363d; }
    .header h1 { color: #58a6ff; }
    .container { max-width: 1200px; margin: 0 auto; padding: 20px; }
    .stats { display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 16px; margin-bottom: 24px; }
    .stat-card { background: #161b22; border: 1px solid #30363d; border-radius: 6px; padding: 16px; }
    .stat-card h3 { color: #8b949e; font-size: 14px; margin-bottom: 8px; }
    .stat-card .value { font-size: 32px; font-weight: bold; }
    .stat-card .value.success { color: #3fb950; }
    .stat-card .value.failed { color: #f85149; }
    .projects, .builds { background: #161b22; border: 1px solid #30363d; border-radius: 6px; padding: 16px; margin-bottom: 24px; }
    table { width: 100%; border-collapse: collapse; }
    th, td { padding: 12px; text-align: left; border-bottom: 1px solid #21262d; }
    th { color: #8b949e; font-weight: 600; }
    .status { padding: 4px 8px; border-radius: 12px; font-size: 12px; font-weight: 500; }
    .status.success { background: #1a4731; color: #3fb950; }
    .status.failed { background: #4d1f21; color: #f85149; }
    .status.active { background: #1a4731; color: #3fb950; }
  </style>
</head>
<body>
  <div class="header">
    <h1>🚀 DevOps CI/CD Dashboard</h1>
    <p>Real-time monitoring of builds and deployments</p>
  </div>
  <div class="container">
    <div class="stats">
      <div class="stat-card">
        <h3>Total Projects</h3>
        <div class="value">${projects.length}</div>
      </div>
      <div class="stat-card">
        <h3>Successful Builds</h3>
        <div class="value success">${builds.filter(b => b.status === 'success').length}</div>
      </div>
      <div class="stat-card">
        <h3>Failed Builds</h3>
        <div class="value failed">${builds.filter(b => b.status === 'failed').length}</div>
      </div>
      <div class="stat-card">
        <h3>Avg Build Time</h3>
        <div class="value">${Math.round(builds.reduce((a, b) => a + b.duration, 0) / builds.length)}s</div>
      </div>
    </div>
    
    <div class="projects">
      <h2 style="margin-bottom: 16px;">📦 Projects</h2>
      <table>
        <thead><tr><th>Name</th><th>Status</th><th>Builds</th><th>Last Build</th></tr></thead>
        <tbody>
          ${projects.map(p => `
            <tr>
              <td>${p.name}</td>
              <td><span class="status ${p.status}">${p.status}</span></td>
              <td>${p.builds}</td>
              <td><span class="status ${p.lastBuild}">${p.lastBuild}</span></td>
            </tr>
          `).join('')}
        </tbody>
      </table>
    </div>
    
    <div class="builds">
      <h2 style="margin-bottom: 16px;">🔨 Recent Builds</h2>
      <table>
        <thead><tr><th>ID</th><th>Project</th><th>Status</th><th>Duration</th><th>Time</th></tr></thead>
        <tbody>
          ${builds.map(b => `
            <tr>
              <td>#${b.id}</td>
              <td>${b.project}</td>
              <td><span class="status ${b.status}">${b.status}</span></td>
              <td>${b.duration}s</td>
              <td>${b.timestamp}</td>
            </tr>
          `).join('')}
        </tbody>
      </table>
    </div>
  </div>
</body>
</html>`;
  res.send(html);
});

// API: Projects
router.get('/api/projects', (req, res) => {
  res.json(projects);
});

router.post('/api/projects', (req, res) => {
  const { name } = req.body;
  if (!name) return res.status(400).json({ error: 'Name is required' });
  
  const newProject = {
    id: projects.length + 1,
    name,
    status: 'active',
    builds: 0,
    lastBuild: 'pending'
  };
  projects.push(newProject);
  res.status(201).json(newProject);
});

// API: Builds
router.get('/api/builds', (req, res) => {
  res.json(builds);
});

router.post('/api/builds', (req, res) => {
  const { project } = req.body;
  if (!project) return res.status(400).json({ error: 'Project is required' });
  
  const newBuild = {
    id: builds.length + 1,
    project,
    status: 'pending',
    duration: 0,
    timestamp: new Date().toISOString()
  };
  builds.unshift(newBuild);
  res.status(201).json(newBuild);
});

module.exports = router;
