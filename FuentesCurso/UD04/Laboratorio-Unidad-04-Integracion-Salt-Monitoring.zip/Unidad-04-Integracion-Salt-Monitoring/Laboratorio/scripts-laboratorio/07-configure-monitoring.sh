#!/bin/bash
# 07-configure-monitoring.sh - Configura Prometheus Targets y Dashboards de Grafana
set -euo pipefail

# Colores y Formato
RED='\033[0;31m'; GREEN='\033[0;32m'; YELLOW='\033[1;33m'; BLUE='\033[0;34m'; NC='\033[0m'
log()  { echo -e "${BLUE}[CONFIG]${NC} $1"; }
ok()   { echo -e "${GREEN}[CONFIG] ✓${NC} $1"; }
fail() { echo -e "${RED}[CONFIG] ✗${NC} $1"; }
warn() { echo -e "${YELLOW}[CONFIG] ⚠${NC} $1"; }

# ========== NUEVAS FUNCIONES DE ESPERA ==========
wait_for_prometheus() {
    log "Esperando a que Prometheus tenga datos de Node Exporters..."
    local max_wait=60  # 60 segundos máximo
    local waited=0
    
    while [ $waited -lt $max_wait ]; do
        # Verificar si Prometheus tiene al menos un target UP
        local targets=$(docker exec vm-master curl -s "http://localhost:9090/api/v1/targets" 2>/dev/null | jq '[.data.activeTargets[] | select(.health=="up")] | length' 2>/dev/null)
        
        if [ "$targets" -gt 0 ]; then
            ok "Prometheus tiene $targets targets activos"
            return 0
        fi
        
        sleep 2
        waited=$((waited + 2))
        echo -n "."
    done
    
    warn "Timeout esperando targets de Prometheus"
    return 1
}

wait_for_metric() {
    local metric_name="$1"
    local max_wait=30
    local waited=0
    
    log "Esperando métrica: $metric_name..."
    
    while [ $waited -lt $max_wait ]; do
        local has_data=$(docker exec vm-master curl -s "http://localhost:9090/api/v1/query?query=$metric_name" 2>/dev/null | jq '.data.result | length' 2>/dev/null)
        
        if [ "$has_data" -gt 0 ]; then
            ok "Métrica $metric_name disponible"
            return 0
        fi
        
        sleep 2
        waited=$((waited + 2))
        echo -n "."
    done
    
    warn "Timeout esperando métrica $metric_name"
    return 1
}

# ========== INICIO SCRIPT ==========
echo -e "${BLUE}╔═══════════════════════════════════════════════════════╗${NC}"
echo -e "${BLUE}║     UD04 - Configuración de Monitorización            ║${NC}"
echo -e "${BLUE}╚═══════════════════════════════════════════════════════╝${NC}"

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
LAB_DIR="$(dirname "$SCRIPT_DIR")"
MONITORING_DIR="$LAB_DIR/monitoring-lab"

docker inspect vm-master &>/dev/null || { fail "vm-master no encontrado"; exit 1; }

# ---------- PROMETHEUS CONFIG ----------
log "Actualizando configuración de Prometheus (targets y alertas)..."
docker cp "$MONITORING_DIR/prometheus.yml" vm-master:/etc/prometheus/prometheus.yml
docker cp "$MONITORING_DIR/alerts.yml" vm-master:/etc/prometheus/alerts.yml

docker exec vm-master bash -c '
    HUP_PID=$(pgrep -x "prometheus" | head -1)
    if [ -n "$HUP_PID" ]; then
        kill -HUP "$HUP_PID" 2>/dev/null || true
        echo "Prometheus configuration reloaded via SIGHUP"
    else
        pkill -f "/usr/bin/prometheus" 2>/dev/null || true
        sleep 1
        nohup /usr/bin/prometheus \
            --config.file=/etc/prometheus/prometheus.yml \
            --storage.tsdb.path=/var/lib/prometheus \
            --web.listen-address="0.0.0.0:9090" \
            --web.enable-lifecycle > /var/log/prometheus.log 2>&1 &
        echo "Prometheus started with full parameters"
    fi
'
ok "Configuración de Prometheus actualizada"

# ========== ESPERAR A QUE PROMETHEUS TENGA DATOS ==========
log "Esperando a que los Node Exporters envíen métricas..."
sleep 5  # Dar tiempo para el primer scrape
wait_for_prometheus

# Esperar métrica específica de disco
wait_for_metric "node_filesystem_size_bytes"

# ========== GRAFANA CONFIG ==========
GRAFANA_USER="admin"
GRAFANA_PASS="admin"

log "Verificando acceso a la API de Grafana..."
# Intento 1: admin/admin
if docker exec vm-master bash -c 'curl -sf -u admin:admin http://localhost:3000/api/health' > /dev/null 2>&1; then
    GRAFANA_PASS="admin"
# Intento 2: admin/Admin123
elif docker exec vm-master bash -c 'curl -sf -u admin:Admin123 http://localhost:3000/api/health' > /dev/null 2>&1; then
    GRAFANA_PASS="Admin123"
# Intento 3: Forzar reseteo
else
    warn "No se pudo autenticar con Grafana. Forzando reseteo..."
    docker exec vm-master bash -c "grafana cli --homepath /usr/share/grafana --config /etc/grafana/grafana.ini admin reset-admin-password admin" > /dev/null 2>&1
    GRAFANA_PASS="admin"
    sleep 5
fi
ok "Autenticación en Grafana lista"

log "Configurando Grafana datasource..."
docker exec vm-master bash -c "curl -sf -u $GRAFANA_USER:$GRAFANA_PASS http://localhost:3000/api/datasources/name/Prometheus" >/dev/null 2>&1 && \
    docker exec vm-master bash -c "curl -sf -X DELETE -u $GRAFANA_USER:$GRAFANA_PASS http://localhost:3000/api/datasources/name/Prometheus" >/dev/null 2>&1


# Eliminar dashboard existente si existe
log "Eliminando dashboard anterior si existe..."
docker exec vm-master bash -c "
    curl -s -X DELETE http://localhost:3000/api/dashboards/uid/ud04-overview \
      -u $GRAFANA_USER:$GRAFANA_PASS
" > /dev/null 2>&1
sleep 2

docker exec vm-master bash -c "
    curl -s -X POST http://localhost:3000/api/datasources \
      -u $GRAFANA_USER:$GRAFANA_PASS \
      -H 'Content-Type: application/json' \
      -d '{
        \"name\": \"Prometheus\",
        \"uid\": \"prometheus\",
        \"type\": \"prometheus\",
        \"url\": \"http://localhost:9090\",
        \"access\": \"proxy\",
        \"isDefault\": true,
        \"jsonData\": {\"timeInterval\": \"15s\"}
      }' > /dev/null 2>&1
" && ok "Datasource Prometheus configurado" || warn "Datasource no configurado"

# ========== ESPERA ADICIONAL ANTES DE CREAR DASHBOARD ==========
log "Esperando que Prometheus recolecte métricas iniciales..."
sleep 10
wait_for_metric "node_cpu_seconds_total"

# ========== CREAR DASHBOARD ==========
log "Configurando dashboard UD04 System Overview..."
docker exec vm-master bash -c "
    curl -s -X POST http://localhost:3000/api/dashboards/db \
      -u $GRAFANA_USER:$GRAFANA_PASS \
      -H 'Content-Type: application/json' \
      -d '{
        \"dashboard\": {
          \"id\": null,
          \"uid\": \"ud04-overview\",
          \"title\": \"UD04 - System Overview\",
          \"timezone\": \"browser\",
          \"editable\": true,
          \"graphTooltip\": 1,
          \"panels\": [
            {
              \"id\": 1, \"title\": \"CPU Usage\", \"type\": \"timeseries\",
              \"datasource\": \"Prometheus\",
              \"targets\": [{\"expr\": \"100 - (avg by(instance) (rate(node_cpu_seconds_total{mode=\\\"idle\\\"}[5m])) * 100)\", \"legendFormat\": \"{{instance}}\"}],
              \"gridPos\": {\"h\": 8, \"w\": 12, \"x\": 0, \"y\": 0}
            },
            {
              \"id\": 2, \"title\": \"Memory Usage\", \"type\": \"timeseries\",
              \"datasource\": \"Prometheus\",
              \"targets\": [{\"expr\": \"node_memory_MemTotal_bytes - node_memory_MemAvailable_bytes\", \"legendFormat\": \"{{instance}}\"}],
              \"gridPos\": {\"h\": 8, \"w\": 12, \"x\": 12, \"y\": 0}
            },
            {
              \"id\": 3, \"title\": \"Disk Usage\", \"type\": \"timeseries\",
              \"datasource\": \"Prometheus\",
              \"targets\": [{\"expr\": \"avg by (instance) (100 - ((node_filesystem_avail_bytes{fstype!=\\\"tmpfs\\\"} * 100) / node_filesystem_size_bytes{fstype!=\\\"tmpfs\\\"}))\", \"legendFormat\": \"{{instance}}\"}],
              \"gridPos\": {\"h\": 8, \"w\": 12, \"x\": 0, \"y\": 8}
            },
            {
              \"id\": 4, \"title\": \"Network Received\", \"type\": \"timeseries\",
              \"datasource\": \"Prometheus\",
              \"targets\": [{\"expr\": \"rate(node_network_receive_bytes_total{device!=\\\"lo\\\"}[5m])\", \"legendFormat\": \"{{instance}} {{device}}\"}],
              \"gridPos\": {\"h\": 8, \"w\": 12, \"x\": 12, \"y\": 8}
            }
          ],
          \"time\": {\"from\": \"now-1h\", \"to\": \"now\"},
          \"schemaVersion\": 39
        },
        \"overwrite\": true
      }' > /dev/null 2>&1
" && ok "Dashboard 'UD04 - System Overview' configurado" || warn "Dashboard no configurado"

echo ""
ok "Configuración de monitorización completada."
echo ""
log "📊 Accede a Grafana: http://172.28.0.40:3000"
log "   Usuario: admin / Contraseña: admin"
log "   Dashboard: UD04 - System Overview"