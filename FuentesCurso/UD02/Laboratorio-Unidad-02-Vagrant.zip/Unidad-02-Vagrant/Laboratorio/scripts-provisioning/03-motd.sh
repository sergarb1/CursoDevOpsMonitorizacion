#!/bin/bash
# 03-motd.sh - Mensaje de bienvenida (MOTD)
set -e
GREEN='\033[0;32m'; BLUE='\033[0;34m'; NC='\033[0m'

echo -e "${BLUE}[PROVISIÓN]${NC} Configurando mensaje de bienvenida (MOTD)..."
cat <<EOF > /etc/motd
╔═══════════════════════════════════════════════════════╗
║   BIENVENIDO AL LABORATORIO - UNIDAD 02 (VAGRANT)     ║
╚═══════════════════════════════════════════════════════╝
Hostname: $(hostname)
IP: $(hostname -I)
EOF
echo -e "${GREEN}✓${NC} MOTD configurado."
