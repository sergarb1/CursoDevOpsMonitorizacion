#!/bin/bash
# run-all.sh - Orquestador completo para UD04 (Salt + Monitoring)
# Este script automatiza todo el proceso, desde la red hasta la verificación final.
# Es ideal para entornos de aprendizaje (didáctico) para ver la secuencia de despliegue.

set -euo pipefail

# Colores y Formato para una mejor experiencia de usuario
RED='\033[0;31m'; GREEN='\033[0;32m'; YELLOW='\033[1;33m'; BLUE='\033[0;34m'; NC='\033[0m'

echo -e "${BLUE}╔═══════════════════════════════════════════════════════╗${NC}"
echo -e "${BLUE}║     UD04 - DESPLIEGUE COMPLETO (SALT + MONITORING)    ║${NC}"
echo -e "${BLUE}╚═══════════════════════════════════════════════════════╝${NC}"
echo ""
echo -e "  ${YELLOW}Estimación de tiempo:${NC} ~3-5 minutos (dependiendo de la conexión a internet)"
echo "  Este script realizará el despliegue completo del Laboratorio UD04:"
echo "    01. Configuración de Red Bridge (Host) - Crea el puente de red LabCEFIRE"
echo "    02. Despliegue de Infraestructura (Terraform) - Levanta los contenedores"
echo "    03. Provisión de Salt Master (Ubuntu) - Configura el servidor de control"
echo "    04. Provisión de Salt Minions (Ubuntu) - Configura los agentes"
echo "    05. Instalación de Prometheus Server - Motor de monitorización"
echo "    06. Instalación de Grafana Server - Visualización de datos"
echo "    07. Configuración de Monitorización (Targets + Dashboards)"
echo "    08. Verificación del Sistema - Comprobación final de salud"
echo ""
echo -e "  ${RED}NOTA:${NC} Algunos pasos (como Grafana) pueden parecer pausados mientras"
echo "  se realizan configuraciones internas. Por favor, no canceles el proceso."
echo ""
read -p "  ¿Deseas comenzar el despliegue? (s/N): " confirm
if [[ ! "$confirm" =~ ^[sS]$ ]]; then
    echo "  Operación cancelada."
    exit 0
fi

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

echo ""
echo -e "${BLUE}═══════ Paso 1/8: Red Bridge ═══════${NC}"
bash "$SCRIPT_DIR/01-setup-network.sh"

echo ""
echo -e "${BLUE}═══════ Paso 2/8: Infraestructura (Terraform) ═══════${NC}"
bash "$SCRIPT_DIR/02-deploy-infra.sh"

echo ""
echo -e "${BLUE}═══════ Paso 3/8: Salt Master ═══════${NC}"
bash "$SCRIPT_DIR/03-provision-salt-master.sh"

echo ""
echo -e "${BLUE}═══════ Paso 4/8: Salt Minions ═══════${NC}"
bash "$SCRIPT_DIR/04-provision-salt-minions.sh"

echo ""
echo -e "${BLUE}═══════ Paso 5/8: Prometheus Server ═══════${NC}"
bash "$SCRIPT_DIR/05-install-prometheus.sh"

echo ""
echo -e "${BLUE}═══════ Paso 6/8: Grafana Server ═══════${NC}"
bash "$SCRIPT_DIR/06-install-grafana.sh"

echo ""
echo -e "${BLUE}═══════ Paso 7/8: Configuración de Monitorización ═══════${NC}"
bash "$SCRIPT_DIR/07-configure-monitoring.sh"

echo ""
echo -e "${BLUE}═══════ Paso 8/8: Verificación ═══════${NC}"
bash "$SCRIPT_DIR/08-verify-system.sh"

echo ""
echo -e "${GREEN}╔═══════════════════════════════════════════════════════╗${NC}"
echo -e "${GREEN}║     ✅ Despliegue de UD04 Completado                ║${NC}"
echo -e "${GREEN}╚═══════════════════════════════════════════════════════╝${NC}"
echo ""
echo "  🚀 Accesos Rápidos (IPs actualizadas al rango .40+):"
echo "    - Salt Master:  docker exec -it vm-master bash"
echo "    - Prometheus:   http://172.28.0.40:9090"
echo "    - Grafana:      http://172.28.0.40:3000 (admin/admin)"
echo ""
echo "  Para destruir la infraestructura: bash $SCRIPT_DIR/98-destroy-infra.sh"
echo "  Para eliminar la red bridge:    bash $SCRIPT_DIR/99-destroy-network.sh"
echo ""
