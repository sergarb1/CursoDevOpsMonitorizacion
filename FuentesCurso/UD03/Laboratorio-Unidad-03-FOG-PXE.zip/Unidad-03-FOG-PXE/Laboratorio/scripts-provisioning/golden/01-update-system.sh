#!/bin/bash
# 01-update-system.sh - Actualizar sistema base
set -e

echo "=========================================="
echo "🔄 [GOLDEN] Actualizando sistema base..."
echo "=========================================="

apt-get update
# Comentado por agilizar el taller
# apt-get upgrade -y

echo "✅ [GOLDEN] Sistema actualizado correctamente"
