#!/bin/bash
# 06-prometheus.sh - Instalación y configuración de Prometheus Server.
# Este script prepara el nodo para actuar como el recolector de métricas central.
# Didáctica: Prometheus no necesita una base de datos externa, usa su propio
# motor TSDB (Time Series Database) optimizado para datos temporales.

set -euo pipefail
export DEBIAN_FRONTEND=noninteractive

# Colores para feedback visual
BLUE='\033[0;34m'; GREEN='\033[0;32m'; YELLOW='\033[1;33m'; RED='\033[0;31m'; NC='\033[0m'

echo -e "${BLUE}--- [PROMETHEUS] Iniciando instalación y configuración ---${NC}"

# Función para mostrar progreso
progress() { echo -e "${YELLOW}  [→]${NC} $1..."; }

# 1. Preparación del sistema
if ! command -v curl &>/dev/null; then
    progress "Instalando dependencias base (curl, gnupg, net-tools)"
    apt-get update  && apt-get install -y  curl gnupg net-tools ca-certificates iproute2 > /dev/null
fi

# 2. Instalación de Prometheus
export DEBIAN_FRONTEND=noninteractive
if command -v prometheus &>/dev/null; then
    echo -e "  ${GREEN}✓${NC} Prometheus ya está instalado en el sistema."
else
    progress "Instalando Prometheus desde repositorios oficiales"
    export DEBIAN_FRONTEND=noninteractive
      echo -e "  ${YELLOW}!${NC} Descargando binario Prometheus LTS..."
      PROMETHEUS_VERSION="2.45.0"
      curl -sL "https://github.com/prometheus/prometheus/releases/download/v${PROMETHEUS_VERSION}/prometheus-${PROMETHEUS_VERSION}.linux-amd64.tar.gz" | tar xz
      mv "prometheus-${PROMETHEUS_VERSION}.linux-amd64/prometheus" /usr/bin/
      mv "prometheus-${PROMETHEUS_VERSION}.linux-amd64/promtool" /usr/bin/
      rm -rf "prometheus-${PROMETHEUS_VERSION}.linux-amd64"
    echo -e "  ${GREEN}✓${NC} Binarios instalados correctamente."
fi

# 3. Configuración
mkdir -p /etc/prometheus /var/lib/prometheus

# Didáctica: Solo creamos un archivo básico si no existe ya uno (ej. subido por Terraform)
if [ ! -f /etc/prometheus/prometheus.yml ]; then
    progress "Generando configuración inicial por defecto (.40+)"
    cat > /etc/prometheus/prometheus.yml << 'EOF'
global:
  scrape_interval: 15s
  evaluation_interval: 15s

scrape_configs:
  - job_name: 'prometheus'
    static_configs:
      - targets: ['localhost:9090']

  - job_name: 'master-node'
    static_configs:
      - targets: ['172.28.0.40:9100']
        labels:
          instance: 'vm-master'

  - job_name: 'minion-1-node'
    static_configs:
      - targets: ['172.28.0.43:9100']
        labels:
          instance: 'vm-minion-1'

  - job_name: 'minion-2-node'
    static_configs:
      - targets: ['172.28.0.44:9100']
        labels:
          instance: 'vm-minion-2'
EOF
else
    echo -e "  ${GREEN}✓${NC} Se detectó configuración existente en /etc/prometheus/prometheus.yml"
fi

# 4. Gestión del servicio (Simulado con nohup en Docker)
progress "Reiniciando proceso Prometheus para aplicar cambios"
pkill -9 -f '/usr/bin/prometheus' 2>/dev/null || true
sleep 2

log_file="/var/log/prometheus.log"
# Didáctica: --storage.tsdb.path define dónde se guardan los datos históricos.
nohup /usr/bin/prometheus \
    --config.file=/etc/prometheus/prometheus.yml \
    --storage.tsdb.path=/var/lib/prometheus \
    --web.listen-address="0.0.0.0:9090" \
    --web.enable-lifecycle > "$log_file" 2>&1 &

# 5. Verificación de salud
echo -ne "  ${YELLOW}[WAIT]${NC} Esperando a que el motor TSDB esté listo "
for i in $(seq 1 20); do
    if curl -sf http://localhost:9090/-/healthy > /dev/null 2>&1; then
        echo -e "\n  ${GREEN}✓${NC} Prometheus operativo en puerto 9090."
        break
    fi
    echo -n "."
    sleep 1
    if [ $i -eq 20 ]; then
        echo -e "\n  ${RED}✗${NC} Error: El servicio no responde tras 20s. Revisa $log_file"
        exit 1
    fi
done

echo -e "${GREEN}--- [PROMETHEUS] Configuración finalizada con éxito ---${NC}"
