#!/bin/bash
# 02-pull-images.sh - Descarga imágenes Docker para trabajo offline
# ===================================================================
set -euo pipefail

BOLD='\033[1m'
RED='\033[0;31m'; GREEN='\033[0;32m'; YELLOW='\033[1;33m'
BLUE='\033[0;34m'; CYAN='\033[0;36m'; NC='\033[0m'
CHECK="${GREEN}✓${NC}"; CROSS="${RED}✗${NC}"; INFO="${CYAN}ℹ${NC}"
log() { echo -e "${CYAN}[PULL]${NC} $1"; }
ok()  { echo -e "  ${CHECK} $1"; }

echo -e "${BLUE}${BOLD}"
echo "╔══════════════════════════════════════════════════════════════╗"
echo "║   📥 UD06 - Paso 2: Precarga de Imágenes Docker           ║"
echo "╚══════════════════════════════════════════════════════════════╝"
echo -e "${NC}"

echo -e "${YELLOW}${BOLD}📘 ¿Qué vamos a hacer?${NC}"
echo "  Descargaremos todas las imágenes necesarias para el laboratorio"
echo "  para que el despliegue con Terraform sea más rápido y funcione"
echo "  sin depender de Internet durante la ejecución."
echo ""

IMAGES=(
    "jenkins/jenkins:lts-jdk21"
    "gitea/gitea:1.17"
    "postgres:16-alpine"
    "node:20-alpine"
    "prom/prometheus:latest"
    "grafana/grafana:latest"
    "gcr.io/cadvisor/cadvisor:latest"
)

TOTAL=${#IMAGES[@]}
COUNT=0
for img in "${IMAGES[@]}"; do
    COUNT=$((COUNT + 1))
    if docker image inspect "$img" >/dev/null 2>&1; then
        log "[$COUNT/$TOTAL] $img — ya en caché"
    else
        log "[$COUNT/$TOTAL] Descargando $img..."
        docker pull "$img" -q > /dev/null 2>&1
        log "[$COUNT/$TOTAL] $img — descargada"
    fi
done

echo ""
ok "Todas las imágenes están en local"
echo ""
echo -e "${YELLOW}${BOLD}📘 ¿Qué acabamos de hacer?${NC}"
echo -e "  Hemos descargado las 7 imágenes Docker que usaremos."
echo ""
echo -e "  ${BOLD}Imagen                ${NC}  ${BOLD}Rol en el laboratorio${NC}"
echo -e "  ───────────────────────────────────────────────────"
echo -e "  ${CYAN}jenkins/jenkins:lts-jdk21${NC}  Servidor CI/CD (orquesta pipelines)"
echo -e "  ${CYAN}gitea/gitea:1.17${NC}          Repositorio Git (código fuente)"
echo -e "  ${CYAN}postgres:16-alpine${NC}         Base de datos de Gitea"
echo -e "  ${CYAN}node:20-alpine${NC}             Entorno de tests (npm test en pipeline)"
echo -e "  ${CYAN}prom/prometheus${NC}            Métricas del sistema"
echo -e "  ${CYAN}grafana/grafana${NC}            Dashboard visual de métricas"
echo -e "  ${CYAN}cadvisor${NC}                   Monitor de contenedores Docker"
echo ""
echo -e "${YELLOW}${BOLD}🔍 COMPROBACIONES:${NC}"
echo -e "  docker images | grep -E 'jenkins|gitea|postgres|node|prometheus|grafana|cadvisor'"
echo -e "  → Deben aparecer todas con tamaño > 0"
echo ""
echo -e "${YELLOW}${BOLD}🏗️  Próximos pasos (visión general):${NC}"
echo -e "    ${BOLD}03${NC} Despliegas contenedores → Jenkins, Gitea, etc."
echo -e "    ${BOLD}04${NC} Configuras herramientas → plugins, job, credenciales"
echo -e "    ${BOLD}05${NC} Subes app v1         → pipeline la despliega en ${BOLD}staging${NC}"
echo -e "    ${BOLD}06${NC} Subes app v2         → pipeline actualiza staging,"
echo -e "                           luego ⏸️ espera aprobación para ${BOLD}producción${NC}"
echo -e "    ${BOLD}07${NC} Verificas staging vs producción → comparas ambos entornos"
echo ""
echo -e "${YELLOW}${BOLD}🔐 Credenciales del laboratorio (próximos pasos):${NC}"
echo -e "    ${BOLD}Jenkins:${NC} admin / admin  (en paso 03 se despliega)"
echo -e "    ${BOLD}Gitea:${NC}   gitea-admin / admin  (en paso 03)"
echo -e "    ${BOLD}Grafana:${NC} admin / admin  (en paso 03)"
echo ""

echo -e "  ${YELLOW}💡 Próximo paso:${NC} bash 03-deploy-infrastructure.sh"
