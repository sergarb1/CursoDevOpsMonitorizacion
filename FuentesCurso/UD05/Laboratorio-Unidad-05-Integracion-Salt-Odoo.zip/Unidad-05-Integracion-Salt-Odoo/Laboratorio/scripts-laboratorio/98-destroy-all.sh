#!/bin/bash
# 98-destroy-all.sh - Destrucción completa del laboratorio UD05 (sin red)
set -uo pipefail

RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
CYAN='\033[0;36m'
NC='\033[0m'

echo -e "${RED}╔════════════════════════════════════════════════════════════════╗${NC}"
echo -e "${RED}║              🔥 UD05 - DESTRUCCIÓN TOTAL DEL LAB              ║${NC}"
echo -e "${RED}╚════════════════════════════════════════════════════════════════╝${NC}"
echo ""

echo -e "  ${YELLOW}⚠ ADVERTENCIA:${NC} Esto eliminará TODOS los contenedores, volúmenes y la infraestructura."
echo -e "  ${RED}¡Los datos se perderán por completo!${NC}"
echo ""

read -p "  ¿Estás seguro de que deseas continuar? (s/N): " confirm

if [[ ! "$confirm" =~ ^[sS]$ ]]; then
    echo -e "\n  ${GREEN}Operación cancelada.${NC}"
    exit 0
fi

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
TF_DIR="$SCRIPT_DIR/../terraform"

cd "$TF_DIR"

echo -e "\n${BLUE}════════════════════════════════════════════════════════════════${NC}"
echo -e "${BLUE}  1. Destruyendo infraestructura con Terraform${NC}"
echo -e "${BLUE}════════════════════════════════════════════════════════════════${NC}"

if [ ! -f "terraform.tfstate" ] || [ ! -s "terraform.tfstate" ]; then
    echo -e "${YELLOW}⚠ No hay estado de Terraform. Nada que destruir.${NC}"
else
    echo -e "${CYAN}→ Ejecutando terraform destroy...${NC}"
    terraform destroy -auto-approve

    if [ $? -eq 0 ]; then
        echo -e "${GREEN}✓ Terraform destruyó todos los recursos correctamente${NC}"
    else
        echo -e "${RED}✗ Error durante terraform destroy${NC}"
        exit 1
    fi
fi

echo -e "\n${BLUE}════════════════════════════════════════════════════════════════${NC}"
echo -e "${BLUE}  2. Eliminando volúmenes de Docker (automático)${NC}"
echo -e "${BLUE}════════════════════════════════════════════════════════════════${NC}"

# Buscar y eliminar TODOS los volúmenes que comiencen con "ud05_"
volumes=$(docker volume ls -q --filter name=^ud05_ 2>/dev/null)

if [ -z "$volumes" ]; then
    echo -e "  ${YELLOW}No se encontraron volúmenes con prefijo 'ud05_'.${NC}"
else
    while IFS= read -r volume; do
        docker volume rm "$volume" >/dev/null 2>&1
        echo -e "  ${GREEN}✓ Eliminado volumen: $volume${NC}"
    done <<< "$volumes"
fi

echo -e "\n${BLUE}════════════════════════════════════════════════════════════════${NC}"
echo -e "${BLUE}  3. Limpiando contenedores huérfanos${NC}"
echo -e "${BLUE}════════════════════════════════════════════════════════════════${NC}"

containers=(
    "odoo-pg1" "odoo-pg2"
    "odoo-minion-1" "odoo-minion-2"
    "odoo-prometheus" "odoo-grafana"
    "odoo-loki" "odoo-alloy"
    "odoo-cadvisor" "odoo-blackbox"
    "ud05-salt-master"
)

for container in "${containers[@]}"; do
    if docker ps -a --format '{{.Names}}' | grep -q "^${container}$"; then
        docker stop "$container" >/dev/null 2>&1
        docker rm "$container" >/dev/null 2>&1
        echo -e "  ${GREEN}✓ Eliminado contenedor: $container${NC}"
    fi
done

echo -e "\n${BLUE}════════════════════════════════════════════════════════════════${NC}"
echo -e "${BLUE}  4. Limpiando archivos de Terraform${NC}"
echo -e "${BLUE}════════════════════════════════════════════════════════════════${NC}"

rm -f terraform.tfstate* 2>/dev/null
rm -rf .terraform 2>/dev/null
echo -e "  ${GREEN}✓ Archivos de Terraform eliminados${NC}"

echo -e "\n${GREEN}╔════════════════════════════════════════════════════════════════╗${NC}"
echo -e "${GREEN}║           ✅ LABORATORIO DESTRUIDO COMPLETAMENTE             ║${NC}"
echo -e "${GREEN}╚════════════════════════════════════════════════════════════════╝${NC}"
echo ""
echo -e "${YELLOW}📝 Nota: La red 'LabCEFIRE' NO ha sido eliminada.${NC}"
echo -e "   Para eliminarla manualmente: docker network rm LabCEFIRE"
echo -e "   O ejecuta: bash $SCRIPT_DIR/99-destroy-network.sh"
echo ""