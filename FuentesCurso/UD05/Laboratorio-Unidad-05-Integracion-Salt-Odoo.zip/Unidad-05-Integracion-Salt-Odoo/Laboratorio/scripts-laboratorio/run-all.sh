#!/bin/bash
# run-all.sh - Orquestador completo para UD05
# Fase 1: Infraestructura Terraform (11 contenedores)
# Fase 2: Inicialización de bases de datos
# Fase 3: Verificación
set -euo pipefail

RED='\033[0;31m'; GREEN='\033[0;32m'; YELLOW='\033[1;33m'; BLUE='\033[0;34m'; NC='\033[0m'

echo ""
echo -e "${BLUE}╔═══════════════════════════════════════════════════════╗${NC}"
echo -e "${BLUE}║     UD05 - Despliegue Completo (Salt+Odoo+Loki)    ║${NC}"
echo -e "${BLUE}╚═══════════════════════════════════════════════════════╝${NC}"
echo ""
echo "  Este script realizará:"
echo "    ✓ Creación de red Docker"
echo "    ✓ Despliegue de 11 contenedores (Terraform)"
echo "    ✓ Inicialización de bases de datos Odoo"
echo "    ✓ Verificación del sistema"
echo ""
echo "  Todos los contenedores se unirán automáticamente a SaltStack."
echo ""
read -p "  ¿Deseas continuar? (s/N): " confirm
if [[ ! "$confirm" =~ ^[sS]$ ]]; then
    echo "  Operación cancelada."
    exit 0
fi

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

echo ""
echo -e "${BLUE}═══════ Fase 1/3: Infraestructura (Terraform) ═══════${NC}"
bash "$SCRIPT_DIR/01-setup-network.sh"
bash "$SCRIPT_DIR/02-deploy-odoo-containers.sh"

echo ""
echo -e "${BLUE}═══════ Fase 2/3: Inicialización de Bases de Datos ═══════${NC}"
bash "$SCRIPT_DIR/04-create-odoo-database.sh"

echo ""
echo -e "${BLUE}═══════ Fase 3/3: Verificación ═══════${NC}"
bash "$SCRIPT_DIR/03-check-status-odoo.sh"

echo ""
echo -e "${GREEN}╔═══════════════════════════════════════════════════════╗${NC}"
echo -e "${GREEN}║     ✅ Despliegue de UD05 Completado                ║${NC}"
echo -e "${GREEN}╚═══════════════════════════════════════════════════════╝${NC}"
echo ""
echo "  🔧 Salt Master:  172.28.0.50"
echo "  📊 Grafana:      http://172.28.0.56:3000 (admin / admin)"
echo "  🛒 Odoo-1:       http://172.28.0.57:8069 (admin / admin)"
echo "  🛒 Odoo-2:       http://172.28.0.58:8069 (admin / admin)"
echo ""
echo "  Para aceptar minions: bash $SCRIPT_DIR/05-salt-accept-keys.sh"
echo "  Para destruir:        bash $SCRIPT_DIR/98-destroy-all.sh"
echo "  Para incidencias:     bash $SCRIPT_DIR/06-simulate-odoo-incidents.sh"
echo ""
