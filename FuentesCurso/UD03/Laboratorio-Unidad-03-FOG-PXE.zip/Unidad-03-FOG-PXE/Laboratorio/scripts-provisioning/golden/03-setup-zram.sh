#!/bin/bash
# 03-setup-zram.sh - Configurar ZRAM para optimización de memoria
set -e

echo "=========================================="
echo "⚡ [GOLDEN] Configurando ZRAM..."
echo "=========================================="

apt-get install -y zram-tools

# Configurar ZRAM solo si no existe ya la configuración
if ! grep -q "ALGO=zstd" /etc/default/zramswap; then
    echo -e "ALGO=zstd\nPERCENT=60" >> /etc/default/zramswap
fi

# Recargar daemon y habilitar el servicio
systemctl daemon-reload
systemctl enable zramswap.service

# Intentar iniciar el servicio (puede fallar en entorno Vagrant sin problemas reales)
echo "🔄 Iniciando servicio ZRAM..."
if ! systemctl start zramswap.service 2>/dev/null; then
    echo "⚠️  zramswap.service no pudo iniciarse ahora (normal en Vagrant)"
    echo "   Se activará en el próximo reinicio o al montar ZRAM manualmente"
fi

# Verificar estado (informativo)
echo "✅ [GOLDEN] ZRAM configurado correctamente"
sleep 1
zramctl 2>/dev/null && echo "✓ ZRAM activo" || echo "⚠️  ZRAM se activará al reiniciar"
