variable "network_name" {
  description = "Nombre de la red de Docker para el laboratorio"
  type        = string
  default     = "LabCEFIRE"
}

variable "subnet" {
  description = "Subred para el laboratorio"
  type        = string
  default     = "172.28.0.0/24"
}

variable "jenkins_ip" {
  description = "IP estática para el contenedor de Jenkins"
  type        = string
  default     = "172.28.0.61"
}

variable "gitea_ip" {
  description = "IP estática para el servidor git local"
  type        = string
  default     = "172.28.0.64"
}

variable "prometheus_ip" {
  description = "IP estática para Prometheus"
  type        = string
  default     = "172.28.0.65"
}

variable "grafana_ip" {
  description = "IP estática para Grafana"
  type        = string
  default     = "172.28.0.66"
}

variable "cadvisor_ip" {
  description = "IP estática para cAdvisor"
  type        = string
  default     = "172.28.0.67"
}

variable "postgres_ip" {
  description = "IP estática para PostgreSQL"
  type        = string
  default     = "172.28.0.68"
}

# variable "staging_ip" {
#   description = "IP estática para el entorno de staging"
#   type        = string
#   default     = "172.28.0.62"
# }
# 
# variable "production_ip" {
#   description = "IP estática para el entorno de producción"
#   type        = string
#   default     = "172.28.0.63"
# }
