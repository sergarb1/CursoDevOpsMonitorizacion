#!/bin/bash
# 01-update-system.sh - Actualizar sistema base
set -e

echo "=========================================="
echo "🔄 [FOG] Actualizando sistema base..."
echo "=========================================="

apt-get update
# COMENTADO PARA AGILIZAR EL TALLER
# apt-get upgrade -y

echo "✅ [FOG] Sistema actualizado correctamente"
