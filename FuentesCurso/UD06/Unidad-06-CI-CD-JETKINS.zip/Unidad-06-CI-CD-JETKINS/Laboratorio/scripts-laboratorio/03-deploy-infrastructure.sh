#!/bin/bash
# 03-deploy-infrastructure.sh - Despliega la infraestructura CI/CD con Terraform
# ==============================================================================
set -euo pipefail

# ── Colores ──
BOLD='\033[1m'
RED='\033[0;31m'; GREEN='\033[0;32m'; YELLOW='\033[1;33m'
BLUE='\033[0;34m'; CYAN='\033[0;36m'; NC='\033[0m'
CHECK="${GREEN}✓${NC}"; CROSS="${RED}✗${NC}"; INFO="${CYAN}ℹ${NC}"
log()   { echo -e "${BLUE}[DEPLOY]${NC} $1"; }
ok()    { echo -e "  ${CHECK} $1"; }
fail()  { echo -e "  ${CROSS} $1"; exit 1; }
warn()  { echo -e "  ${YELLOW}⚠${NC} $1"; }

echo -e "${BLUE}${BOLD}"
echo "╔══════════════════════════════════════════════════════════════╗"
echo "║   🏗️ UD06 - Paso 3: Infraestructura CI/CD con Terraform   ║"
echo "╚══════════════════════════════════════════════════════════════╝"
echo -e "${NC}"

echo -e "${YELLOW}${BOLD}📘 ¿Qué vamos a hacer?${NC}"
echo "  Vamos a desplegar 6 contenedores que forman el corazón del"
echo "  laboratorio: PostgreSQL (base de datos), Gitea (repositorio),"
echo "  Jenkins (CI/CD), Prometheus (métricas), Grafana (visualización)"
echo "  y cAdvisor (monitor Docker). Todo ello sobre la red LabCEFIRE"
echo "  con IPs estáticas."
echo ""
echo -e "${YELLOW}${BOLD}⏱️ Tiempos estimados (primera ejecución):${NC}"
echo -e "  ${YELLOW}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}"
echo -e "  ${YELLOW}⚠${NC}  Terraform apply:     ${BOLD}hasta 6 min${NC}  (construye imagen Jenkins personalizada)"
echo -e "  ${YELLOW}⚠${NC}  PostgreSQL:          ${BOLD}hasta 3 min${NC}  (inicializa la BD)"
echo -e "  ${YELLOW}⚠${NC}  Gitea 1.17:          ${BOLD}hasta 4 min${NC}  (migra esquemas la 1ª vez)"
echo -e "  ${YELLOW}⚠${NC}  Jenkins lts-jdk21:   ${BOLD}hasta 4 min${NC}  (descarga + arranca plugins)"
echo -e "  ${YELLOW}⚠${NC}  Prometheus:          ${BOLD}hasta 2 min${NC}"
echo -e "  ${YELLOW}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}"
echo -e "  ${BOLD}Total orientativo: 6-15 minutos${NC}"
echo -e "  ${CYAN}ℹ${NC}  Los contadores en vivo muestran el progreso."
echo -e "  ${CYAN}ℹ${NC}  Si un servicio excede el máximo, se muestran sus"
echo -e "     últimas líneas de log y se ${BOLD}continúa${NC} con el siguiente."
echo ""

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
LAB_DIR="$(dirname "$SCRIPT_DIR")"
APP_DIR="$LAB_DIR/app"
TERRAFORM_DIR="$(dirname "$(dirname "$SCRIPT_DIR")")/Terraform"
GITEA_DATA_DIR="$LAB_DIR/data/gitea"

# ── [1/7] Validación ──
echo -e "${BLUE}${BOLD}[1/7]${NC} Validando entorno..."
if [ ! -d "$TERRAFORM_DIR" ]; then fail "Directorio Terraform no encontrado"; fi
if ! command -v terraform &>/dev/null; then fail "Terraform no instalado"; fi
if ! docker network inspect LabCEFIRE >/dev/null 2>&1; then
    fail "Red LabCEFIRE no existe. Ejecuta 01-setup-network.sh primero"
fi
ok "Entorno validado"

# ── [2/7] Preparar directorios ──
echo -e "${BLUE}${BOLD}[2/7]${NC} Preparando directorios de la aplicación y datos..."
mkdir -p "$APP_DIR/src"
mkdir -p "$GITEA_DATA_DIR"
# Asegurar permisos para el usuario git del contenedor Gitea (UID 1000)
chown 1000:1000 "$GITEA_DATA_DIR" 2>/dev/null || true
ok "Directorios listos"

# ── [3/7] Pre-pull imagen para tests ──
echo -e "${BLUE}${BOLD}[3/7]${NC} Precargando imagen para tests (node:20-alpine)..."
if docker image inspect node:20-alpine >/dev/null 2>&1; then
    log "  node:20-alpine ya en caché"
else
    docker pull node:20-alpine -q > /dev/null 2>&1
    ok "node:20-alpine descargada"
fi
ok "Imagen de tests precargada"

# ── [4/7] Sincronizar estado Terraform ──
echo -e "${BLUE}${BOLD}[4/7]${NC} Sincronizando estado de Terraform..."
cd "$TERRAFORM_DIR"
for res in $(terraform state list 2>/dev/null); do
    if [[ $res == docker_volume.* ]]; then
        vol_name=$(terraform state show $res 2>/dev/null | grep 'name ' | awk -F'"' '{print $2}')
        [ -n "$vol_name" ] && ! docker volume inspect "$vol_name" >/dev/null 2>&1 && \
            terraform state rm "$res" >/dev/null 2>&1 || true
    elif [[ $res == docker_container.* ]]; then
        cont_name=$(terraform state show $res 2>/dev/null | grep 'name ' | awk -F'"' '{print $2}')
        [ -n "$cont_name" ] && ! docker inspect "$cont_name" >/dev/null 2>&1 && \
            terraform state rm "$res" >/dev/null 2>&1 || true
    fi
done
ok "Estado sincronizado"

# ── [5/7] Limpiar conflictos ──
echo -e "${BLUE}${BOLD}[5/7]${NC} Limpiando conflictos en Docker..."
CLEANED=false

# Eliminar contenedores previos
for cont in ud06-gitea ud06-jenkins ud06-postgres ud06-prometheus ud06-grafana ud06-cadvisor; do
    if docker ps -a --format '{{.Names}}' | grep -q "^${cont}$"; then
        warn "Eliminando contenedor: $cont"
        docker rm -f "$cont" >/dev/null 2>&1 || true
        CLEANED=true
    fi
done

# Eliminar volumen PostgreSQL para evitar recovery largo al arrancar
if docker volume inspect postgres-data >/dev/null 2>&1; then
    warn "Eliminando volumen postgres-data (arranque fresco)"
    docker volume rm -f postgres-data >/dev/null 2>&1 || true
    CLEANED=true
fi

# Eliminar volúmenes anónimos (creados por docker run en pipelines)
for v in $(docker volume ls -q --filter "label=com.docker.volume.anonymous" 2>/dev/null); do
    docker volume rm -f "$v" >/dev/null 2>&1 || true
    CLEANED=true
done

$CLEANED && ok "Conflictos resueltos" || ok "Sin conflictos"

# ── [6/7] Terraform init + apply ──
echo -e "${BLUE}${BOLD}[6/7]${NC} Desplegando infraestructura con Terraform..."
log "  Inicializando Terraform..."
terraform init -input=false >/dev/null 2>&1
ok "Terraform inicializado"

log "  Aplicando plan de Terraform..."
echo -e "  ${YELLOW}⚠ Puede tardar hasta 5 minutos. Lo más lento:${NC}"
echo -e "  ${YELLOW}  1.${NC} Descargar imagen base jenkins/jenkins:lts-jdk21 (~400MB)"
echo -e "  ${YELLOW}  2.${NC} Construir imagen personalizada (instalar Docker CLI)"
echo -e "  ${YELLOW}  3.${NC} Descargar postgres:16-alpine, prom/prometheus, etc."
echo -e "  ${CYAN}ℹ  Si todo está en caché (02-pull-images.sh), esto vuela.${NC}"
echo ""
START_TS=$(date +%s)
terraform apply -auto-approve > /tmp/tf-output.log 2>&1 &
TF_PID=$!
while kill -0 $TF_PID 2>/dev/null; do
    ELAPSED=$(( $(date +%s) - START_TS ))
    printf "\r${CYAN}  Terraform ejecutándose... ${NC}[${ELAPSED}s]      "
    sleep 2
done
wait $TF_PID
TOTAL=$(( $(date +%s) - START_TS ))
grep -E "Apply complete|Created:|Destroyed:|Modified:" /tmp/tf-output.log 2>/dev/null || true
echo ""
ok "Infraestructura desplegada (${TOTAL}s)"

# ── [7/7] Esperar servicios ──
echo -e "${BLUE}${BOLD}[7/7]${NC} Esperando a que los servicios estén listos..."
echo -e "  ${YELLOW}⚠ Puede llevar tiempo (sobre todo PostgreSQL recovery, Gitea y Jenkins).${NC}"
echo -e "  ${YELLOW}  Los contadores muestran: nombre [segundos / máximo].${NC}"
echo -e "  ${YELLOW}  Si un servicio excede el máximo, se muestran sus últimas líneas${NC}"
echo -e "  ${YELLOW}  de log como ayuda y se continúa con el siguiente.${NC}"
echo ""

wait_for_service() {
    local name=$1
    local url=$2
    local container=$3
    local label=$4
    local max_attempts=$5
    local attempt=0
    local started_at=$(date +%s)

    while [ $attempt -lt $max_attempts ]; do
        if curl -s --connect-timeout 3 -o /dev/null "$url" 2>/dev/null; then
            local elapsed=$(($(date +%s) - started_at))
            echo -e "  ${CHECK} $name responde (${elapsed}s)"
            return 0
        fi
        attempt=$((attempt + 1))
        local elapsed=$((attempt * 3))
        printf "\r${CYAN}  %-20s ${NC}[%3ds / %3ds]  %-45s" "$label" "$elapsed" $((max_attempts * 3)) "$url"
        sleep 3
    done
    local elapsed=$(($(date +%s) - started_at))
    echo -e "\r  ${YELLOW}⚠ $name no responde tras ${elapsed}s${NC}"
    echo -e "  ${CYAN}  Últimas líneas de ${container}:${NC}"
    docker logs "$container" 2>&1 | tail -5 | sed 's/^/    /'
    echo ""
    return 1
}

# PostgreSQL — esperar con pg_isready (hasta 200s)
for attempt in $(seq 1 100); do
    if docker exec ud06-postgres pg_isready -U gitea -d gitea 2>/dev/null | grep -q "accepting connections"; then
        echo -e "  ${CHECK} PostgreSQL listo (${attempt}s)"
        break
    fi
    printf "\r${CYAN}  PostgreSQL iniciando...  ${NC}[%3ds / 200s]" $((attempt * 2))
    sleep 2
    if [ $attempt -eq 100 ]; then
        echo -e "\r  ${YELLOW}⚠ PostgreSQL no responde tras 200s${NC}"
        echo -e "  ${CYAN}  Últimas líneas de logs:${NC}"
        docker logs ud06-postgres 2>&1 | tail -5 | sed 's/^/    /'
        echo ""
    fi
done

# Gitea — reiniciar para que coja conexión limpia a PostgreSQL
docker restart ud06-gitea >/dev/null 2>&1
wait_for_service "Gitea" "http://172.28.0.64:3000/" "ud06-gitea" "Gitea arrancando" 90

# Jenkins — plugins + JVM (hasta 4 min)
wait_for_service "Jenkins" "http://172.28.0.61:8080/login" "ud06-jenkins" "Jenkins iniciando" 90

# Prometheus
wait_for_service "Prometheus" "http://172.28.0.65:9090/-/healthy" "ud06-prometheus" "Prometheus iniciando" 40

echo ""
echo -e "${GREEN}${BOLD}✅ Infraestructura desplegada correctamente${NC}"
echo ""
docker ps --format "table {{.Names}}\t{{.Status}}\t{{.Ports}}" | grep ud06 || true
echo ""
echo -e "  ${CYAN}${BOLD}Accesos:${NC}"
echo -e "    💾 Gitea:      ${BOLD}http://172.28.0.64:3000${NC}"
echo -e "    🔧 Jenkins:    ${BOLD}http://172.28.0.61:8080${NC}"
echo -e "    📊 Prometheus: ${BOLD}http://172.28.0.65:9090${NC}"
echo -e "    📈 Grafana:    ${BOLD}http://172.28.0.66:3000${NC}"
echo ""
echo -e "  ${YELLOW}${BOLD}🔍 COMPROBACIONES MANUALES (navegador):${NC}"
echo -e "    ${BOLD}1) Jenkins:${NC}  http://172.28.0.61:8080 → debe cargar login"
echo -e "    ${BOLD}2) Gitea:${NC}    http://172.28.0.64:3000 → debe cargar inicio"
echo -e "    ${BOLD}3) Grafana:${NC}  http://172.28.0.66:3000 → debe cargar login"
echo -e "    ${BOLD}4) Prometheus:${NC} http://172.28.0.65:9090 → debe cargar"
echo ""
echo -e "${YELLOW}${BOLD}🔐 Credenciales del laboratorio:${NC}"
echo -e "    ${BOLD}Jenkins:${NC} admin / admin"
echo -e "    ${BOLD}Gitea:${NC}   gitea-admin / admin"
echo -e "    ${BOLD}Grafana:${NC} admin / admin"
echo ""
echo -e "${YELLOW}${BOLD}📘 ¿Qué acabamos de desplegar?${NC}"
echo -e "  6 contenedores que forman el ecosistema CI/CD completo."
echo -e "  La aplicación (calculadora) se desplegará más adelante"
echo -e "  mediante el pipeline de Jenkins."
echo ""
echo -e "${YELLOW}${BOLD}🏗️  ¿Dónde irá la app?${NC}"
echo -e "  ${CYAN}172.28.0.62${NC} — ${BOLD}Staging${NC}    → pruebas (llega primero)"
echo -e "  ${CYAN}172.28.0.63${NC} — ${BOLD}Producción${NC} → usuarios reales (llega tras aprobación)"
echo -e "  Estas IPs ya están reservadas, pero aún no hay contenedores."
echo -e "  Los creará el pipeline de Jenkins cuando ejecutes los pasos 05 y 06."
echo ""
echo -e "${BLUE}${BOLD}[⏳]${NC} Estabilizando servicios (3 min)..."
echo -e "  ${YELLOW}⚠ Espera para que Jenkins, Gitea y el resto terminen de iniciarse.${NC}"
echo ""
START=$SECONDS
DURATION=180
while [ $((SECONDS - START)) -lt $DURATION ]; do
    ELAPSED=$((SECONDS - START))
    PERCENT=$((ELAPSED * 100 / DURATION))
    FILLED=$((PERCENT * 40 / 100))
    EMPTY=$((40 - FILLED))
    printf "\r  ${CYAN}Estabilizando [${NC}"
    printf "${GREEN}%${FILLED}s${NC}" | tr ' ' '#'
    printf "${YELLOW}%${EMPTY}s${NC}" | tr ' ' '.'
    printf "${CYAN}] ${GREEN}%3d%%${NC}" $PERCENT
    sleep 1
done
printf "\r  ${CHECK} Servicios estabilizados (3 min)\n"
echo ""
echo -e "  ${YELLOW}💡 Próximo paso:${NC} bash 04-configure-tools.sh"
echo ""
