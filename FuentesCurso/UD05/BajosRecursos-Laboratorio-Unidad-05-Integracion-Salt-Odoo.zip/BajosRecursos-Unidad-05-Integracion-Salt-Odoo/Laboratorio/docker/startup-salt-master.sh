#!/bin/bash
# startup-salt-master.sh - UD05 (Versión Blindada)
set -uo pipefail
log() { echo "[ARRANQUE:salt-master] $1"; }
export DEBIAN_FRONTEND=noninteractive

# 1. Asegurar herramientas base
apt-get update -qq && apt-get install -y -qq wget curl gnupg >/dev/null 2>&1

# 2. Iniciar Node Exporter inmediatamente
if ! command -v node_exporter &>/dev/null; then
    wget -q https://github.com/prometheus/node_exporter/releases/download/v1.7.0/node_exporter-1.7.0.linux-amd64.tar.gz -O /tmp/node_exp.tar.gz
    cd /tmp && tar -xzf node_exp.tar.gz
    mv node_exporter-1.7.0.linux-amd64/node_exporter /usr/local/bin/
fi
/usr/local/bin/node_exporter >/dev/null 2>&1 &
log "✓ Node Exporter activo"

# 3. Instalación de Salt (en fondo para no bloquear nada)
(
    log "Instalando Salt Master 3006 LTS..."
    mkdir -m 755 -p /etc/apt/keyrings
    curl -fsSL https://packages.broadcom.com/artifactory/api/security/keypair/SaltProjectKey/public | gpg --dearmor -o /etc/apt/keyrings/salt-archive-keyring.pgp
    curl -fsSL https://github.com/saltstack/salt-install-guide/releases/latest/download/salt.sources | tee /etc/apt/sources.list.d/salt.sources > /dev/null
    echo 'Package: salt-*
Pin: version 3006.*
Pin-Priority: 1001' | tee /etc/apt/preferences.d/salt-pin-1001 > /dev/null
    apt-get update -qq && apt-get install -y -qq salt-master salt-minion salt-common >/dev/null 2>&1
    
    # Iniciar servicios Salt
    salt-master -d 2>/dev/null || true
    mkdir -p /etc/salt
    echo "master: 172.28.0.50" > /etc/salt/minion
    echo "id: salt-master" >> /etc/salt/minion
    salt-minion -d 2>/dev/null || true
    
    # Auto-aceptación
    (while true; do salt-key -A -y >/dev/null 2>&1 || true; sleep 15; done) &
) &

log "Servicios principales en marcha. Tailing /dev/null"
tail -f /dev/null
