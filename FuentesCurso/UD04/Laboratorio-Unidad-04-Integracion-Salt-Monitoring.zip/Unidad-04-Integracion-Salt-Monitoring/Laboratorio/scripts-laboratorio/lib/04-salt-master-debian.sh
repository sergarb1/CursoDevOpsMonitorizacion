#!/bin/bash
# 04-salt-master-debian.sh - Instalación de Salt Master para Debian 12
set -euo pipefail

echo "--- [SALT-MASTER-DEBIAN] Instalando Salt Master (Debian 12) ---"

# Método oficial de instalación (Salt Project)
mkdir -m 755 -p /etc/apt/keyrings
curl -fsSL https://packages.broadcom.com/artifactory/api/security/keypair/SaltProjectKey/public | gpg --dearmor | tee /etc/apt/keyrings/salt-archive-keyring.pgp > /dev/null
curl -fsSL https://github.com/saltstack/salt-install-guide/releases/latest/download/salt.sources | tee /etc/apt/sources.list.d/salt.sources

apt-get update 

# Instalar Salt Master
apt-get install -y  salt-master salt-common

# Configurar master para escuchar en todas las interfaces
cat >> /etc/salt/master << 'EOF'

# Laboratorio UD04 Configuration
interface: 0.0.0.0
auto_accept: false
keep_jobs: 24
EOF

# Arranque forzado si no hay systemd
if ! pgrep salt-master > /dev/null; then
    nohup /usr/bin/salt-master -d > /var/log/salt-master.log 2>&1 &
fi

echo "Salt Master (Debian) OK."
