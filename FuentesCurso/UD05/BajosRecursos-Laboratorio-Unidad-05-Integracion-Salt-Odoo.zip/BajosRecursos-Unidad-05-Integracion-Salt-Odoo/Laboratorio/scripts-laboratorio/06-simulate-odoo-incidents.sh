#!/bin/bash
# 07-simulate-odoo-incidents.sh - Simulador de Caos UD05 (Versión Mejorada)

set -uo pipefail

# COLORES
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
CYAN='\033[0;36m'
MAGENTA='\033[0;35m'
NC='\033[0m'

# Verificar que los contenedores existen antes de empezar
check_containers() {
    local missing=0
    for container in "odoo-minion-1" "odoo-pg1" "ud05-salt-master"; do
        if ! docker ps --format '{{.Names}}' | grep -q "^${container}$"; then
            echo -e "${RED}✗ Contenedor $container no está corriendo${NC}"
            missing=1
        fi
    done
    return $missing
}

# Barra de progreso simple
progress() {
    local duration=$1
    local message=$2
    for i in $(seq 1 $duration); do
        echo -ne "\r${CYAN}${message} ${NC}[${GREEN}"
        for j in $(seq 1 $i); do echo -n "#"; done
        for j in $(seq $((i+1)) $duration); do echo -n "."; done
        echo -ne "${NC}] ${GREEN}$((i * 100 / duration))%%${NC}"
        sleep 1
    done
    echo ""
}

# Mostrar estado actual antes del menú
show_status() {
    echo -e "\n${CYAN}📊 Estado rápido:${NC}"
    
    # Odoo
    if curl -s -o /dev/null -w "%{http_code}" http://172.28.0.57:8069 2>/dev/null | grep -q "200\|301\|302"; then
        echo -e "  ${GREEN}✓${NC} Odoo: Operativo"
    else
        echo -e "  ${RED}✗${NC} Odoo: Caído"
    fi
    
    # PostgreSQL
    if docker exec odoo-pg1 pg_isready -U odoo >/dev/null 2>&1; then
        echo -e "  ${GREEN}✓${NC} PostgreSQL: Conectado"
    else
        echo -e "  ${RED}✗${NC} PostgreSQL: Desconectado"
    fi
    
    # Prometheus
    if curl -s -o /dev/null http://172.28.0.51:9090 2>/dev/null; then
        echo -e "  ${GREEN}✓${NC} Prometheus: Activo"
    else
        echo -e "  ${RED}✗${NC} Prometheus: Inactivo"
    fi
}

# Verificar contenedores al inicio
if ! check_containers; then
    echo -e "\n${RED}[ERROR]${NC} No se encuentran los contenedores necesarios."
    echo "Ejecuta primero el despliegue con Terraform."
    exit 1
fi

while true; do
    clear
    echo -e "${BLUE}╔════════════════════════════════════════════════════════════════╗${NC}"
    echo -e "${BLUE}║              🚀 UD05 - SIMULADOR DE INCIDENCIAS                ║${NC}"
    echo -e "${BLUE}╚════════════════════════════════════════════════════════════════╝${NC}"
    
    show_status
    
    echo -e "\n${CYAN}────────────────────────────────────────────────────────────────${NC}"
    echo -e "${YELLOW}Selecciona un escenario de fallo:${NC}"
    echo -e "${CYAN}────────────────────────────────────────────────────────────────${NC}"
    echo -e " 1) ${YELLOW}🔥 CPU STRESS${NC}      - Carga CPU al 100% en Odoo (60s)"
    echo -e " 2) ${RED}💀 ODOO KILL${NC}       - Mata el proceso de Odoo"
    echo -e " 3) ${RED}🔌 DB CONNECTION${NC}   - Bloquea acceso a PostgreSQL"
    echo -e " 4) ${RED}🗄️ DB DROP${NC}         - Elimina la base de datos (¡CUIDADO!)"
    echo -e " 5) ${RED}🌐 NETWORK PARTITION${NC} - Aísla Odoo de la red"
    echo -e " 6) ${RED}🐳 CONTAINER STOP${NC}  - Detiene el contenedor Odoo"
    echo -e " 7) ${RED}📁 DISK FULL${NC}       - Llena el disco de Odoo (simulado)"
    echo -e "${CYAN}────────────────────────────────────────────────────────────────${NC}"
    echo -e " 8) ${GREEN}🔄 CLEANUP${NC}         - Restaurar todo al estado normal"
    echo -e " 9) ${GREEN}🔧 RESTART ALL${NC}     - Reinicia todos los servicios"
    echo -e "${CYAN}────────────────────────────────────────────────────────────────${NC}"
    echo -e " q) ${GREEN}👋 SALIR${NC}"
    echo -e "${CYAN}────────────────────────────────────────────────────────────────${NC}"
    read -p "Elige una opción: " opcion
    
    case $opcion in
        1)
            echo -e "\n${YELLOW}[ACCIÓN]${NC} Estresando CPU en odoo-minion-1 durante 60 segundos..."
            docker exec -d odoo-minion-1 timeout 60s bash -c "yes > /dev/null 2>&1 &"
            echo -e "${GREEN}✓ CPU stress lanzado.${NC} Mira el panel de CPU en Grafana."
            progress 10 "  ⏳ Generando carga"
            echo -e "${CYAN}→ El estrés durará 60 segundos en total.${NC}"
            ;;
        2)
            echo -e "\n${RED}[ACCIÓN]${NC} Matando proceso Odoo en odoo-minion-1..."
            docker exec odoo-minion-1 pkill -f "odoo" || true
            echo -e "${GREEN}✓ Proceso Odoo eliminado.${NC}"
            echo -e "${YELLOW}⏳ El servicio debería reiniciarse automáticamente (restart policy).${NC}"
            progress 5 "  ⏳ Esperando reinicio"
            ;;
        3)
            echo -e "\n${RED}[ACCIÓN]${NC} Bloqueando acceso a PostgreSQL..."
            docker exec odoo-pg1 psql -U odoo -d postgres -c "ALTER USER odoo NOLOGIN;" 2>/dev/null || true
            echo -e "${GREEN}✓ Acceso bloqueado. Odoo perderá conexión a la BD.${NC}"
            ;;
        4)
            echo -e "\n${RED}[ADVERTENCIA]${NC} Esto ELIMINARÁ la base de datos de Odoo."
            read -p "¿Estás seguro? (escribe 'CONFIRMAR' para continuar): " confirm
            if [[ "$confirm" == "CONFIRMAR" ]]; then
                echo -e "${RED}[ACCIÓN]${NC} Eliminando base de datos..."
                docker exec odoo-pg1 dropdb -U odoo --if-exists odoo 2>/dev/null || true
                echo -e "${GREEN}✓ Base de datos eliminada.${NC}"
                echo -e "${YELLOW}→ El script de inicialización la recreará al reiniciar.${NC}"
            else
                echo -e "${GREEN}Operación cancelada.${NC}"
            fi
            ;;
        5)
            echo -e "\n${RED}[ACCIÓN]${NC} Aislando Odoo de la red (partición de red)..."
            docker network disconnect LabCEFIRE odoo-minion-1 2>/dev/null || true
            echo -e "${GREEN}✓ Odoo desconectado de la red LabCEFIRE.${NC}"
            ;;
        6)
            echo -e "\n${RED}[ACCIÓN]${NC} Deteniendo el contenedor Odoo..."
            docker stop odoo-minion-1 2>/dev/null || true
            echo -e "${GREEN}✓ Contenedor detenido.${NC}"
            echo -e "${YELLOW}⏳ Debería reiniciarse automáticamente en unos segundos.${NC}"
            progress 8 "  ⏳ Esperando reinicio"
            ;;
        7)
            echo -e "\n${YELLOW}[ACCIÓN]${NC} Simulando disco lleno en Odoo..."
            docker exec -d odoo-minion-1 timeout 60s bash -c "dd if=/dev/zero of=/tmp/bigfile bs=1M count=100 2>/dev/null" 2>/dev/null || true
            echo -e "${GREEN}✓ Archivo temporal de 100MB creado. Se limpiará solo.${NC}"
            ;;
        8)
            echo -e "\n${GREEN}[LIMPIEZA] Restaurando el orden...${NC}"
            # Restaurar PostgreSQL
            docker exec odoo-pg1 psql -U odoo -d postgres -c "ALTER USER odoo LOGIN;" 2>/dev/null || true
            # Reconectar red si estaba desconectado
            docker network connect LabCEFIRE odoo-minion-1 2>/dev/null || true
            # Reiniciar Odoo
            docker restart odoo-minion-1 2>/dev/null || true
            # Limpiar archivos temporales
            docker exec odoo-minion-1 rm -f /tmp/bigfile 2>/dev/null || true
            echo -e "${GREEN}✓ Todo restaurado. Esperando que los servicios levanten...${NC}"
            progress 10 "  ⏳ Estabilizando servicios"
            echo -e "${GREEN}✅ Limpieza completada.${NC}"
            ;;
        9)
            echo -e "\n${GREEN}[REINICIO] Reiniciando todos los servicios...${NC}"
            for service in odoo-pg1 odoo-minion-1 odoo-prometheus odoo-grafana odoo-cadvisor; do
                echo -e "  Reiniciando $service..."
                docker restart $service 2>/dev/null || true
                sleep 2
            done
            echo -e "${GREEN}✓ Todos los servicios reiniciados.${NC}"
            progress 15 "  ⏳ Esperando que levanten"
            ;;
        q|Q)
            echo -e "\n${GREEN}👋 Saliendo del simulador...${NC}"
            echo -e "${YELLOW}Nota: Si dejaste algún servicio afectado, ejecuta la opción 8 (CLEANUP) después.${NC}"
            exit 0
            ;;
        *)
            echo -e "\n${RED}[ERROR] Opción no válida.${NC}"
            ;;
    esac
    
    echo -e "\n${CYAN}Presiona ENTER para volver al menú...${NC}"
    read
done