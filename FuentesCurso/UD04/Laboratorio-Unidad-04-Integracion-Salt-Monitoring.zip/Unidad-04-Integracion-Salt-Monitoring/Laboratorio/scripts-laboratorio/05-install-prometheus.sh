#!/bin/bash
# 05-install-prometheus.sh - Instala el servidor de métricas Prometheus en vm-master.
# Prometheus es una base de datos de series temporales que recolecta métricas vía HTTP.
set -euo pipefail

# Colores y Formato
RED='\033[0;31m'; GREEN='\033[0;32m'; YELLOW='\033[1;33m'; BLUE='\033[0;34m'; NC='\033[0m'
log()  { echo -e "${BLUE}[STEP]${NC} $1"; }
ok()   { echo -e "${GREEN}✓${NC} $1"; }
fail() { echo -e "${RED}✗${NC} $1"; }

echo -e "${BLUE}╔═══════════════════════════════════════════════════════╗${NC}"
echo -e "${BLUE}║     UD04 - Instalación de Prometheus                  ║${NC}"
echo -e "${BLUE}║     (Motor de Monitorización y Métricas)              ║${NC}"
echo -e "${BLUE}╚═══════════════════════════════════════════════════════╝${NC}"

docker inspect vm-master &>/dev/null || { fail "vm-master no encontrado"; exit 1; }




# ---------- PROMETHEUS ----------
# Prometheus se autogestiona. En este lab, lo instalamos como un binario de sistema
# dentro del contenedor vm-master para simplificar la gestión de red.
check_prometheus() {
    docker exec vm-master bash -c 'curl -sf http://localhost:9090/-/healthy > /dev/null 2>&1' 2>/dev/null
}

if check_prometheus; then
    ok "Prometheus: Ya está operativo en el puerto 9090."
else
    log "Instalando servidor Prometheus..."
    docker exec vm-master bash -c '
        export DEBIAN_FRONTEND=noninteractive
        bash /opt/scripts/lib/06-prometheus.sh
    '
    sleep 3
    if check_prometheus; then
        ok "Prometheus: Instalado y en ejecución."
    else
        fail "Prometheus: Error al arrancar el servicio."
    fi
fi


# ---------- NODE EXPORTER (MASTER) ----------
check_node_exporter() {
    docker exec vm-master bash -c 'curl -sf http://localhost:9100/metrics > /dev/null 2>&1' 2>/dev/null
}

if check_node_exporter; then
    ok "Node Exporter (master) ya está corriendo, saltando"
else
    log "Instalando Node Exporter en master..."
    docker exec vm-master bash -c '
        export DEBIAN_FRONTEND=noninteractive
        bash /opt/scripts/lib/08-node-exporter.sh 2>&1
    '
    sleep 2
    check_node_exporter && ok "Node Exporter (master) corriendo" || fail "Node Exporter (master) falló"
fi




echo -e "\n${YELLOW}Nota Didáctica:${NC} Prometheus utiliza un modelo 'pull'. No recibe datos, sino que va a buscarlos a los targets definidos en prometheus.yml."
echo ""
