#!/usr/bin/env python3
import time, os, sys, argparse
import xmlrpc.client
from prometheus_client import start_http_server, Gauge

# ========== ARGUMENTOS (prioritarios) ==========
parser = argparse.ArgumentParser()
parser.add_argument('--odoo-url', default=os.getenv('ODOO_URL', 'http://127.0.0.1:8069'))
parser.add_argument('--db', default=os.getenv('ODOO_DB', 'odoo_db'))
parser.add_argument('--user', default=os.getenv('ODOO_USER', 'admin'))
parser.add_argument('--password', default=os.getenv('ODOO_PASS', 'admin'))
parser.add_argument('--port', type=int, default=int(os.getenv('EXPORTER_PORT', '9090')))
args = parser.parse_args()

ODOO_URL = args.odoo_url
ODOO_DB  = args.db
ODOO_USER = args.user
ODOO_PASS = args.password
PORT      = args.port

# ========== MÉTRICAS ==========
users_gauge     = Gauge('odoo_users_total', 'Total usuarios')
partners_gauge  = Gauge('odoo_partners_total', 'Total contactos')
sales_gauge     = Gauge('odoo_sales_orders_total', 'Pedidos de venta')
products_gauge  = Gauge('odoo_products_total', 'Total productos')
invoices_gauge  = Gauge('odoo_invoices_total', 'Total facturas')
cron_gauge      = Gauge('odoo_cron_jobs_pending', 'Tareas pendientes')
query_time      = Gauge('odoo_query_duration_seconds', 'Latencia consulta')
error_gauge     = Gauge('odoo_exporter_errors', 'Errores consecutivos')

def safe_set(gauge, model, uid, pw):
    try:
        count = models.execute_kw(ODOO_DB, uid, pw, model, 'search_count', [[]])
        gauge.set(count)
        return count
    except Exception as e:
        print(f"[WARN] {model}: {e}")
        return None

def collect():
    global models
    try:
        common = xmlrpc.client.ServerProxy(f"{ODOO_URL}/xmlrpc/2/common", allow_none=True)
        uid = common.authenticate(ODOO_DB, ODOO_USER, ODOO_PASS, {})
        if not uid:
            raise Exception("Autenticación fallida")
        
        models = xmlrpc.client.ServerProxy(f"{ODOO_URL}/xmlrpc/2/object", allow_none=True)
        t0 = time.time()
        
        users_gauge.set(models.execute_kw(ODOO_DB, uid, ODOO_PASS, 'res.users', 'search_count', [[]]))
        partners_gauge.set(models.execute_kw(ODOO_DB, uid, ODOO_PASS, 'res.partner', 'search_count', [[]]))
        
        # Modelos opcionales: no actualizar si fallan
        safe_set(sales_gauge, 'sale.order', uid, ODOO_PASS)
        safe_set(products_gauge, 'product.template', uid, ODOO_PASS)
        safe_set(invoices_gauge, 'account.move', uid, ODOO_PASS)
        
        cron_gauge.set(models.execute_kw(ODOO_DB, uid, ODOO_PASS,
            'ir.cron', 'search_count', [[['active', '=', True]]]))
        
        query_time.set(time.time() - t0)
        error_gauge.set(0)
        print(f"[OK] users={users_gauge.collect()[0].samples[0].value:.0f} time={query_time.collect()[0].samples[0].value:.3f}s")
        
    except Exception as e:
        print(f"[ERROR] {e}")
        error_gauge.inc()
        # No ponemos las métricas a 0, conservan su último valor

if __name__ == '__main__':
    print(f"🚀 Odoo Exporter en :{PORT}")
    start_http_server(PORT)
    while True:
        collect()
        time.sleep(20)