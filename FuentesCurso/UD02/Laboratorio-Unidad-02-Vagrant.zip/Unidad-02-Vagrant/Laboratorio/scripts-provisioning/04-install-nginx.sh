#!/bin/bash
# 04-install-nginx.sh - Instalación de Nginx
set -e
GREEN='\033[0;32m'; BLUE='\033[0;34m'; NC='\033[0m'

echo -e "${BLUE}[PROVISIÓN]${NC} Instalando servidor web Nginx..."
export DEBIAN_FRONTEND=noninteractive
apt-get install -y -qq nginx > /dev/null
echo -e "${GREEN}✓${NC} Nginx instalado correctamente."
