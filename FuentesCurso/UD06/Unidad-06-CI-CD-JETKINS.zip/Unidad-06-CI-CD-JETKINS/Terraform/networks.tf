# En esta arquitectura, la red LabCEFIRE es compartida y gestionada externamente.
# Terraform simplemente la utiliza como recurso externo.

data "docker_network" "ud06_net" {
  name = var.network_name
}
