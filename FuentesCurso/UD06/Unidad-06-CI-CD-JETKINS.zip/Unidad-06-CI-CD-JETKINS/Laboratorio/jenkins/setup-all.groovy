import jenkins.model.*
import hudson.model.*
import org.jenkinsci.plugins.workflow.job.WorkflowJob
import org.jenkinsci.plugins.workflow.cps.CpsScmFlowDefinition
import hudson.plugins.git.GitSCM
import hudson.plugins.git.BranchSpec
import hudson.plugins.git.UserRemoteConfig
import com.cloudbees.plugins.credentials.*
import com.cloudbees.plugins.credentials.common.*
import com.cloudbees.plugins.credentials.domains.*
import com.cloudbees.plugins.credentials.impl.*

def instance = Jenkins.getInstance()

// 1. Crear Credenciales si no existen
def domain = Domain.global()
def store = instance.getExtensionList("com.cloudbees.plugins.credentials.SystemCredentialsProvider")[0].getStore()
def existingCreds = CredentialsMatchers.firstOrNull(
    CredentialsProvider.lookupCredentials(StandardUsernamePasswordCredentials.class, instance, null, domain),
    CredentialsMatchers.withId("gitea-admin")
)

if (existingCreds == null) {
    def giteaCreds = new UsernamePasswordCredentialsImpl(
        CredentialsScope.GLOBAL,
        "gitea-admin", "Gitea Admin",
        "gitea-admin",
        "admin"
    )
    store.addCredentials(domain, giteaCreds)
    println "✅ Credenciales creadas."
}

// 2. Crear el Job
def jobName = "Calculator-Pipeline"
if (instance.getItem(jobName) == null) {
    def repoUrl = "http://172.28.0.64:3000/gitea-admin/calculator-app.git"
    def job = instance.createProject(WorkflowJob.class, jobName)
    
    def gitScm = new GitSCM(repoUrl)
    gitScm.userRemoteConfigs = [new UserRemoteConfig(repoUrl, "gitea-admin", null, null)]
    gitScm.branches = [new BranchSpec("*/main")]
    
    job.definition = new CpsScmFlowDefinition(gitScm, "Jenkinsfile")
    job.save()
    println "✅ Job '${jobName}' creado con éxito."
} else {
    println "ℹ️ El Job '${jobName}' ya existe."
}

instance.save()
