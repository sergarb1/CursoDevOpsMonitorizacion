#!/bin/bash
# 03-install-node-exporter.sh - Instala Node Exporter en VM Debian 12
# Uso: vagrant ssh <VM> -c "sudo bash /path/to/02-install-node-exporter.sh"

set -euo pipefail

RED='\033[0;31m'; GREEN='\033[0;32m'; BLUE='\033[0;34m'; NC='\033[0m'
log()  { echo -e "${BLUE}[NE]${NC} $1"; }
ok()   { echo -e "${GREEN}[NE] ✓${NC} $1"; }

log "Instalando Node Exporter..."

export DEBIAN_FRONTEND=noninteractive

if command -v prometheus-node-exporter &>/dev/null; then
    ok "Node Exporter ya instalado"
else
    apt-get update 
    apt-get install -y  prometheus-node-exporter > /dev/null 2>&1
    ok "Node Exporter instalado"
fi

# Start
systemctl daemon-reload 2>/dev/null || true
systemctl restart prometheus-node-exporter 2>/dev/null || {
    pkill node_exporter 2>/dev/null || true
    sleep 1
    nohup /usr/bin/prometheus-node-exporter --web.listen-address=:9100 > /var/log/node-exporter.log 2>&1 &
}

sleep 2
MY_IP=$(hostname -I | awk '{print $1}')
ok "Node Exporter corriendo en http://$MY_IP:9100/metrics"
