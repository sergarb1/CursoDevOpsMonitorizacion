describe('Calculadora v2', () => {
  test('Multiplicaci\u00f3n b\u00e1sica', () => { expect(5 * 5).toBe(25); });
});
