#!/bin/bash
# 07-grafana.sh - Instalación y configuración de Grafana.
# Grafana es la capa de visualización que permite crear cuadros de mando (dashboards).
# Didáctica: Grafana no guarda métricas, las consulta en tiempo real de Prometheus.

set -euo pipefail

# Colores para feedback visual
BLUE='\033[0;34m'; GREEN='\033[0;32m'; YELLOW='\033[1;33m'; RED='\033[0;31m'; NC='\033[0m'

echo -e "${BLUE}--- [GRAFANA] Iniciando instalación y configuración ---${NC}"
export DEBIAN_FRONTEND=noninteractive

# Función para mostrar progreso
progress() { echo -e "${YELLOW}  [→]${NC} $1..."; }

# 1. Preparación y Repositorio
if [ ! -f /etc/apt/sources.list.d/grafana.list ]; then
    progress "Configurando repositorio oficial de Grafana OSS"
#    apt-get update  && apt-get install -y  curl gnupg ca-certificates apt-transport-https software-properties-common
    
    mkdir -p /etc/apt/keyrings
    curl -fsSL https://apt.grafana.com/gpg.key | gpg --dearmor -o /etc/apt/keyrings/grafana.gpg
    echo "deb [signed-by=/etc/apt/keyrings/grafana.gpg] https://apt.grafana.com stable main" > /etc/apt/sources.list.d/grafana.list
    apt-get update 
else
    echo -e "  ${GREEN}✓${NC} Repositorio de Grafana ya configurado."
fi

# 2. Instalación
if command -v grafana-server &>/dev/null; then
    echo -e "  ${GREEN}✓${NC} Grafana ya está instalado."
else
    progress "Instalando paquete 'grafana'"
    apt-get install -y  grafana
    echo -e "  ${GREEN}✓${NC} Instalación completada."
fi

# 3. Configuración y Permisos
progress "Preparando directorios y configuración (.ini)"
mkdir -p /var/lib/grafana /var/log/grafana /etc/grafana /run/grafana
chown -R grafana:grafana /var/lib/grafana /var/log/grafana /etc/grafana /run/grafana 2>/dev/null || true

cat > /etc/grafana/grafana.ini << 'EOF'
[server]
http_port = 3000
http_addr = 0.0.0.0

[security]
admin_user = admin
admin_password = admin

[users]
allow_sign_up = false

[auth.anonymous]
enabled = false
EOF

# 4. Arranque del servicio
progress "Iniciando grafana-server en segundo plano"
pkill -9 -f 'grafana-server' 2>/dev/null || true
sleep 1

export HOME=/usr/share/grafana
# Didáctica: Usamos --homepath porque los archivos estáticos de la web están allí.
nohup /usr/sbin/grafana-server \
    --config=/etc/grafana/grafana.ini \
    --homepath=/usr/share/grafana \
    --packaging=deb > /var/log/grafana.log 2>&1 &

# 5. Verificación (Grafana tarda por las migraciones de base de datos iniciales)
echo -ne "  ${YELLOW}[WAIT]${NC} Esperando migraciones de base de datos (Depende de la máquina, nos aseguramos con 600 segundos)  "
for i in $(seq 1 600); do
   
    echo -n "."
    sleep 1
done
if curl -sf http://localhost:3000/api/health > /dev/null 2>&1; then
        echo -e "\n  ${GREEN}✓${NC} Grafana operativo en puerto 3000."
fi

echo -e "${GREEN}--- [GRAFANA] Configuración finalizada con éxito ---${NC}"
