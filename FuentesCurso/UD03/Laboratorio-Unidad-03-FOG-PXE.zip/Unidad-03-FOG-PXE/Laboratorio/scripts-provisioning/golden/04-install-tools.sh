#!/bin/bash
# 04-install-tools.sh - Instalar herramientas adicionales
set -e

echo "=========================================="
echo "🛠️  [GOLDEN] Instalando herramientas adicionales..."
echo "=========================================="

apt-get install -y nano sudo htop vim

echo "✅ [GOLDEN] Herramientas instaladas correctamente: nano, sudo, htop, vim"
