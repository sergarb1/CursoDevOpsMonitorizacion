#!/bin/bash
# 06-create-admin-user.sh - Crear usuario admin para FOG-Server
set -e

echo "=========================================="
echo "👤 [FOG] Creando usuario 'admin'..."
echo "=========================================="

if ! id "admin" &>/dev/null; then
    useradd -m -s /bin/bash admin
    echo "admin:AdminCEFIRE1234" | chpasswd
    usermod -aG sudo admin
    # Permitir sudo sin contraseña para facilitar el laboratorio
    echo "admin ALL=(ALL) NOPASSWD:ALL" > /etc/sudoers.d/admin
    chmod 440 /etc/sudoers.d/admin
    echo "✅ [FOG] Usuario 'admin' creado correctamente (con SUDO sin password)"
    echo "   Usuario: admin"
    echo "   Contraseña: AdminCEFIRE1234"
else
    echo "✅ [FOG] Usuario 'admin' ya existe"
fi

echo "=========================================="
echo "✅ [FOG] Usuario configurado"
echo "=========================================="
