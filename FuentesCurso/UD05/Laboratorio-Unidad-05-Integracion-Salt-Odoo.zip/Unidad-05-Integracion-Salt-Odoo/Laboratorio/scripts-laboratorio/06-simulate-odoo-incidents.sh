#!/bin/bash
# 06-simulate-odoo-incidents.sh - Simulador de Caos UD05 (Completo con Loki + 2 Minions)

set -uo pipefail

RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
CYAN='\033[0;36m'
NC='\033[0m'

check_containers() {
    local missing=0
    for container in "odoo-minion-1" "odoo-minion-2" "odoo-pg1" "odoo-pg2" "ud05-salt-master"; do
        if ! docker ps --format '{{.Names}}' | grep -q "^${container}$"; then
            echo -e "${RED}✗ Contenedor $container no está corriendo${NC}"
            missing=1
        fi
    done
    return $missing
}

progress() {
    local duration=$1
    local message=$2
    for i in $(seq 1 $duration); do
        echo -ne "\r${CYAN}${message} ${NC}[${GREEN}"
        for j in $(seq 1 $i); do echo -n "#"; done
        for j in $(seq $((i+1)) $duration); do echo -n "."; done
        echo -ne "${NC}] ${GREEN}$((i * 100 / duration))%%${NC}"
        sleep 1
    done
    echo ""
}

show_status() {
    echo -e "\n${CYAN}📊 Estado rápido:${NC}"
    for i in 1 2; do
        local host="172.28.0.$((56 + i))"
        if curl -s -o /dev/null -w "%{http_code}" http://$host:8069 2>/dev/null | grep -q "200\|301\|302"; then
            echo -e "  ${GREEN}✓${NC} Odoo $i: Operativo"
        else
            echo -e "  ${RED}✗${NC} Odoo $i: Caído"
        fi
    done
    for pg in odoo-pg1 odoo-pg2; do
        if docker exec $pg pg_isready -U odoo >/dev/null 2>&1; then
            echo -e "  ${GREEN}✓${NC} $pg: Conectado"
        else
            echo -e "  ${RED}✗${NC} $pg: Desconectado"
        fi
    done
    if curl -s -o /dev/null http://172.28.0.51:9090 2>/dev/null; then
        echo -e "  ${GREEN}✓${NC} Prometheus: Activo"
    else
        echo -e "  ${RED}✗${NC} Prometheus: Inactivo"
    fi
}

if ! check_containers; then
    echo -e "\n${RED}[ERROR]${NC} No se encuentran los contenedores necesarios."
    echo "Ejecuta primero el despliegue con Terraform."
    exit 1
fi

while true; do
    clear
    echo -e "${BLUE}╔════════════════════════════════════════════════════════════════╗${NC}"
    echo -e "${BLUE}║              🚀 UD05 - SIMULADOR DE INCIDENCIAS                ║${NC}"
    echo -e "${BLUE}╚════════════════════════════════════════════════════════════════╝${NC}"

    show_status

    echo -e "\n${CYAN}────────────────────────────────────────────────────────────────${NC}"
    echo -e "${YELLOW}Selecciona un escenario de fallo:${NC}"
    echo -e "${CYAN}────────────────────────────────────────────────────────────────${NC}"
    echo -e " 1) ${YELLOW}🔥 CPU STRESS${NC}      - Carga CPU al 100% en Odoo 1 (60s)"
    echo -e " 2) ${YELLOW}💾 RAM EXHAUSTION${NC}  - Agota 1GB de RAM en Odoo 2 (60s)"
    echo -e " 3) ${YELLOW}📀 DISK I/O SPAM${NC}   - Escritura masiva en disco (Odoo 2)"
    echo -e " 4) ${YELLOW}📋 LOG FLOOD${NC}       - Inundación masiva de logs (Alloy/Loki)"
    echo -e " 5) ${RED}💀 ODOO KILL${NC}       - Mata el proceso Odoo (Blackbox salta)"
    echo -e " 6) ${RED}🔌 DB CONNECTION${NC}   - Bloquea acceso a PostgreSQL 1"
    echo -e " 7) ${RED}🐳 DB DOWN${NC}          - Detiene PostgreSQL 2"
    echo -e "${CYAN}────────────────────────────────────────────────────────────────${NC}"
    echo -e " 8) ${GREEN}🔄 CLEANUP${NC}         - Restaurar todo al estado normal"
    echo -e " 9) ${GREEN}🔧 RESTART ALL${NC}     - Reinicia todos los servicios"
    echo -e "${CYAN}────────────────────────────────────────────────────────────────${NC}"
    echo -e " q) ${GREEN}👋 SALIR${NC}"
    echo -e "${CYAN}────────────────────────────────────────────────────────────────${NC}"
    read -p "Elige una opción: " opcion

    case $opcion in
        1)
            echo -e "\n${YELLOW}[ACCIÓN]${NC} Estresando CPU en odoo-minion-1 durante 60 segundos..."
            docker exec -d odoo-minion-1 timeout 60s bash -c "cat /dev/urandom | md5sum"
            echo -e "${GREEN}✓ CPU stress lanzado.${NC} Mira el panel de CPU en Grafana."
            progress 10 "  ⏳ Generando carga"
            echo -e "${CYAN}→ El estrés durará 60 segundos en total.${NC}"
            ;;
        2)
            echo -e "\n${YELLOW}[ACCIÓN]${NC} Agotando 1GB de RAM en odoo-minion-2..."
            docker exec -d odoo-minion-2 python3 -c "import time; x = bytearray(1024*1024*1000); print('RAM reservada'); time.sleep(60)"
            echo -e "${GREEN}✓ RAM exhaustion lanzada.${NC} Mira el panel de RAM en Grafana."
            ;;
        3)
            echo -e "\n${YELLOW}[ACCIÓN]${NC} Generando tráfico de disco en odoo-minion-2..."
            docker exec -d odoo-minion-2 dd if=/dev/zero of=/tmp/stress_file bs=1M count=2048 oflag=dsync
            echo -e "${GREEN}✓ Disk I/O lanzado.${NC} Mira 'I/O de Disco'."
            ;;
        4)
            echo -e "\n${YELLOW}[ACCIÓN]${NC} Inundando Loki con logs desde odoo-minion-1..."
            docker exec -d odoo-minion-1 bash -c "for i in {1..10000}; do echo \"UD05 LOG FLOOD LINE \$i - CRITICAL SIMULATED ERROR\"; done"
            echo -e "${GREEN}✓ Log flood lanzado.${NC} Revisa Loki/Alloy en Grafana."
            ;;
        5)
            echo -e "\n${RED}[ACCIÓN]${NC} Matando proceso Odoo en odoo-minion-1..."
            docker exec odoo-minion-1 pkill -f "odoo" || true
            echo -e "${GREEN}✓ Proceso Odoo eliminado.${NC}"
            echo -e "${YELLOW}⏳ El servicio debería reiniciarse automáticamente.${NC}"
            progress 5 "  ⏳ Esperando reinicio"
            ;;
        6)
            echo -e "\n${RED}[ACCIÓN]${NC} Bloqueando acceso a PostgreSQL 1..."
            docker exec odoo-pg1 psql -U odoo -d postgres -c "ALTER USER odoo NOLOGIN;" 2>/dev/null || true
            echo -e "${GREEN}✓ Acceso bloqueado. Odoo 1 perderá conexión a la BD.${NC}"
            ;;
        7)
            echo -e "\n${RED}[ACCIÓN]${NC} Deteniendo PostgreSQL 2..."
            docker stop odoo-pg2 2>/dev/null || true
            echo -e "${GREEN}✓ PostgreSQL 2 detenido.${NC}"
            echo -e "${YELLOW}⏳ Odoo 2 debería mostrar error de BD.${NC}"
            ;;
        8)
            echo -e "\n${GREEN}[LIMPIEZA] Restaurando el orden...${NC}"
            docker exec odoo-pg1 psql -U odoo -d postgres -c "ALTER USER odoo LOGIN;" 2>/dev/null || true
            docker start odoo-pg2 2>/dev/null || true
            docker restart odoo-minion-1 odoo-minion-2 2>/dev/null || true
            docker exec odoo-minion-2 rm -f /tmp/stress_file 2>/dev/null || true
            echo -e "${GREEN}✓ Todo restaurado. Esperando que los servicios levanten...${NC}"
            progress 10 "  ⏳ Estabilizando servicios"
            echo -e "${GREEN}✅ Limpieza completada.${NC}"
            ;;
        9)
            echo -e "\n${GREEN}[REINICIO] Reiniciando todos los servicios...${NC}"
            for service in odoo-pg1 odoo-pg2 odoo-minion-1 odoo-minion-2 odoo-prometheus odoo-grafana odoo-loki odoo-alloy odoo-cadvisor; do
                echo -e "  Reiniciando $service..."
                docker restart $service 2>/dev/null || true
                sleep 2
            done
            echo -e "${GREEN}✓ Todos los servicios reiniciados.${NC}"
            progress 15 "  ⏳ Esperando que levanten"
            ;;
        q|Q)
            echo -e "\n${GREEN}👋 Saliendo del simulador...${NC}"
            echo -e "${YELLOW}Nota: Si dejaste algún servicio afectado, ejecuta la opción 8 (CLEANUP) después.${NC}"
            exit 0
            ;;
        *)
            echo -e "\n${RED}[ERROR] Opción no válida.${NC}"
            ;;
    esac

    echo -e "\n${CYAN}Presiona ENTER para volver al menú...${NC}"
    read
done
