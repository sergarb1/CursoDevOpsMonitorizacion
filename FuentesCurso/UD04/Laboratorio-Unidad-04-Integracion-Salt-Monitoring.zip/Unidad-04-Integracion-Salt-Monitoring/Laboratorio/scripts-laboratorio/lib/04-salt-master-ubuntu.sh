#!/bin/bash
# 04-salt-master-ubuntu.sh - Instalación de Salt Master para Ubuntu 24.04
set -euo pipefail

echo "--- [SALT-MASTER-UBUNTU] Instalando Salt Master (Ubuntu 24.04) ---"

# Install prerequisites (container may be bare ubuntu:24.04)
export DEBIAN_FRONTEND=noninteractive
apt-get update
apt-get install -y  --no-install-recommends curl gnupg net-tools ca-certificates

# Método oficial de instalación (Salt Project)
mkdir -m 755 -p /etc/apt/keyrings
curl -fsSL https://packages.broadcom.com/artifactory/api/security/keypair/SaltProjectKey/public | gpg --dearmor | tee /etc/apt/keyrings/salt-archive-keyring.pgp > /dev/null
curl -fsSL https://github.com/saltstack/salt-install-guide/releases/latest/download/salt.sources | tee /etc/apt/sources.list.d/salt.sources

apt-get update

# Instalar Salt Master
apt-get install -y salt-master salt-common

# Configurar master para escuchar en todas las interfaces
# Append only if not already present
grep -q 'Laboratorio UD04' /etc/salt/master 2>/dev/null || cat >> /etc/salt/master << 'EOF'

# Laboratorio UD04 Configuration
interface: 0.0.0.0
auto_accept: false
keep_jobs: 24
EOF

# Kill stale processes before starting (avoids "ports not available")
pkill -9 -f '/usr/bin/salt-master' 2>/dev/null || true
sleep 1

# Arranque forzado si no hay systemd
nohup /usr/bin/salt-master -d > /var/log/salt-master.log 2>&1 &
# Wait for process to actually start (retry up to 15s)
for i in $(seq 1 15); do
    pgrep -f '/usr/bin/salt-master' > /dev/null && break
    sleep 1
done
pgrep -f '/usr/bin/salt-master' > /dev/null || { echo "ERROR: Salt Master failed to start"; cat /var/log/salt-master.log 2>/dev/null | tail -10; exit 1; }

echo "Salt Master (Ubuntu) OK."
