#!/bin/bash
# 02-common-tools.sh - Herramientas esenciales
set -e
GREEN='\033[0;32m'; BLUE='\033[0;34m'; NC='\033[0m'

echo -e "${BLUE}[PROVISIÓN]${NC} Instalando herramientas comunes (vim, curl, git, net-tools)..."
export DEBIAN_FRONTEND=noninteractive
apt-get install -y -qq vim curl git htop net-tools > /dev/null
echo -e "${GREEN}✓${NC} Herramientas instaladas correctamente."
