#!/bin/bash
# 04-configure-tools.sh - Configura Jenkins y Gitea para el pipeline CI/CD
# ==============================================================================
set -euo pipefail

# ── Colores ──
BOLD='\033[1m'
RED='\033[0;31m'; GREEN='\033[0;32m'; YELLOW='\033[1;33m'
BLUE='\033[0;34m'; CYAN='\033[0;36m'; NC='\033[0m'
CHECK="${GREEN}✓${NC}"; CROSS="${RED}✗${NC}"; INFO="${CYAN}ℹ${NC}"
log()   { echo -e "${BLUE}[TOOLS]${NC} $1"; }
ok()    { echo -e "  ${CHECK} $1"; }
fail()  { echo -e "  ${CROSS} $1"; exit 1; }
warn()  { echo -e "  ${YELLOW}⚠${NC} $1"; }

echo -e "${BLUE}${BOLD}"
echo "╔══════════════════════════════════════════════════════════════╗"
echo "║   🔧 UD06 - Paso 4: Configuración de Jenkins y Gitea      ║"
echo "╚══════════════════════════════════════════════════════════════╝"
echo -e "${NC}"

echo -e "${YELLOW}${BOLD}📘 ¿Qué vamos a hacer?${NC}"
echo "  Configuraremos Jenkins (plugins, job pipeline, credenciales"
echo "  para Gitea) y Gitea (usuario gitea-admin y repositorio"
echo "  calculator-app). Así dejamos listo el ecosistema para"
echo "  recibir el código de la aplicación."
echo ""
echo -e "${YELLOW}${BOLD}⏱️ Tiempos estimados:${NC}"
echo -e "  ${YELLOW}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}"
echo -e "  ${YELLOW}⚠${NC}  Jenkins inicial:     ${BOLD}hasta 4 min${NC}  (esperar que arranque plugins)"
echo -e "  ${YELLOW}⚠${NC}  Plugins + Job:       ${BOLD}~20 s${NC}      (instalar 4 plugins)"
echo -e "  ${YELLOW}⚠${NC}  Gitea configuración: ${BOLD}~10 s${NC}      (crear usuario + repo)"
echo -e "  ${YELLOW}⚠${NC}  Reinicio Jenkins:    ${BOLD}hasta 3 min${NC} (cargar plugins + credenciales)"
echo -e "  ${YELLOW}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}"
echo -e "  ${BOLD}Total orientativo: 3-8 minutos${NC}"
echo -e "  ${CYAN}ℹ${NC}  Los contadores en vivo muestran el progreso."
echo ""

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

# ── [1/6] Esperar Jenkins ──
echo -e "${BLUE}${BOLD}[1/6]${NC} Esperando a que Jenkins esté listo..."
echo -e "  ${YELLOW}⚠ Jenkins puede tardar hasta 4 min descargando plugins.${NC}"
echo -e "  ${CYAN}  URL: http://172.28.0.61:8080/login${NC}"
echo ""
for i in $(seq 1 90); do
    if curl -s --connect-timeout 3 -o /dev/null http://172.28.0.61:8080/login 2>/dev/null; then
        echo -e "  ${CHECK} Jenkins listo (${i}s)"
        break
    fi
    printf "\r${CYAN}  Jenkins arrancando... ${NC}[%3ds / 270s]" $((i * 3))
    sleep 3
    if [ $i -eq 90 ]; then
        echo -e "\r  ${YELLOW}⚠ Jenkins no responde tras 270s${NC}"
    fi
done

# ── [2/6] Instalar plugins ──
echo -e "${BLUE}${BOLD}[2/6]${NC} Instalando plugins de Jenkins..."
if docker exec ud06-jenkins jenkins-plugin-cli --plugins \
    git workflow-aggregator docker-workflow credentials-binding prometheus \
    > /dev/null 2>&1; then
    ok "Plugins instalados"
else
    warn "Algunos plugins ya estaban presentes"
fi

# ── [3/6] Crear job pipeline ──
echo -e "${BLUE}${BOLD}[3/6]${NC} Creando job 'Calculator-Pipeline'..."
JOB_DIR="/var/jenkins_home/jobs/Calculator-Pipeline"
docker exec -u root ud06-jenkins mkdir -p "$JOB_DIR"
docker cp "$SCRIPT_DIR/../jenkins/pipeline-config.xml" ud06-jenkins:"$JOB_DIR/config.xml"
docker exec -u root ud06-jenkins chown -R 1000:1000 /var/jenkins_home/jobs/
ok "Job Calculator-Pipeline configurado"

# ── [4/6] Inyectar credenciales ──
echo -e "${BLUE}${BOLD}[4/6]${NC} Inyectando credenciales Gitea en Jenkins..."
docker exec ud06-jenkins mkdir -p /var/jenkins_home/init.groovy.d
cat <<'CREDS_EOF' > /tmp/creds.groovy
import com.cloudbees.plugins.credentials.*
import com.cloudbees.plugins.credentials.common.*
import com.cloudbees.plugins.credentials.domains.*
import com.cloudbees.plugins.credentials.impl.*
import jenkins.model.Jenkins

def domain = Domain.global()
def store = Jenkins.instance.getExtensionList("com.cloudbees.plugins.credentials.SystemCredentialsProvider")[0].getStore()
if (!store.getCredentials(domain).any { it.id == "gitea-admin" }) {
    def giteaCreds = new UsernamePasswordCredentialsImpl(
      CredentialsScope.GLOBAL, "gitea-admin", "Gitea Admin", "gitea-admin", "admin"
    )
    store.addCredentials(domain, giteaCreds)
}
CREDS_EOF
docker cp /tmp/creds.groovy ud06-jenkins:/var/jenkins_home/init.groovy.d/creds.groovy
ok "Credenciales preparadas"

# ── [5/6] Configurar Gitea ──
echo -e "${BLUE}${BOLD}[5/6]${NC} Configurando Gitea..."

docker exec -u git ud06-gitea gitea admin user create \
    --username gitea-admin --password admin --email devops@example.com \
    --must-change-password=false 2>/dev/null \
    && log "  Usuario admin creado" \
    || log "  Usuario admin ya existe"

# Intentar generar token (si ya existe, regenerar)
GITEA_TOKEN=""
for attempt in 1 2; do
    GITEA_TOKEN=$(docker exec -u git ud06-gitea gitea admin user generate-access-token \
        --username gitea-admin --token-name "lab-token-$attempt" --raw 2>/dev/null || true)
    [ -n "$GITEA_TOKEN" ] && break
done

if [ -n "$GITEA_TOKEN" ]; then
    HTTP_CODE=$(curl -s -o /dev/null -w "%{http_code}" -X POST \
        "http://172.28.0.64:3000/api/v1/user/repos" \
        -H "Authorization: token $GITEA_TOKEN" \
        -H "Content-Type: application/json" \
        -d '{"name":"calculator-app","description":"Calculadora DevOps","auto_init":false,"private":false}')
    case "$HTTP_CODE" in
        201) ok "Repositorio calculator-app creado" ;;
        409) ok "Repositorio calculator-app ya existe" ;;
        *)   warn "Código HTTP: $HTTP_CODE al crear repo" ;;
    esac
else
    warn "No se pudo obtener token de Gitea"
fi

# ── [6/6] Reiniciar Jenkins ──
echo -e "${BLUE}${BOLD}[6/6]${NC} Reiniciando Jenkins..."
echo -e "  ${YELLOW}⚠ Al reiniciar Jenkins carga plugins + credenciales.${NC}"
echo -e "  ${CYAN}  URL: http://172.28.0.61:8080/login${NC}"
echo ""
docker restart ud06-jenkins > /dev/null
for i in $(seq 1 90); do
    if curl -s --connect-timeout 3 -o /dev/null http://172.28.0.61:8080/login 2>/dev/null; then
        echo -e "  ${CHECK} Jenkins reiniciado y listo (${i}s)"
        break
    fi
    printf "\r${CYAN}  Jenkins reiniciando... ${NC}[%3ds / 270s]" $((i * 3))
    sleep 3
    if [ $i -eq 90 ]; then
        echo -e "\r  ${YELLOW}⚠ Jenkins no responde tras 270s${NC}"
    fi
done

echo ""
echo -e "${GREEN}${BOLD}✅ Configuración completada${NC}"
echo ""
echo -e "${YELLOW}${BOLD}📘 ¿Qué acabamos de hacer?${NC}"
echo ""
echo -e "  ${BOLD}1. Jenkins — Plugins${NC}"
echo -e "     Instalamos 4 plugins esenciales para el pipeline CI/CD:"
echo -e "     • ${BOLD}git${NC} — para clonar repositorios"
echo -e "     • ${BOLD}workflow-aggregator${NC} — para pipelines declarativos (Jenkinsfile)"
echo -e "     • ${BOLD}docker-workflow${NC} — para construir y gestionar imágenes Docker"
echo -e "     • ${BOLD}credentials-binding${NC} — para inyectar credenciales de forma segura"
echo -e "     • ${BOLD}prometheus${NC} — para exponer métricas de Jenkins"
echo ""
echo -e "  ${BOLD}2. Jenkins — Job Calculator-Pipeline${NC}"
echo -e "     Se ha creado el job que ejecutará el pipeline CI/CD. Su configuración"
echo -e "     (pipeline-config.xml) se ha inyectado directamente en el disco de Jenkins,"
echo -e "     evitando tener que configurarlo manualmente por web. El job:"
echo -e "     • Apunta al repositorio Git en http://172.28.0.64:3000/gitea-admin/calculator-app.git"
echo -e "     • Usa el archivo Jenkinsfile como definición del pipeline"
echo -e "     • Polling cada 2 minutos (H/2 * * * *) para detectar cambios"
echo ""
echo -e "  ${BOLD}3. Jenkins — Credenciales Gitea${NC}"
echo -e "     Se ha inyectado un script init.groovy que crea la credencial"
echo -e "     'gitea-admin' (usuario: gitea-admin, password: admin) en el"
echo -e "     almacén de Jenkins. Esto permite que el pipeline pueda autenticarse"
echo -e "     contra Gitea para clonar repositorios."
echo ""
echo -e "  ${BOLD}4. Gitea — Usuario y repositorio${NC}"
echo -e "     • Usuario 'gitea-admin' creado (password: admin)"
echo -e "     • Token de acceso generado para operaciones vía API"
echo -e "     • Repositorio 'calculator-app' creado (vacío, listo para recibir código)"
echo ""
echo -e "${YELLOW}${BOLD}🔗 Arquitectura resultante:${NC}"
echo -e "  ${CYAN}Desarrollador${NC} → ${BOLD}Gitea${NC} (:3000) → ${BOLD}Jenkins${NC} (:8080) → ${BOLD}Docker${NC} (staging/producción)"
echo -e "                                        ↳ Polling cada 2 min"
echo -e "                                        ↳ Credencial: gitea-admin / admin"
echo ""
echo -e "${YELLOW}${BOLD}🔍 COMPROBACIONES MANUALES (navegador):${NC}"
echo -e "  ${BOLD}1) Jenkins job:${NC}  http://172.28.0.61:8080/job/Calculator-Pipeline"
echo -e "     → Debe mostrar el pipeline configurado (sin builds aún)"
echo -e "  ${BOLD}2) Gitea repo:${NC}   http://172.28.0.64:3000/gitea-admin/calculator-app"
echo -e "     → Debe mostrar el repositorio vacío (sin archivos)"
echo ""
echo -e "  ${YELLOW}${BOLD}🔐 Credenciales del laboratorio:${NC}"
echo -e "    ${BOLD}Jenkins:${NC} admin / admin"
echo -e "    ${BOLD}Gitea:${NC}   gitea-admin / admin"
echo -e "    ${BOLD}Grafana:${NC} admin / admin"
echo ""
echo -e "${YELLOW}${BOLD}🏗️  Flujo de despliegue (staging → producción):${NC}"
echo -e "  Cuando ejecutes el paso 05, el pipeline hará:"
echo -e "    ${CYAN}1.${NC} Test unitarios (Node 20)"
echo -e "    ${CYAN}2.${NC} Build imagen Docker"
echo -e "    ${CYAN}3.${NC} Deploy a ${BOLD}Staging${NC} (172.28.0.62) ← código nuevo llega AQUÍ primero"
echo -e "    ${CYAN}4.${NC} Smoke test automatizado (verifica /health)"
echo -e "    ${CYAN}5.${NC} ⏸️ PAUSA — espera tu ${BOLD}aprobación manual${NC}"
echo -e "    ${CYAN}6.${NC} Deploy a ${BOLD}Producción${NC} (172.28.0.63) ← solo tras tu 'Proceed'"
echo ""
echo -e "  ${YELLOW}⚠ Recuerda: Staging es para PRUEBAS, Producción para USUARIOS."
echo -e "     El \"gate\" de aprobación manual separa ambos entornos."
echo ""
echo -e "${BLUE}${BOLD}[⏳]${NC} Estabilizando servicios (2 min)..."
echo -e "  ${YELLOW}⚠ Espera para que Jenkins termine de cargar plugins y credenciales.${NC}"
echo ""
START=$SECONDS
DURATION=120
while [ $((SECONDS - START)) -lt $DURATION ]; do
    ELAPSED=$((SECONDS - START))
    PERCENT=$((ELAPSED * 100 / DURATION))
    FILLED=$((PERCENT * 40 / 100))
    EMPTY=$((40 - FILLED))
    printf "\r  ${CYAN}Estabilizando [${NC}"
    printf "${GREEN}%${FILLED}s${NC}" | tr ' ' '#'
    printf "${YELLOW}%${EMPTY}s${NC}" | tr ' ' '.'
    printf "${CYAN}] ${GREEN}%3d%%${NC}" $PERCENT
    sleep 1
done
printf "\r  ${CHECK} Servicios estabilizados (2 min)\n"
echo ""
echo -e "${YELLOW}${BOLD}💡 Próximo paso:${NC}"
echo -e "  bash ${BOLD}05-launch-example-app-v1.sh${NC}"
echo -e "  → Escribirá el código de la calculadora, lo subirá a Gitea y"
echo -e "    lanzará el primer pipeline CI/CD que lo despliega en staging."
echo ""
