#!/bin/bash
# 99-destroy-network.sh - Elimina la red bridge del host (LabCEFIRE) y el dummy
set -euo pipefail

# Colores y Formato
RED='\033[0;31m'; GREEN='\033[0;32m'; YELLOW='\033[1;33m'; BLUE='\033[0;34m'; NC='\033[0m'
log()  { echo -e "${BLUE}[NETWORK]${NC} $1"; }
ok()   { echo -e "${GREEN}[NETWORK] ✓${NC} $1"; }
fail() { echo -e "${RED}[NETWORK] ✗${NC} $1"; }
warn() { echo -e "${YELLOW}[NETWORK] ⚠${NC} $1"; }

echo -e "${BLUE}╔═══════════════════════════════════════════════════════╗${NC}"
echo -e "${BLUE}║     UD04 - ELIMINACIÓN DE RED BRIDGE                  ║${NC}"
echo -e "${BLUE}╚═══════════════════════════════════════════════════════╝${NC}"

# Check for sudo
if [[ $EUID -ne 0 ]]; then
   warn "Este script requiere privilegios de sudo para modificar interfaces de red."
   SUDO="sudo"
else
   SUDO=""
fi

log "Eliminando bridge LabCEFIRE..."
if ip link show LabCEFIRE &>/dev/null; then
    $SUDO ip link set LabCEFIRE down 2>/dev/null || true
    $SUDO ip link delete LabCEFIRE 2>/dev/null && ok "LabCEFIRE eliminado" || fail "No se pudo eliminar LabCEFIRE"
else
    ok "LabCEFIRE no existe, saltando"
fi

log "Eliminando dummy interface (dum0)..."
if ip link show dum0 &>/dev/null; then
    $SUDO ip link set dum0 down 2>/dev/null || true
    $SUDO ip link delete dum0 2>/dev/null && ok "dum0 eliminado" || fail "No se pudo eliminar dum0"
else
    ok "dum0 no existe, saltando"
fi

ok "Red eliminada completamente"
echo ""
