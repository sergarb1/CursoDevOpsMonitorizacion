#!/bin/bash
# 06-upgrade-to-v2.sh - Evoluciona la App a v2 (Multiplicaci\u00f3n)
# ==============================================================================
set -euo pipefail

# ── Colores ──
BOLD='\033[1m'
RED='\033[0;31m'; GREEN='\033[0;32m'; YELLOW='\033[1;33m'
BLUE='\033[0;34m'; CYAN='\033[0;36m'; NC='\033[0m'
CHECK="${GREEN}✓${NC}"; CROSS="${RED}✗${NC}"; INFO="${CYAN}ℹ${NC}"
log()   { echo -e "${CYAN}[UPGRADE-V2]${NC} $1"; }
ok()    { echo -e "  ${CHECK} $1"; }
fail()  { echo -e "  ${CROSS} $1"; exit 1; }
warn()  { echo -e "  ${YELLOW}⚠${NC} $1"; }

echo -e "${BLUE}${BOLD}"
echo "╔══════════════════════════════════════════════════════════════╗"
echo "║   🚀 UD06 - Paso 6: App v2 (Multiplicaci\u00f3n) - Upgrade  ║"
echo "╚══════════════════════════════════════════════════════════════╝"
echo -e "${NC}"

echo -e "${YELLOW}${BOLD}⏱  Tiempo estimado: 5-12 minutos${NC}"
echo -e "     (push 1m + espera build 3-8m + stages)"
echo ""

echo -e "${YELLOW}${BOLD}📘 ¿Qué vamos a hacer?${NC}"
echo "  Vamos a evolucionar la calculadora de la v1 (suma, azul) a la"
echo "  v2 (multiplicaci\u00f3n, verde). El c\u00f3digo se subir\u00e1 a Gitea,"
echo "  Jenkins detectar\u00e1 el cambio, ejecutar\u00e1 el pipeline completo,"
echo "  y se pausar\u00e1 esperando aprobaci\u00f3n manual para Producci\u00f3n."
echo ""

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
APP_DIR="$(dirname "$SCRIPT_DIR")/app"

# ── [1/4] Modificar c\u00f3digo a v2 ──
echo -e "${BLUE}${BOLD}[1/4]${NC} Escribiendo c\u00f3digo de la app v2 (Multiplicaci\u00f3n)..."
mkdir -p "$APP_DIR/src" "$APP_DIR/tests"

cat <<'V2EOF' > "$APP_DIR/src/index.js"
const express = require('express');
const app = express();
const port = 3000;

app.get('/', (req, res) => {
  const n1 = parseInt(req.query.n1) || 5;
  const n2 = parseInt(req.query.n2) || 5;
  const result = n1 * n2;

  res.send(`
    <html>
      <head>
        <title>Calculadora DevOps - v2</title>
        <style>
          body { font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; text-align: center; padding-top: 50px; background-color: #e8f5e9; }
          .card { background: white; padding: 30px; border-radius: 15px; box-shadow: 0 4px 6px rgba(0,0,0,0.1); display: inline-block; min-width: 300px; border: 2px solid #2e7d32; }
          h1 { color: #2e7d32; }
          input { padding: 10px; width: 60px; margin: 10px; border: 1px solid #ccc; border-radius: 5px; text-align: center; font-size: 1.2em; }
          button { padding: 10px 20px; background: #2e7d32; color: white; border: none; border-radius: 5px; cursor: pointer; font-size: 1em; }
          .result { font-size: 2em; margin-top: 20px; color: #c62828; font-weight: bold; }
          .version { font-size: 0.8em; color: #2e7d32; margin-top: 20px; font-weight: bold; }
        </style>
      </head>
      <body>
        <div class="card">
          <h1>🚀 Calculadora (v2: MULTIPLIER)</h1>
          <form action="/" method="get">
            <input type="number" name="n1" value="${n1}">
            <span>×</span>
            <input type="number" name="n2" value="${n2}">
            <br>
            <button type="submit">Multiplicar Ahora</button>
          </form>
          <div class="result">${n1} × ${n2} = ${result}</div>
          <div class="version">Versi\u00f3n 2.0.0 (PRO) - Entorno: ${process.env.NODE_ENV || 'local'}</div>
        </div>
      </body>
    </html>
  `);
});

app.get('/health', (req, res) => res.json({ status: 'healthy', version: '2.0.0' }));
app.get('/metrics', (req, res) => {
  res.set('Content-Type', 'text/plain');
  res.send('# HELP app_version Version\napp_version{version="2.0.0"} 1\n');
});

app.listen(port, () => {
  console.log('🚀 Calculator v2 (MUL) running on port ' + port);
});
V2EOF

cat <<'V2EOF' > "$APP_DIR/tests/app.test.js"
describe('Calculadora v2', () => {
  test('Multiplicaci\u00f3n b\u00e1sica', () => { expect(5 * 5).toBe(25); });
});
V2EOF
ok "C\u00f3digo v2 escrito"

# ── [2/4] Commit y push a Gitea ──
echo -e "${BLUE}${BOLD}[2/4]${NC} Subiendo v2 a Gitea..."
cd "$APP_DIR"

git checkout -B main 2>/dev/null || git branch -m main
git add .
if ! git diff --cached --exit-code > /dev/null; then
    git commit -m "Upgrade to v2: Multiplication feature" -q
fi

for i in $(seq 1 10); do
    if git push origin main --force -q 2>/dev/null; then
        ok "C\u00f3digo v2 subido a Gitea (rama main)"
        break
    fi
    printf "\r  ${CYAN}Esperando Gitea [%ds / 50s]${NC}" $((i * 5))
    sleep 5
done
ok "Push completado"

# ── [3/4] Disparar pipeline ──
echo -e "${BLUE}${BOLD}[3/4]${NC} Disparando pipeline en Jenkins..."

BEFORE_BUILD=$(curl -s -u admin:admin --connect-timeout 3 \
    "http://172.28.0.61:8080/job/Calculator-Pipeline/lastBuild/api/json" 2>/dev/null | python3 -c \
    "import sys,json; d=json.load(sys.stdin); print(d.get('number',0))" 2>/dev/null || echo 0)
echo -e "  ${INFO} \u00daltimo build antes del trigger: #${BEFORE_BUILD}"

echo -n "  Obteniendo crumb CSRF "
CRUMB=$(curl -s -u admin:admin -c /tmp/jenkins_cookies_v2.txt \
    "http://172.28.0.61:8080/crumbIssuer/api/json" 2>/dev/null | python3 -c \
    "import sys,json; print(json.load(sys.stdin)['crumb'])" 2>/dev/null)
[ -n "$CRUMB" ] && echo -e "\b${CHECK}" || echo -e "\b${CROSS}"

HTTP_CODE=$(curl -s -o /dev/null -w "%{http_code}" -u admin:admin \
    -b /tmp/jenkins_cookies_v2.txt \
    -X POST "http://172.28.0.61:8080/job/Calculator-Pipeline/build" \
    -H "Jenkins-Crumb: $CRUMB")

if [ "$HTTP_CODE" = "201" ]; then
    ok "Build disparado (HTTP $HTTP_CODE)"
else
    warn "HTTP $HTTP_CODE (intentando sin crumb...)"
    HTTP_CODE=$(curl -s -o /dev/null -w "%{http_code}" -u admin:admin \
        -X POST "http://172.28.0.61:8080/job/Calculator-Pipeline/build" 2>/dev/null)
    [ "$HTTP_CODE" = "201" ] && ok "Build disparado!" || warn "HTTP $HTTP_CODE"
fi

# ── [4/4] Seguimiento del build ──
echo -e "${BLUE}${BOLD}[4/4]${NC} Siguiendo el progreso del build..."
echo -e "${YELLOW}${BOLD}⏳ El pipeline tarda entre 3 y 8 minutos${NC}"
echo -e "  (npm install + docker build + smoke test)"
echo ""

BUILD_NUM=""
for i in $(seq 1 40); do
    BUILD_NUM=$(curl -s -u admin:admin --connect-timeout 3 \
        "http://172.28.0.61:8080/job/Calculator-Pipeline/lastBuild/api/json" 2>/dev/null | python3 -c \
        "import sys,json; d=json.load(sys.stdin); print(d.get('number',0))" 2>/dev/null || echo 0)
    if [ "$BUILD_NUM" -gt "$BEFORE_BUILD" ] 2>/dev/null; then
        echo -e "  ${CHECK} Build #${BUILD_NUM} iniciado"
        break
    fi
    printf "\r  ${CYAN}Esperando build [%ds / 120s]${NC}" $((i * 3))
    sleep 3
    if [ $i -eq 40 ]; then
        echo -e "\r  ${YELLOW}⚠ Build no inici\u00f3 tras 120s${NC}"
        BUILD_NUM=""
    fi
done

if [ -n "$BUILD_NUM" ]; then
    LAST_STAGE=""
    POLLS=0
    MAX_POLLS=180
    while [ $POLLS -lt $MAX_POLLS ]; do
        PIPELINE_STATUS=$(curl -s -u admin:admin --connect-timeout 3 \
            "http://172.28.0.61:8080/job/Calculator-Pipeline/${BUILD_NUM}/wfapi/describe" 2>/dev/null)
        STATUS=$(echo "$PIPELINE_STATUS" | python3 -c \
            "import sys,json; d=json.load(sys.stdin); print(d.get('status',''))" 2>/dev/null)

        CURRENT_STAGE=$(echo "$PIPELINE_STATUS" | python3 -c "
import sys,json
d=json.load(sys.stdin)
for s in reversed(d.get('stages',[])):
    st = s.get('status','')
    if st in ('IN_PROGRESS','PAUSED_PENDING_INPUT','FAILED','ABORTED','NOT_EXECUTED'):
        print(f'[{st}] {s.get(\"name\",\"?\")}')
        break
    elif st == 'SUCCESS':
        pass
" 2>/dev/null)

        if [ -z "$CURRENT_STAGE" ]; then
            CURRENT_STAGE=$(echo "$PIPELINE_STATUS" | python3 -c "
import sys,json
d=json.load(sys.stdin)
stages = d.get('stages',[])
if stages:
    last = stages[-1]
    print(f'[{last.get(\"status\",\"?\")}] {last.get(\"name\",\"?\")}')
" 2>/dev/null)
        fi

        [ -n "$CURRENT_STAGE" ] && CURRENT_STAGE=" $CURRENT_STAGE"
        ELAPSED=$((POLLS * 5))

        case "$STATUS" in
            PAUSED_PENDING_INPUT)
                echo ""
                echo -e "  ${CHECK} Pipeline v2 completo — esperando aprobaci\u00f3n manual"
                echo ""
                echo -e "  ${YELLOW}${BOLD}⏸️  Acci\u00f3n requerida:${NC}"
                echo -e "    1. Abre Jenkins: ${BOLD}http://172.28.0.61:8080/job/Calculator-Pipeline/${NC}"
                echo -e "    2. Usuario: ${BOLD}admin${NC} / Contrase\u00f1a: ${BOLD}admin${NC}"
                echo -e "    3. Haz clic en ${BOLD}\"Proceed\"${NC} para desplegar v2 a producci\u00f3n"
                echo ""
                break
                ;;
            SUCCESS)
                echo ""
                echo -e "  ${CHECK} Pipeline v2 completado con \u00e9xito!"
                break
                ;;
            FAILED)
                echo ""
                echo -e "  ${CROSS} Pipeline v2 fall\u00f3"
                echo -e "     Revisa: ${BOLD}http://172.28.0.61:8080/job/Calculator-Pipeline/${BUILD_NUM}/console${NC}"
                break
                ;;
            ABORTED)
                echo ""
                echo -e "  ${YELLOW}⚠ Pipeline v2 cancelado${NC}"
                break
                ;;
        esac

        if [ "$CURRENT_STAGE" != "$LAST_STAGE" ] && [ -n "$CURRENT_STAGE" ]; then
            echo -e "  ${CYAN}▶${NC}${CURRENT_STAGE}"
            LAST_STAGE="$CURRENT_STAGE"
        fi

        printf "\r  ${CYAN}En ejecuci\u00f3n [%3ds / 900s]${NC}" $ELAPSED
        sleep 5
        POLLS=$((POLLS + 1))
    done

    if [ $POLLS -ge $MAX_POLLS ]; then
        echo -e "\r  ${YELLOW}⚠ Tiempo m\u00e1ximo excedido. Revisa el progreso manualmente:${NC}"
    fi
fi

echo ""
echo -e "  ${INFO} Consola del build: ${BOLD}http://172.28.0.61:8080/job/Calculator-Pipeline/${BUILD_NUM:-?}/console${NC}"
echo ""
echo -e "  ${INFO} Contenedores activos:${NC}"
docker ps --format "table {{.Names}}\t{{.Status}}\t{{.Ports}}" 2>/dev/null | grep -E "ud06-(staging|production|gitea|jenkins|postgres|prometheus|grafana|cadvisor)" || true
echo ""
if curl -s --connect-timeout 2 -o /dev/null http://172.28.0.62:3000/health 2>/dev/null; then
    echo -e "  ${CHECK} Staging responde en http://172.28.0.62:3000/health"
else
    echo -e "  ${INFO} Staging a\u00fan no disponible (el pipeline sigue ejecut\u00e1ndose)"
fi
echo ""
echo -e "${GREEN}${BOLD}✅ App v2 enviada y pipeline en marcha${NC}"
echo ""
echo -e "${YELLOW}${BOLD}📘 ¿Qué acaba de suceder?${NC}"
echo ""
echo -e "  ${BOLD}1. C\u00f3digo v2 (multiplicaci\u00f3n)${NC} — Se ha actualizado ${BOLD}src/index.js${NC}"
echo -e "     con la nueva l\u00f3gica (×) y tests. Interfaz cambia a color verde."
echo ""
echo -e "  ${BOLD}2. Push a Gitea${NC} — Los cambios se han subido al repositorio:"
echo -e "     ${BOLD}http://172.28.0.64:3000/gitea-admin/calculator-app${NC}"
echo ""
echo -e "  ${BOLD}3. Trigger Jenkins${NC} — Se ha disparado el pipeline que ejecuta:"
echo ""
echo -e "      ${CYAN}Stage${NC}                ${CYAN}Qu\u00e9 hace${NC}"
echo -e "      ${CHECK} Checkout           Clona la v2 desde Gitea"
echo -e "      ${CHECK} Unit Tests         Ejecuta tests con la nueva l\u00f3gica (×)"
echo -e "      ${CHECK} Build Image        Construye nueva imagen Docker con v2"
echo -e "      ${CHECK} Deploy Staging     Reemplaza contenedor staging con v2"
echo -e "      ${CHECK} Smoke Test Staging Verifica /health responde v2.0.0"
echo -e "      ${BOLD}⏸️  Aprobar${NC}          ${YELLOW}PAUSA — espera tu aprobaci\u00f3n manual${NC}"
echo -e "      ${CHECK} Deploy Production  Actualiza producci\u00f3n con v2"
echo ""
echo -e "${YELLOW}${BOLD}🔗 Flujo completo del pipeline:${NC}"
echo -e "  C\u00f3digo v2 (app/) → Git push → Gitea (:3000) → Jenkins detecta"
echo -e "  → Test (Node 20) → Build (Docker) → Staging (:62, verde) → ✅ Smoke test"
echo -e "  → ⏸️  APRUEBAS → Production (:63, verde)"
echo ""
echo -e "${YELLOW}${BOLD}🔍 COMPROBACIONES MANUALES (navegador):${NC}"
echo ""
echo -e "  ${CYAN}Opci\u00f3n A — En tu navegador web:${NC}"
echo ""
echo -e "    ${BOLD}1) Pipeline Jenkins:${NC}"
echo -e "       Abre: ${BOLD}http://172.28.0.61:8080/job/Calculator-Pipeline/${NC}"
echo -e "       Usuario: ${BOLD}admin${NC} / Contrase\u00f1a: ${BOLD}admin${NC}"
echo -e "       Ver\u00e1s el progreso del build v2"
echo ""
echo -e "    ${BOLD}2) App v2 en Staging (cuando est\u00e9 desplegada):${NC}"
echo -e "       Abre: ${BOLD}http://172.28.0.62:3000/${NC}"
echo -e "       → Debe mostrar la calculadora ${GREEN}verde${NC} (v2: MULTIPLIER)"
echo ""
echo -e "    ${BOLD}3) Health check en Staging:${NC}"
echo -e "       Abre: ${BOLD}http://172.28.0.62:3000/health${NC}"
echo -e "       → Debe mostrar: ${GREEN}{\"status\":\"healthy\",\"version\":\"2.0.0\"}${NC}"
echo ""
echo -e "    ${BOLD}4) App v1 en Producci\u00f3n (a\u00fan no actualizada):${NC}"
echo -e "       Abre: ${BOLD}http://172.28.0.63:3000/${NC}"
echo -e "       → Todav\u00eda muestra la calculadora ${BLUE}azul${NC} (v1: suma)"
echo -e "     ${YELLOW}¿Por qué?${NC} El pipeline se ha pausado en el \"gate\" de"
echo -e "     aprobaci\u00f3n manual. Staging ya tiene la v2 (verde), pero"
echo -e "     Producci\u00f3n solo se actualiza cuando t\u00fa hagas clic en"
echo -e "     ${BOLD}\"Proceed\"${NC} en Jenkins. As\u00ed funciona CI/CD con entornos."
echo ""
echo -e "  ${CYAN}Opci\u00f3n B — Desde terminal:${NC}"
echo -e "    ${BOLD}curl http://172.28.0.62:3000/health${NC}"
echo ""

echo -e "  ${YELLOW}${BOLD}💡 Cuando el build v2 llegue a 'Aprobar despliegue a producci\u00f3n':${NC}"
echo -e "     1. Verifica que staging funciona con v2 (punto 2 y 3 arriba)"
echo -e "     2. Aprueba el despliegue desde la interfaz web de Jenkins (bot\u00f3n \"Proceed\")"
echo -e "     3. Tras la aprobaci\u00f3n, curl http://172.28.0.63:3000/ mostrar\u00e1 v2 verde"
echo ""

echo -e "${YELLOW}${BOLD}🔐 Credenciales del laboratorio:${NC}"
echo -e "    ${BOLD}Jenkins:${NC} admin / admin"
echo -e "    ${BOLD}Gitea:${NC}   gitea-admin / admin"
echo -e "    ${BOLD}Grafana:${NC} admin / admin"
echo ""
echo -e "${YELLOW}${BOLD}📊 Recordatorio — Monitorizaci\u00f3n:${NC}"
echo -e "  Cuando todo est\u00e9 desplegado, puedes ver las m\u00e9tricas en:"
echo -e "    ${BOLD}Grafana:${NC}  http://172.28.0.66:3000  (admin / admin)"
echo -e "    ${BOLD}Prometheus:${NC} http://172.28.0.65:9090"
echo ""

echo -e "${YELLOW}${BOLD}💡 Pr\u00f3ximo paso:${NC}"
echo -e "  bash ${BOLD}07-verify-status.sh${NC}"
echo -e "  → Comparar\u00e1 visualmente los entornos Staging y Producci\u00f3n"
echo -e "    para verificar que todo est\u00e1 sincronizado."
echo ""
