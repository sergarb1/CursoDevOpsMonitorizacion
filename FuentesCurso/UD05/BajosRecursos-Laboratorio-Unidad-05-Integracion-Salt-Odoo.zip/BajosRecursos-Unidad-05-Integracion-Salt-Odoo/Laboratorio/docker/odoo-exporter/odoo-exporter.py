#!/usr/bin/env python3
import time
import xmlrpc.client
from prometheus_client import start_http_server, Gauge
import os
import sys

# CONFIGURACIÓN desde variables de entorno (con valores por defecto)
ODOO_URL = os.getenv("ODOO_URL", "http://localhost:8069")
ODOO_DB = os.getenv("ODOO_DB", "odoo_db")
ODOO_USER = os.getenv("ODOO_USER", "admin")
ODOO_PASS = os.getenv("ODOO_PASS", "admin")
PORT = int(os.getenv("EXPORTER_PORT", 9090))

# MÉTRICAS PROMETHEUS (inicializadas a 0 para evitar "No Data")
users_gauge = Gauge('odoo_users_total', 'Total de usuarios registrados')
partners_gauge = Gauge('odoo_partners_total', 'Total de contactos')
sales_gauge = Gauge('odoo_sales_orders_total', 'Total de pedidos de venta')
products_gauge = Gauge('odoo_products_total', 'Total de productos')
invoices_gauge = Gauge('odoo_invoices_total', 'Total de facturas')
cron_gauge = Gauge('odoo_cron_jobs_pending', 'Tareas programadas pendientes')
# CORREGIDO: el nombre debe coincidir con el dashboard
query_time_gauge = Gauge('odoo_query_duration_seconds', 'Latencia de consulta a la BD')

def set_initial_zero():
    for g in [users_gauge, partners_gauge, sales_gauge, products_gauge, invoices_gauge, cron_gauge, query_time_gauge]:
        g.set(0)

set_initial_zero()

def get_odoo_data():
    try:
        common = xmlrpc.client.ServerProxy(f"{ODOO_URL}/xmlrpc/2/common", allow_none=True)
        uid = common.authenticate(ODOO_DB, ODOO_USER, ODOO_PASS, {})
        
        if not uid:
            print(f"[ERROR] Autenticación fallida para DB='{ODOO_DB}', user='{ODOO_USER}'. Verifica la base de datos.")
            return

        models = xmlrpc.client.ServerProxy(f"{ODOO_URL}/xmlrpc/2/object", allow_none=True)
        start_time = time.time()
        
        # Conteos básicos
        users_gauge.set(models.execute_kw(ODOO_DB, uid, ODOO_PASS, 'res.users', 'search_count', [[]]))
        partners_gauge.set(models.execute_kw(ODOO_DB, uid, ODOO_PASS, 'res.partner', 'search_count', [[]]))
        
        # Modelos opcionales (pueden no existir)
        try:
            sales_gauge.set(models.execute_kw(ODOO_DB, uid, ODOO_PASS, 'sale.order', 'search_count', [[]]))
        except Exception as e:
            print(f"[WARN] No se pudo obtener 'sale.order': {e}")
        try:
            products_gauge.set(models.execute_kw(ODOO_DB, uid, ODOO_PASS, 'product.template', 'search_count', [[]]))
        except Exception as e:
            print(f"[WARN] No se pudo obtener 'product.template': {e}")
        try:
            invoices_gauge.set(models.execute_kw(ODOO_DB, uid, ODOO_PASS, 'account.move', 'search_count', [[]]))
        except Exception as e:
            print(f"[WARN] No se pudo obtener 'account.move': {e}")

        cron_gauge.set(models.execute_kw(ODOO_DB, uid, ODOO_PASS, 'ir.cron', 'search_count', [[['active', '=', True]]]))
        
        duration = time.time() - start_time
        query_time_gauge.set(duration)
        print(f"[OK] DB='{ODOO_DB}' | users={users_gauge._value.get()} | partners={partners_gauge._value.get()} | latencia={duration:.3f}s")

    except Exception as e:
        print(f"[ERROR] Excepción en get_odoo_data: {e}")
        # No reseteamos las métricas a 0 para conservar el último valor conocido

if __name__ == '__main__':
    print(f"🚀 Odoo Exporter iniciado en puerto {PORT}")
    print(f"   Conectando a Odoo: {ODOO_URL}")
    print(f"   Base de datos: {ODOO_DB}")
    start_http_server(PORT)
    while True:
        get_odoo_data()
        time.sleep(20)