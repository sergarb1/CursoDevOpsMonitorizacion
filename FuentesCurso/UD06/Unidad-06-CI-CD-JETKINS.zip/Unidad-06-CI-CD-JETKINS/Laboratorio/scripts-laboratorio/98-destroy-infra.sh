#!/bin/bash
# 98-destroy-infra.sh - Destrucción completa del laboratorio (preserva imágenes Hub)
# ================================================================================
# Elimina contenedores, volúmenes, imágenes locales, estado Terraform y la red.
# Las imágenes de Docker Hub (Gitea, Jenkins, Prometheus, etc.) se conservan
# para reuso offline.
set -uo pipefail

BOLD='\033[1m'
RED='\033[0;31m'; GREEN='\033[0;32m'; YELLOW='\033[1;33m'
BLUE='\033[0;34m'; CYAN='\033[0;36m'; NC='\033[0m'
CHECK="${GREEN}✓${NC}"; CROSS="${RED}✗${NC}"; INFO="${CYAN}ℹ${NC}"
log()   { echo -e "${BLUE}[DESTROY]${NC} $1"; }
ok()    { echo -e "  ${CHECK} $1"; }
warn()  { echo -e "  ${YELLOW}⚠${NC} $1"; }

# ── Aceptar flag --force / -f ──
FORCE=false
[[ "${1:-}" == "--force" || "${1:-}" == "-f" ]] && FORCE=true

echo -e "${RED}${BOLD}"
echo "╔══════════════════════════════════════════════════════════════╗"
echo "║     ⚠️  UD06 - DESTRUCCIÓN TOTAL DEL LABORATORIO           ║"
echo "╚══════════════════════════════════════════════════════════════╝"
echo -e "${NC}"

echo "  Esto eliminará de forma PERMANENTE:"
echo "    ✗ Contenedores: PostgreSQL, Gitea, Jenkins, Staging, Prod, Prometheus, Grafana, cAdvisor"
echo "    ✗ Contenedores de app que Jenkins hubiera dejado (calculator-app)"
echo "    ✗ Volúmenes Docker (jenkins-data, postgres-data)"
echo "    ✗ Imágenes locales construidas (calculator-app, ud06-jenkins-custom)"
echo "    ✗ Estado de Terraform (.tfstate, .terraform/)"
echo "    ✗ Red Docker LabCEFIRE"
echo ""
echo -e "${GREEN}  ✓ Las imágenes de Docker Hub se MANTIENEN (modo offline)${NC}"
echo ""

if ! $FORCE; then
  read -p "  ¿Estás seguro? (s/N): " confirm
  if [[ ! "$confirm" =~ ^[sS]$ ]]; then
      echo "  Operación cancelada."
      exit 0
  fi
fi

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
LAB_DIR="$(dirname "$SCRIPT_DIR")"
TERRAFORM_DIR="$(dirname "$(dirname "$SCRIPT_DIR")")/Terraform"
GITEA_DATA_DIR="$LAB_DIR/data/gitea"

# ── 1. Destrucción vía Terraform (ordenada) ──
echo -e "\n${BLUE}${BOLD}[1/6]${NC} Destruyendo infraestructura vía Terraform..."
if [ -d "$TERRAFORM_DIR" ]; then
  cd "$TERRAFORM_DIR"
  if [ -f terraform.tfstate ]; then
    terraform destroy -auto-approve 2>/dev/null && ok "Terraform destroy completado" \
      || warn "Falló terraform destroy (continuando con limpieza manual)"
  else
    log "  Sin estado Terraform, saltando..."
    ok "Sin estado que destruir"
  fi
else
  warn "Directorio Terraform no encontrado en $TERRAFORM_DIR"
fi

# ── 2. Forzar eliminación de contenedores (por si Terraform falló o hay restos) ──
echo -e "\n${BLUE}${BOLD}[2/6]${NC} Eliminando contenedores..."
CONTAINERS=(
  ud06-gitea ud06-jenkins ud06-postgres ud06-staging ud06-production
  ud06-prometheus ud06-grafana ud06-cadvisor
)
for c in "${CONTAINERS[@]}"; do
  if docker inspect "$c" >/dev/null 2>&1; then
    docker rm -f "$c" >/dev/null 2>&1 && log "  Eliminado: $c"
  fi
done

# También contenedores sueltos que Jenkins pudiera haber creado
for c in $(docker ps -a --filter "name=calculator-app" --format "{{.Names}}" 2>/dev/null); do
  docker rm -f "$c" >/dev/null 2>&1 && log "  Eliminado: $c"
done
ok "Contenedores eliminados"

# ── 3. Eliminar volúmenes Docker ──
echo -e "\n${BLUE}${BOLD}[3/6]${NC} Eliminando volúmenes Docker y datos persistentes..."
for vol in jenkins-data postgres-data; do
  if docker volume inspect "$vol" >/dev/null 2>&1; then
    docker volume rm "$vol" >/dev/null 2>&1 && log "  Volumen eliminado: $vol"
  fi
done

# Eliminar datos de Gitea (bind mount, SQLite)
if [ -d "$GITEA_DATA_DIR" ]; then
  rm -rf "${GITEA_DATA_DIR:?}"/* 2>/dev/null
  log "  Datos Gitea eliminados: $GITEA_DATA_DIR"
fi
ok "Datos persistentes eliminados"

# Eliminar volúmenes anónimos (creados por docker run sin nombre)
for v in $(docker volume ls -q --filter "label=com.docker.volume.anonymous" 2>/dev/null); do
  docker volume rm -f "$v" >/dev/null 2>&1 && log "  Volumen anónimo eliminado: ${v:0:12}..."
done

# ── 4. Eliminar imágenes construidas localmente ──
echo -e "\n${BLUE}${BOLD}[4/6]${NC} Eliminando imágenes locales (no de Hub)..."
for img in calculator-app:latest ud06-jenkins-custom:latest; do
  if docker image inspect "$img" >/dev/null 2>&1; then
    docker rmi "$img" >/dev/null 2>&1 && log "  Imagen eliminada: $img"
  fi
done
ok "Imágenes locales eliminadas"

# ── 5. Limpiar estado de Terraform ──
echo -e "\n${BLUE}${BOLD}[5/6]${NC} Limpiando archivos de Terraform..."
if [ -d "$TERRAFORM_DIR" ]; then
  rm -f "$TERRAFORM_DIR/terraform.tfstate"* 2>/dev/null
  rm -f "$TERRAFORM_DIR/.terraform.lock.hcl" 2>/dev/null
  rm -rf "$TERRAFORM_DIR/.terraform" 2>/dev/null
  log "  .tfstate, .terraform/ y lock.hcl eliminados"
fi
ok "Estado Terraform limpiado"

# ── 6. Eliminar red LabCEFIRE ──
echo -e "\n${BLUE}${BOLD}[6/6]${NC} Eliminando red LabCEFIRE..."
NETWORK_NAME="LabCEFIRE"
if docker network inspect "$NETWORK_NAME" >/dev/null 2>&1; then
  # Verificar que no queden contenedores conectados
  REMAINING=$(docker network inspect "$NETWORK_NAME" --format '{{json .Containers}}' 2>/dev/null)
  if [[ "$REMAINING" != "{}" && -n "$REMAINING" ]]; then
    warn "  Aún hay contenedores conectados a la red:"
    docker network inspect "$NETWORK_NAME" --format '{{range $k, $v := .Containers}}{{.Name}}{{"\n"}}{{end}}' 2>/dev/null
    log "  Forzando eliminación de la red..."
  fi
  docker network rm "$NETWORK_NAME" >/dev/null 2>&1 && ok "Red LabCEFIRE eliminada" \
    || warn "No se pudo eliminar la red (puede estar en uso por otro proceso)"
else
  ok "Red LabCEFIRE no existe"
fi

# ── Resumen final ──
echo ""
echo -e "${GREEN}${BOLD}╔══════════════════════════════════════════════════════════╗${NC}"
echo -e "${GREEN}${BOLD}║     ✅ Laboratorio UD06 reseteado por completo         ║${NC}"
echo -e "${GREEN}${BOLD}║     Imágenes de Hub preservadas (modo offline)        ║${NC}"
echo -e "${GREEN}${BOLD}╚══════════════════════════════════════════════════════════╝${NC}"
echo ""
echo -e "  ${YELLOW}💡 Para volver a desplegar desde cero:${NC}"
echo -e "     ${BOLD}bash 01-setup-network.sh${NC}"
echo -e "     ${BOLD}bash 02-pull-images.sh${NC}"
echo -e "     ${BOLD}bash 03-deploy-infrastructure.sh${NC}"
echo -e "     ${BOLD}bash 04-configure-tools.sh${NC}"
echo ""
