#!/bin/bash
# 02-deploy-infra.sh - Despliegue de infraestructura con Vagrant
set -e

RED='\033[0;31m'; GREEN='\033[0;32m'; YELLOW='\033[1;33m'; BLUE='\033[0;34m'; NC='\033[0m'

echo -e "\n${BLUE}╔═══════════════════════════════════════════════════════╗${NC}"
echo -e "${BLUE}║     UD02 - FASE 2: Despliegue de Infraestructura   ║${NC}"
echo -e "${BLUE}╚═══════════════════════════════════════════════════════╝${NC}"

# Navegar a la carpeta raíz de Vagrant (estamos en scripts-laboratorio/)
DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" >/dev/null 2>&1 && pwd )"
cd "$DIR/.."

echo -e "${BLUE}[VAGRANT]${NC} Levantando máquinas virtuales..."
echo -e "${YELLOW}Este proceso puede tardar unos minutos (descarga de box y provisión)...${NC}\n"
vagrant up

echo -e "\n${GREEN}✓${NC} Infraestructura levantada correctamente."
echo -e "${YELLOW}NOTA: Ejecuta 03-verify-lab.sh para comprobar el estado de los servicios.${NC}\n"
