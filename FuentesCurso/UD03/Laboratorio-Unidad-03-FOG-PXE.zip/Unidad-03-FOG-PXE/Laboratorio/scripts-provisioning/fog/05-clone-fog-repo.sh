#!/bin/bash
# 05-clone-fog-repo.sh - Clonar repositorio de FOG Project
set -e

echo "=========================================="
echo "📥 [FOG] Clonando repositorio de FOG..."
echo "=========================================="

cd /opt
if [ ! -d "fogproject" ]; then
    git clone https://github.com/FOGProject/fogproject.git
    echo "✅ [FOG] Repositorio clonado en /opt/fogproject"
else
    echo "✅ [FOG] Repositorio ya existe, actualizando..."
    cd fogproject
    git pull
fi

echo ""
echo "=========================================="
echo "⚠️  [FOG] SIGUIENTE PASO MANUAL:"
echo "=========================================="
echo "Ejecuta la instalación interactiva de FOG:"
echo "  sudo /opt/fogproject/bin/installfog.sh"
echo ""
echo "Configuración recomendada:"
echo "  - DHCP Server: Y"
echo "  - Interface: eth1 (la que tiene IP 172.28.0.30)"
echo "  - IP: 172.28.0.30"
echo "  - Subnet: 255.255.255.0"
echo "  - Router: 172.28.0.1"
echo "  - DNS: 172.28.0.1"
echo "  - FOG Client: N"
echo "  - Web Server: Y"
echo "  - MySQL: Y"
echo "  - NFS: Y"
echo "=========================================="
