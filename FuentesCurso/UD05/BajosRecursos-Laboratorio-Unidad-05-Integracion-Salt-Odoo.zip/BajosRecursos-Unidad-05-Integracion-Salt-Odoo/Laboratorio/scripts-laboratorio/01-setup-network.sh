#!/bin/bash
# 01-setup-network.sh - Prepara la red Docker compartida para el laboratorio
set -e

RED='\033[0;31m'; GREEN='\033[0;32m'; BLUE='\033[0;34m'; NC='\033[0m'

echo -e "${BLUE}╔═══════════════════════════════════════════════════════╗${NC}"
echo -e "${BLUE}║     UD05 - Configuración de Red                    ║${NC}"
echo -e "${BLUE}╚═══════════════════════════════════════════════════════╝${NC}"

# Nombre de la red (compartida con otros laboratorios)
NETWORK_NAME="LabCEFIRE"

if docker network inspect "$NETWORK_NAME" >/dev/null 2>&1; then
    echo -e "${GREEN}✓${NC} La red '${NETWORK_NAME}' ya existe."
else
    echo -e "${BLUE}[RED]${NC} Creando red '${NETWORK_NAME}' (172.28.0.0/24)..."
    docker network create --subnet=172.28.0.0/24 "$NETWORK_NAME"
    echo -e "${GREEN}✓${NC} Red creada con éxito."
fi

echo ""
docker network ls | grep "$NETWORK_NAME"
echo ""
