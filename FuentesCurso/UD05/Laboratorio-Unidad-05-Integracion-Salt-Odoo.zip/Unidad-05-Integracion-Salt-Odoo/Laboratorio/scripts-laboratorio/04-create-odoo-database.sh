#!/bin/bash
# ============================================================================
# 04-create-odoo-database.sh - Crea BD en Odoo con datos demo (JSON-RPC)
# ============================================================================

set -u

# ----------------------------------------------------------------------------
# CONFIGURACIÓN
# ----------------------------------------------------------------------------
ODOO1_HOST="172.28.0.57"
ODOO1_PORT="8069"
ODOO2_HOST="172.28.0.58"
ODOO2_PORT="8069"

MASTER_PWD="admin"
DB_NAME="odoo_db"
ADMIN_EMAIL="admin"
ADMIN_PASSWORD="admin"
LANGUAGE="es_ES"
COUNTRY="ES"

PG1_CONTAINER="odoo-pg1"
PG2_CONTAINER="odoo-pg2"
PG_USER="odoo"

ODOO1_CONTAINER="odoo-minion-1"
ODOO2_CONTAINER="odoo-minion-2"

GRAFANA_URL="http://172.28.0.56:3000"
GRAFANA_USER="admin"
GRAFANA_PASS="admin"

# ----------------------------------------------------------------------------
# COLORES
# ----------------------------------------------------------------------------
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
CYAN='\033[0;36m'
NC='\033[0m'

ok()   { echo -e "  ${GREEN}[OK]${NC} $1"; }
info() { echo -e "  ${CYAN}[INFO]${NC} $1"; }
warn() { echo -e "  ${YELLOW}[WARN]${NC} $1"; }
err()  { echo -e "  ${RED}[ERROR]${NC} $1"; }

# ----------------------------------------------------------------------------
# BARRA DE PROGRESO
# ----------------------------------------------------------------------------
progress_bar() {
    local duration=$1
    local message=$2
    local width=40
    local elapsed=0
    echo -ne "${CYAN}${message} ${NC}["
    while [ $elapsed -lt $duration ]; do
        local percent=$((elapsed * 100 / duration))
        local filled=$((percent * width / 100))
        local empty=$((width - filled))
        printf "\r${CYAN}${message} ${NC}["
        printf "${GREEN}%${filled}s${NC}" | tr ' ' '#'
        printf "${YELLOW}%${empty}s${NC}" | tr ' ' '.'
        printf "] ${GREEN}%3d%%${NC}" $percent
        sleep 1
        elapsed=$((elapsed + 1))
    done
    printf "\r${CYAN}${message} ${NC}["
    printf "${GREEN}%${width}s${NC}" | tr ' ' '#'
    printf "] ${GREEN}100%%${NC}\n"
}

# ----------------------------------------------------------------------------
# FUNCIÓN PRINCIPAL
# ----------------------------------------------------------------------------
create_odoo_db() {
    local ODOO_HOST=$1
    local ODOO_PORT=$2
    local ODOO_NAME=$3
    local PG_CONTAINER=$4

    echo ""
    echo "===================================================================="
    echo "  Creando BD en ${ODOO_NAME} (${ODOO_HOST}:${ODOO_PORT})"
    echo "===================================================================="
    echo ""

    # 1. Permisos PostgreSQL
    echo "[1/6] Configurando PostgreSQL..."
    docker exec -i "$PG_CONTAINER" psql -U "$PG_USER" -d postgres -c "ALTER USER ${PG_USER} CREATEDB;" >/dev/null 2>&1
    ok "PostgreSQL listo"

    # 2. Esperar Odoo (HTTP)
    echo "[2/6] Esperando Odoo..."
    MAX_WAIT=180
    START_TIME=$(date +%s)
    while true; do
        HTTP_CODE=$(curl -sL -o /dev/null -w "%{http_code}" "http://${ODOO_HOST}:${ODOO_PORT}/web/login" 2>/dev/null)
        if [ "$HTTP_CODE" = "200" ] || [ "$HTTP_CODE" = "302" ]; then
            ok "Odoo responde (HTTP $HTTP_CODE)"
            break
        fi
        ELAPSED=$(( $(date +%s) - START_TIME ))
        if [ $ELAPSED -ge $MAX_WAIT ]; then
            err "Odoo no respondió tras ${MAX_WAIT}s"
            return 1
        fi
        if [ $((ELAPSED % 10)) -eq 0 ] && [ $ELAPSED -gt 0 ]; then
            progress_bar 10 "  ⏳ Esperando respuesta de ${ODOO_NAME}"
        else
            sleep 2
        fi
    done

    # 3. Verificar si la BD ya existe
    echo "[3/6] Verificando BD..."
    DB_LIST=$(curl -s "http://${ODOO_HOST}:${ODOO_PORT}/web/database/list" 2>/dev/null)
    if echo "$DB_LIST" | grep -q "\"${DB_NAME}\""; then
        warn "BD ya existe, saltando creación"
    else
        ok "BD no existe"
        echo "[4/6] Creando base de datos con demo (JSON-RPC)..."
        # Usar JSON-RPC (compatible Odoo 17+)
        JSON_DATA=$(cat <<EOF
{
    "jsonrpc": "2.0",
    "method": "call",
    "params": {
        "service": "db",
        "method": "create_database",
        "args": [
            "${MASTER_PWD}",
            "${DB_NAME}",
            true,
            "${LANGUAGE}",
            "${ADMIN_EMAIL}",
            "${ADMIN_PASSWORD}",
            "${COUNTRY}"
        ]
    }
}
EOF
)
        RESP=$(curl -s -X POST "http://${ODOO_HOST}:${ODOO_PORT}/jsonrpc" \
            -H "Content-Type: application/json" \
            -d "$JSON_DATA")
        if echo "$RESP" | grep -q 'result.*true'; then
            ok "BD creada correctamente"
        else        # Esperar un par de segundos para que se complete
            sleep 5
            DB_LIST=$(curl -s "http://${ODOO_HOST}:${ODOO_PORT}/web/database/list")
            if echo "$DB_LIST" | grep -q "\"${DB_NAME}\""; then
                ok "BD verificada en la lista"
            else
                warn "BD no aparece en la lista, pero puede estar en proceso"
            fi
        fi

        
    fi

    # 5. Esperar instalación de módulos demo
    echo "[5/6] Esperando inicialización completa de demo..."
    progress_bar 90 "  ⏳ Instalando módulos demo"

    # 6. Reiniciar exporters
    echo "[6/6] Reiniciando exporters..."
    docker exec "$ODOO1_CONTAINER" pkill -f odoo-exporter.py 2>/dev/null || true
    docker exec "$ODOO2_CONTAINER" pkill -f odoo-exporter.py 2>/dev/null || true
    sleep 3
    docker exec "$ODOO1_CONTAINER" nohup python3 /opt/odoo-exporter.py > /tmp/exporter.log 2>&1 &
    docker exec "$ODOO2_CONTAINER" nohup python3 /opt/odoo-exporter.py > /tmp/exporter.log 2>&1 &
    ok "Exporters reiniciados"

    # 7. Verificación de autenticación (con tiempo real)
    echo ""
    info "Verificando login..."
    MAX_AUTH_WAIT=100
    AUTH_START=$(date +%s)
    while true; do
        AUTH_RESP=$(curl -s "http://${ODOO_HOST}:${ODOO_PORT}/jsonrpc" \
            -H "Content-Type: application/json" \
            -d "{
                \"jsonrpc\":\"2.0\",
                \"method\":\"call\",
                \"params\":{
                    \"service\":\"common\",
                    \"method\":\"authenticate\",
                    \"args\":[
                        \"${DB_NAME}\",
                        \"${ADMIN_EMAIL}\",
                        \"${ADMIN_PASSWORD}\",
                        {}
                    ]
                }
            }")
        if echo "$AUTH_RESP" | grep -q '"result":' && ! echo "$AUTH_RESP" | grep -q '"result":false'; then
            ok "Login OK"
            break
        fi
        ELAPSED=$(( $(date +%s) - AUTH_START ))
        if [ $ELAPSED -ge $MAX_AUTH_WAIT ]; then
            warn "Login no verificado tras ${MAX_AUTH_WAIT}s, pero la BD puede estar lista"
            break
        fi
        if [ $((ELAPSED % 10)) -eq 0 ] && [ $ELAPSED -gt 0 ]; then
            progress_bar 10 "  ⏳ Autenticando en ${ODOO_NAME}"
        else
            sleep 2
        fi
    done

    echo ""
    echo "  ${GREEN}✓${NC} ${ODOO_NAME} lista:"
    echo "    http://${ODOO_HOST}:${ODOO_PORT}/web/login?db=${DB_NAME}"
    echo ""
}

# ----------------------------------------------------------------------------
# MAIN
# ----------------------------------------------------------------------------
echo ""
echo "=================================================================="
echo "              ODOO DATABASE AUTO CREATOR (JSON-RPC)"
echo "=================================================================="
echo ""

create_odoo_db "$ODOO1_HOST" "$ODOO1_PORT" "Odoo 1" "$PG1_CONTAINER"
create_odoo_db "$ODOO2_HOST" "$ODOO2_PORT" "Odoo 2" "$PG2_CONTAINER"

echo ""
echo "=================================================================="
echo "              PROCESO TERMINADO"
echo "=================================================================="
echo ""
echo "📊 Odoo 1: http://${ODOO1_HOST}:${ODOO1_PORT}/web/login?db=${DB_NAME}"
echo "📊 Odoo 2: http://${ODOO2_HOST}:${ODOO2_PORT}/web/login?db=${DB_NAME}"
echo ""
echo "🔑 Credenciales Odoo:"
echo "   Usuario: ${ADMIN_EMAIL}"
echo "   Password: ${ADMIN_PASSWORD}"
echo ""
echo "📈 Grafana: ${GRAFANA_URL}"
echo "   Usuario: ${GRAFANA_USER}"
echo "   Password: ${GRAFANA_PASS}"
echo ""