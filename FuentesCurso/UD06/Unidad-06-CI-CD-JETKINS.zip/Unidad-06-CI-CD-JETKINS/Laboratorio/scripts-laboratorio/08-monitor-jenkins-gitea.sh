#!/bin/bash
# 08-monitor-jenkins-gitea.sh - Monitorización por API de Git y CI/CD
set -euo pipefail

RED='\033[0;31m'; GREEN='\033[0;32m'; YELLOW='\033[1;33m'; BLUE='\033[0;34m'; CYAN='\033[0;36m'; NC='\033[0m'
BOLD='\033[1m'

echo -e "${BLUE}${BOLD}"
echo "╔══════════════════════════════════════════════════════════════╗"
echo "║   📊 UD06 - Paso 8: Monitorizacion Gitea + Jenkins        ║"
echo "╚══════════════════════════════════════════════════════════════╝"
echo -e "${NC}"

echo -e "${YELLOW}${BOLD}📘 ¿Qué hace este script?${NC}"
echo "  Consulta las APIs de Gitea (último commit) y Jenkins (estado del"
echo "  pipeline) para mostrarte un resumen rápido del sistema CI/CD."
echo ""

# 1. Consultar Gitea
echo -e "\n${YELLOW}💾 ESTADO DEL REPOSITORIO (Gitea API):${NC}"
REPO_INFO=$(curl -s -u gitea-admin:admin http://172.28.0.64:3000/api/v1/repos/gitea-admin/calculator-app)
if echo "$REPO_INFO" | grep -q "id"; then
    LAST_COMMIT=$(curl -s -u gitea-admin:admin http://172.28.0.64:3000/api/v1/repos/gitea-admin/calculator-app/commits | grep -m 1 "message" | cut -d'"' -f4)
    echo -e "  ✅ Repositorio: ${GREEN}Conectado${NC}"
    echo -e "  📝 Último Cambio: ${BLUE}$LAST_COMMIT${NC}"
else
    echo -e "  ❌ Repositorio: ${RED}No encontrado o Gitea caído.${NC}"
fi

# 2. Consultar Jenkins
echo -e "\n${YELLOW}🔧 ESTADO DEL PIPELINE (Jenkins API):${NC}"
INITIAL_PASSWORD=$(docker exec ud06-jenkins cat /var/jenkins_home/secrets/initialAdminPassword 2>/dev/null || echo "admin")
JOB_INFO=$(curl -s -u admin:$INITIAL_PASSWORD http://172.28.0.61:8080/job/Calculator-Pipeline/api/json)

if echo "$JOB_INFO" | grep -q "color"; then
    STATUS=$(echo "$JOB_INFO" | grep -o '"color":"[^"]*"' | cut -d'"' -f4)
    LAST_BUILD=$(echo "$JOB_INFO" | grep -o '"number":[0-9]*' | head -1 | cut -d':' -f2)
    
    echo -e "  ✅ Pipeline: ${GREEN}Activo${NC}"
    echo -e "  🔢 Último Build: #${BLUE}$LAST_BUILD${NC}"
    
    if [[ "$STATUS" == *"_anime" ]]; then
        echo -e "  ⏳ Estado Actual: ${YELLOW}EJECUTANDO AHORA MISMO...${NC}"
    elif [[ "$STATUS" == "blue" ]]; then
        echo -e "  🎬 Estado Actual: ${GREEN}ÉXITO (Listo)${NC}"
    elif [[ "$STATUS" == "red" ]]; then
        echo -e "  🎬 Estado Actual: ${RED}FALLIDO (Revisa el código)${NC}"
    else
        echo -e "  🎬 Estado Actual: ${YELLOW}ESPERANDO ACCIÓN (Pausado)${NC}"
    fi
    
    # Mostrar estado de los entornos si el pipeline no está ejecutándose
    if [[ "$STATUS" != *"_anime" ]]; then
        echo ""
        echo -e "  ${CYAN}🏗️  Estado de entornos:${NC}"
        STAGING_UP=$(curl -s -o /dev/null -w "%{http_code}" --connect-timeout 2 http://172.28.0.62:3000/health 2>/dev/null || echo "000")
        PROD_UP=$(curl -s -o /dev/null -w "%{http_code}" --connect-timeout 2 http://172.28.0.63:3000/health 2>/dev/null || echo "000")
        
        if [ "$STAGING_UP" = "200" ]; then
            echo -e "    ${GREEN}✅${NC} Staging (62)    — responde (health check OK)"
        else
            echo -e "    ${YELLOW}⏸️${NC} Staging (62)    — sin app o pipeline no ejecutado"
        fi
        if [ "$PROD_UP" = "200" ]; then
            echo -e "    ${GREEN}✅${NC} Producción (63) — responde"
        else
            echo -e "    ${YELLOW}⏸️${NC} Producción (63) — sin app (o pendiente de aprobar)"
        fi
        echo ""
        echo -e "  ${YELLOW}💡 Si staging responde y producción no: el pipeline está esperando${NC}"
        echo -e "  ${YELLOW}   tu aprobación manual (botón Proceed en Jenkins).${NC}"
    fi
else
    echo -e "  ❌ Pipeline: ${RED}No encontrado. Asegúrate de lanzar el script 03 y 04.${NC}"
fi

echo -e "\n${BLUE}═══════════════════════════════════════════════════════${NC}"

echo -e "${YELLOW}🔐 Credenciales del laboratorio:${NC}"
echo -e "    ${BOLD}Jenkins:${NC} admin / admin"
echo -e "    ${BOLD}Gitea:${NC}   gitea-admin / admin"
echo -e "    ${BOLD}Grafana:${NC} admin / admin"
echo ""

echo -e "${YELLOW}🔍 PRÓXIMOS PASOS:${NC}"
echo "  - Si el pipeline está pausado: Ve a Jenkins y dale a 'Proceed'."
echo "  - Si el último cambio no te convence: Haz otro cambio con el script 05."
echo ""
echo -e "${YELLOW}📊 Monitorización:${NC}"
echo -e "    ${BOLD}Grafana:${NC}    http://172.28.0.66:3000  (admin / admin)"
echo -e "    ${BOLD}Prometheus:${NC} http://172.28.0.65:9090"
echo -e "    ${BOLD}cAdvisor:${NC}  http://172.28.0.67:8080"
echo ""
