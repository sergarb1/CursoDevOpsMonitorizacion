#!/bin/bash
# 02-deploy-golden.sh - Despliega la Golden-VM y muestra su MAC
set -e
RED='\033[0;31m'; GREEN='\033[0;32m'; BLUE='\033[0;34m'; YELLOW='\033[1;33m'; NC='\033[0m'

echo -e "${BLUE}╔═══════════════════════════════════════════════════════╗${NC}"
echo -e "${BLUE}║     UD03 - Despliegue de Golden-VM (Template)       ║${NC}"
echo -e "${BLUE}╚═══════════════════════════════════════════════════════╝${NC}"

cd "$(dirname "${BASH_SOURCE[0]}")/../Taller-FOG"
vagrant up Golden-VM

echo -e "\n${YELLOW}[INFO]${NC} Extrayendo dirección MAC para FOG..."
MAC=$(VBoxManage showvminfo Golden-VM-UD03 --machinereadable | grep "macaddress2" | cut -d'=' -f2 | tr -d '"' | sed 's/.\{2\}/&:/g; s/.$//')

echo -e "${GREEN}╔═══════════════════════════════════════════════════════╗${NC}"
echo -e "${GREEN}║  ✅ Golden-VM Lista                                   ║${NC}"
echo -e "${GREEN}╠═══════════════════════════════════════════════════════╣${NC}"
echo -e "${GREEN}║  📍 IP:  172.28.0.31                                  ║${NC}"
echo -e "${GREEN}║  🔌 MAC: $MAC                        ║${NC}"
echo -e "${GREEN}╚═══════════════════════════════════════════════════════╝${NC}"
echo -e "${YELLOW}Anota esta MAC. La necesitarás para el Host Management en FOG.${NC}\n"
