#!/bin/bash
# 98-destroy-infra.sh - Elimina la infraestructura Vagrant
set -e

# Colores
RED='\033[0;31m'; GREEN='\033[0;32m'; BLUE='\033[0;34m'; YELLOW='\033[1;33m'; NC='\033[0m'

echo -e "${RED}╔═══════════════════════════════════════════════════════╗${NC}"
echo -e "${RED}║     ⚠️  UD03 - DESTRUCCIÓN DE INFRAESTRUCTURA (VMs)  ║${NC}"
echo -e "${RED}╚═══════════════════════════════════════════════════════╝${NC}"

read -p "  ¿Deseas eliminar las máquinas virtuales del laboratorio? (s/N): " confirm
if [[ ! "$confirm" =~ ^[sS]$ ]]; then
    echo "  Operación cancelada."
    exit 0
fi

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
VAGRANT_DIR="$SCRIPT_DIR/../Taller-FOG"

echo -e "${RED}[VAGRANT]${NC} Destruyendo máquinas virtuales..."
cd "$VAGRANT_DIR"
vagrant destroy -f

echo -e "${GREEN}✓${NC} Infraestructura eliminada."
echo ""
