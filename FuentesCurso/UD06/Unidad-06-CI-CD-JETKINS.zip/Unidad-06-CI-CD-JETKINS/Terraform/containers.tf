# ── Imagen Base Node (para build local) ──
resource "docker_image" "node_base" {
  name = "node:20-alpine"
}

# ── Imagen Gitea ──
resource "docker_image" "gitea_img" {
  name = "gitea/gitea:1.17"
}

# ── Imagen Jenkins (Personalizada con Docker CLI) ──
resource "docker_image" "jenkins_img" {
  name = "ud06-jenkins-custom:latest"
  build {
    context    = "../Laboratorio/jenkins"
    dockerfile = "Dockerfile"
  }
}

# ── Imágenes Monitorización ──
resource "docker_image" "prometheus_img" {
  name = "prom/prometheus:latest"
}

resource "docker_image" "grafana_img" {
  name = "grafana/grafana:latest"
}

resource "docker_image" "cadvisor_img" {
  name = "gcr.io/cadvisor/cadvisor:latest"
}

# ── Imagen PostgreSQL ──
resource "docker_image" "postgres_img" {
  name = "postgres:16-alpine"
}

# ── PostgreSQL (Base de datos para Gitea) ──
resource "docker_container" "postgres" {
  name     = "ud06-postgres"
  image    = docker_image.postgres_img.image_id
  hostname = "postgres"
  restart  = "unless-stopped"

  networks_advanced {
    name         = data.docker_network.ud06_net.name
    ipv4_address = var.postgres_ip
  }

  volumes {
    volume_name    = docker_volume.postgres_data.name
    container_path = "/var/lib/postgresql/data"
  }

  env = [
    "POSTGRES_USER=gitea",
    "POSTGRES_PASSWORD=gitea",
    "POSTGRES_DB=gitea"
  ]
}

# ── Gitea (Git Local) ──
resource "docker_container" "gitea" {
  name     = "ud06-gitea"
  image    = docker_image.gitea_img.image_id
  hostname = "gitea"
  restart  = "unless-stopped"
  depends_on = [docker_container.postgres]

  networks_advanced {
    name         = data.docker_network.ud06_net.name
    ipv4_address = var.gitea_ip
  }

  volumes {
    host_path      = abspath("${path.module}/../Laboratorio/data/gitea")
    container_path = "/data"
  }

  env = [
    "USER_UID=1000",
    "USER_GID=1000",
    "GITEA__database__DB_TYPE=postgres",
    "GITEA__database__HOST=172.28.0.68:5432",
    "GITEA__database__NAME=gitea",
    "GITEA__database__USER=gitea",
    "GITEA__database__PASSWD=gitea",
    "GITEA__server__DOMAIN=172.28.0.64",
    "GITEA__server__SSH_DOMAIN=172.28.0.64",
    "GITEA__server__SSH_PORT=22",
    "GITEA__server__ROOT_URL=http://172.28.0.64:3000/",
    "GITEA__security__INSTALL_LOCK=true",
    "GITEA__admin__USER=admin",
    "GITEA__admin__PASSWORD=admin",
    "GITEA__admin__EMAIL=admin@example.com",
    "GITEA__metrics__ENABLED=true",
    "GITEA__metrics__TOKEN="
  ]
}

# ── Imagen Aplicación (Build) - Comentado: Jenkins construye la imagen ahora
# resource "docker_image" "app_img" {
#   name = "ud06-app:latest"
#   build {
#     context    = "../Laboratorio/app"
#     dockerfile = "Dockerfile"
#   }
# }

# ── Jenkins Master ──
resource "docker_container" "jenkins" {
  name     = "ud06-jenkins"
  image    = docker_image.jenkins_img.image_id
  hostname = "jenkins"
  restart  = "unless-stopped"
  user     = "root"

  networks_advanced {
    name         = data.docker_network.ud06_net.name
    ipv4_address = var.jenkins_ip
  }

  volumes {
    volume_name    = docker_volume.jenkins_data.name
    container_path = "/var/jenkins_home"
  }

  volumes {
    host_path      = "/var/run/docker.sock"
    container_path = "/var/run/docker.sock"
  }

  env = [
    "JAVA_OPTS=-Djenkins.install.runSetupWizard=false",
    "JENKINS_ADMIN_ID=admin",
    "JENKINS_ADMIN_PASSWORD=admin"
  ]
}

# ── Prometheus ──
resource "docker_container" "prometheus" {
  name     = "ud06-prometheus"
  image    = docker_image.prometheus_img.image_id
  hostname = "prometheus"
  restart  = "unless-stopped"

  networks_advanced {
    name         = data.docker_network.ud06_net.name
    ipv4_address = var.prometheus_ip
  }

  volumes {
    host_path      = abspath("${path.module}/../Laboratorio/monitoring/prometheus.yml")
    container_path = "/etc/prometheus/prometheus.yml"
  }
}

# ── Grafana ──
resource "docker_container" "grafana" {
  name     = "ud06-grafana"
  image    = docker_image.grafana_img.image_id
  hostname = "grafana"
  restart  = "unless-stopped"

  networks_advanced {
    name         = data.docker_network.ud06_net.name
    ipv4_address = var.grafana_ip
  }

  volumes {
    host_path      = abspath("${path.module}/../Laboratorio/monitoring/grafana-datasource.yml")
    container_path = "/etc/grafana/provisioning/datasources/datasource.yml"
  }

  volumes {
    host_path      = abspath("${path.module}/../Laboratorio/monitoring/grafana-dashboard-provider.yml")
    container_path = "/etc/grafana/provisioning/dashboards/provider.yml"
  }

  volumes {
    host_path      = abspath("${path.module}/../Laboratorio/monitoring/dashboard.json")
    container_path = "/etc/grafana/provisioning/dashboards/ud06-dashboard.json"
  }

  env = [
    "GF_AUTH_ANONYMOUS_ENABLED=true",
    "GF_AUTH_ANONYMOUS_ORG_ROLE=Admin",
    "GF_SECURITY_ADMIN_PASSWORD=admin",
    "GF_DASHBOARDS_DEFAULT_HOME_DASHBOARD_PATH=/etc/grafana/provisioning/dashboards/ud06-dashboard.json"
  ]
}

# ── cAdvisor ──
resource "docker_container" "cadvisor" {
  name     = "ud06-cadvisor"
  image    = docker_image.cadvisor_img.image_id
  hostname = "cadvisor"
  restart  = "unless-stopped"

  networks_advanced {
    name         = data.docker_network.ud06_net.name
    ipv4_address = var.cadvisor_ip
  }

  volumes {
    host_path      = "/"
    container_path = "/rootfs"
    read_only      = true
  }
  volumes {
    host_path      = "/var/run"
    container_path = "/var/run"
    read_only      = true
  }
  volumes {
    host_path      = "/sys"
    container_path = "/sys"
    read_only      = true
  }
  volumes {
    host_path      = "/var/lib/docker/"
    container_path = "/var/lib/docker"
    read_only      = true
  }
  volumes {
    host_path      = "/dev/disk/"
    container_path = "/dev/disk"
    read_only      = true
  }
}

# ── Staging Environment (Comentado: Jenkins gestiona este contenedor)
# resource "docker_container" "staging" {
#   name     = "ud06-staging"
#   image    = docker_image.app_img.image_id
#   hostname = "staging"
#   restart  = "unless-stopped"
# 
#   networks_advanced {
#     name         = data.docker_network.ud06_net.name
#     ipv4_address = var.staging_ip
#   }
# 
#   env = [
#     "NODE_ENV=staging",
#     "APP_VERSION=1.0.0-init",
#     "PORT=3000"
#   ]
# 
#   memory = 512
# }
# 
# ── Production Environment (Comentado: Jenkins gestiona este contenedor)
# resource "docker_container" "production" {
#   name     = "ud06-production"
#   image    = docker_image.app_img.image_id
#   hostname = "production"
#   restart  = "unless-stopped"
# 
#   networks_advanced {
#     name         = data.docker_network.ud06_net.name
#     ipv4_address = var.production_ip
#   }
# 
#   env = [
#     "NODE_ENV=production",
#     "APP_VERSION=1.0.0-init",
#     "PORT=3000"
#   ]
# 
#   memory = 512
# }
