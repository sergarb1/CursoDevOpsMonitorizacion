#!/bin/bash
# 03-deploy-fog.sh - Despliega el FOG-Server
set -e
RED='\033[0;31m'; GREEN='\033[0;32m'; BLUE='\033[0;34m'; YELLOW='\033[1;33m'; NC='\033[0m'

echo -e "${BLUE}╔═══════════════════════════════════════════════════════╗${NC}"
echo -e "${BLUE}║     UD03 - Despliegue de FOG-Server                 ║${NC}"
echo -e "${BLUE}╚═══════════════════════════════════════════════════════╝${NC}"

cd "$(dirname "${BASH_SOURCE[0]}")/../Taller-FOG"
vagrant up FOG-Server

echo -e "\n${GREEN}✓ FOG-Server desplegado.${NC}"
echo -e "Siguiente paso: ${YELLOW}vagrant ssh FOG-Server${NC} y ejecutar el instalador."
