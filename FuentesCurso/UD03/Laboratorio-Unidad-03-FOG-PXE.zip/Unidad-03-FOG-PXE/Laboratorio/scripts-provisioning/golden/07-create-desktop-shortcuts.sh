#!/bin/bash
# 07-create-desktop-shortcuts.sh - Crear accesos directos en el escritorio
set -e

DESKTOP_DIR="/home/admin/Escritorio"

echo "=========================================="
echo "🖥️  [GOLDEN] Creando accesos directos..."
echo "=========================================="

# 1. Acceso directo para limpieza
cat > "$DESKTOP_DIR/scripts/EJECUTAR-LIMPIEZA.desktop" << 'EOT'
[Desktop Entry]
Type=Application
Name=🧹 Limpiar Imagen (Ejecutar antes de capturar)
Exec=/home/admin/Escritorio/scripts/03-limpiar-imagen.sh
Icon=system-run
Terminal=true
EOT

# 2. Acceso directo para configuración
cat > "$DESKTOP_DIR/scripts/CONFIGURAR-DESPUES-DESPLEGUE.desktop" << 'EOT'
[Desktop Entry]
Type=Application
Name=🔧 Configurar (Después de desplegar con FOG)
Exec=/home/admin/Escritorio/scripts/01-configurar-red.sh
Icon=preferences-system-network
Terminal=true
EOT

chmod +x "$DESKTOP_DIR/scripts/"*.desktop
chown admin:admin "$DESKTOP_DIR/scripts/"*.desktop

echo "✅ [GOLDEN] Accesos directos creados en el escritorio"
