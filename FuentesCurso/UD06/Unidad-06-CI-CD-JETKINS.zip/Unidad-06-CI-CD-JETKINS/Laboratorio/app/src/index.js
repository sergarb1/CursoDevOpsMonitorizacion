const express = require('express');
const app = express();
const port = 3000;

app.get('/', (req, res) => {
  const n1 = parseInt(req.query.n1) || 5;
  const n2 = parseInt(req.query.n2) || 5;
  const result = n1 * n2;

  res.send(`
    <html>
      <head>
        <title>Calculadora DevOps - v2</title>
        <style>
          body { font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; text-align: center; padding-top: 50px; background-color: #e8f5e9; }
          .card { background: white; padding: 30px; border-radius: 15px; box-shadow: 0 4px 6px rgba(0,0,0,0.1); display: inline-block; min-width: 300px; border: 2px solid #2e7d32; }
          h1 { color: #2e7d32; }
          input { padding: 10px; width: 60px; margin: 10px; border: 1px solid #ccc; border-radius: 5px; text-align: center; font-size: 1.2em; }
          button { padding: 10px 20px; background: #2e7d32; color: white; border: none; border-radius: 5px; cursor: pointer; font-size: 1em; }
          .result { font-size: 2em; margin-top: 20px; color: #c62828; font-weight: bold; }
          .version { font-size: 0.8em; color: #2e7d32; margin-top: 20px; font-weight: bold; }
        </style>
      </head>
      <body>
        <div class="card">
          <h1>🚀 Calculadora (v2: MULTIPLIER)</h1>
          <form action="/" method="get">
            <input type="number" name="n1" value="${n1}">
            <span>×</span>
            <input type="number" name="n2" value="${n2}">
            <br>
            <button type="submit">Multiplicar Ahora</button>
          </form>
          <div class="result">${n1} × ${n2} = ${result}</div>
          <div class="version">Versi\u00f3n 2.0.0 (PRO) - Entorno: ${process.env.NODE_ENV || 'local'}</div>
        </div>
      </body>
    </html>
  `);
});

app.get('/health', (req, res) => res.json({ status: 'healthy', version: '2.0.0' }));
app.get('/metrics', (req, res) => {
  res.set('Content-Type', 'text/plain');
  res.send('# HELP app_version Version\napp_version{version="2.0.0"} 1\n');
});

app.listen(port, () => {
  console.log('🚀 Calculator v2 (MUL) running on port ' + port);
});
