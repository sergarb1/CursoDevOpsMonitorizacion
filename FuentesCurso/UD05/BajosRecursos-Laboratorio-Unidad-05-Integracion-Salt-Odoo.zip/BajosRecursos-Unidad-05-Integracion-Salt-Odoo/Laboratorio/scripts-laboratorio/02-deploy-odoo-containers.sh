#!/bin/bash
# 02-deploy-odoo-containers.sh - Despliega la infraestructura usando Terraform con verificación de servicios
set -e

RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
CYAN='\033[0;36m'
MAGENTA='\033[0;35m'
NC='\033[0m'

# Funciones de logging
log()      { echo -e "${BLUE}[TF]${NC} $1"; }
ok()       { echo -e "${GREEN}✓${NC} $1"; }
warn()     { echo -e "${YELLOW}⚠${NC} $1"; }
error()    { echo -e "${RED}✗${NC} $1"; }
info()     { echo -e "${CYAN}→${NC} $1"; }
success()  { echo -e "${GREEN}✅${NC} $1"; }

# Barra de progreso
progress_bar() {
    local duration=$1
    local message=$2
    local width=40
    local elapsed=0
    
    echo -ne "${CYAN}${message} ${NC}["
    
    while [ $elapsed -lt $duration ]; do
        local percent=$((elapsed * 100 / duration))
        local filled=$((percent * width / 100))
        local empty=$((width - filled))
        
        printf "\r${CYAN}${message} ${NC}["
        printf "${GREEN}%${filled}s${NC}" | tr ' ' '#'
        printf "${YELLOW}%${empty}s${NC}" | tr ' ' '.'
        printf "] ${GREEN}%3d%%${NC}" $percent
        
        sleep 1
        elapsed=$((elapsed + 1))
    done
    
    printf "\r${CYAN}${message} ${NC}["
    printf "${GREEN}%${width}s${NC}" | tr ' ' '#'
    printf "] ${GREEN}100%%${NC}\n"
}

# Cabecera
echo -e "${BLUE}╔════════════════════════════════════════════════════════════════╗${NC}"
echo -e "${BLUE}║              UD05 - Despliegue con Terraform                   ║${NC}"
echo -e "${BLUE}╚════════════════════════════════════════════════════════════════╝${NC}"
echo ""

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
TF_DIR="$SCRIPT_DIR/../terraform"

cd "$TF_DIR"

# Inicializar Terraform si es necesario
if [ ! -d ".terraform" ]; then
    log "Inicializando Terraform..."
    terraform init
    ok "Terraform inicializado"
fi

# Aplicar Terraform
log "Aplicando cambios en la infraestructura..."
terraform apply -auto-approve

if [ $? -eq 0 ]; then
    success " Infraestructura desplegada correctamente"
else
    error "Error en el despliegue de Terraform"
    exit 1
fi

echo ""
info "Esperando a que todos los servicios esten listos..."
echo ""

# ESPERA GLOBAL DE 240 SEGUNDOS (4 minutos)
echo -e "${YELLOW}════════════════════════════════════════════════════════════════${NC}"
echo -e "${YELLOW}     ⏱️  ESPERA GLOBAL: 240 segundos (4 minutos)${NC}"
echo -e "${YELLOW}     Esto permite que todos los servicios terminen de iniciar${NC}"
echo -e "${YELLOW}════════════════════════════════════════════════════════════════${NC}"
progress_bar 240 "Espera global"
echo ""

# =============================================================================
# FUNCIONES DE VERIFICACION CORREGIDAS
# =============================================================================

check_postgres() {
    local max_retries=5
    local retry=0
    
    while [ $retry -lt $max_retries ]; do
        if docker exec odoo-pg1 pg_isready -U odoo >/dev/null 2>&1; then
            return 0
        fi
        sleep 2
        retry=$((retry + 1))
    done
    return 1
}

check_odoo() {
    local max_retries=5
    local retry=0
    local http_code=""
    
    while [ $retry -lt $max_retries ]; do
        http_code=$(docker exec odoo-minion-1 curl -s -o /dev/null -w "%{http_code}" http://localhost:8069 2>/dev/null)
        
        # Acepta cualquier código 2xx, 3xx, o 5xx (vivo aunque inicializando)
        if [[ "$http_code" =~ ^[2-5][0-9]{2}$ ]]; then
            return 0
        fi
        sleep 2
        retry=$((retry + 1))
    done
    return 1
}

check_salt_master() {
    local max_retries=6
    local retry=0
    
    while [ $retry -lt $max_retries ]; do
        # Buscar el proceso salt-master (puede ejecutarse como salt, no solo root)
        if docker exec ud05-salt-master pgrep -x "salt-master" >/dev/null 2>&1; then
            return 0
        fi
        # Buscar también como usuario salt (pgrep con -u)
        if docker exec ud05-salt-master pgrep -x -u salt "salt-master" >/dev/null 2>&1; then
            return 0
        fi
        # Buscar en los procesos de todos los usuarios
        if docker exec ud05-salt-master ps aux | grep -q "[s]alt-master"; then
            return 0
        fi
        # Verificar también si el servicio está activo
        if docker exec ud05-salt-master systemctl is-active salt-master >/dev/null 2>&1; then
            return 0
        fi
        sleep 5
        retry=$((retry + 1))
    done
    return 1
}

check_grafana() {
    local max_retries=5
    local retry=0
    local http_code=""
    
    while [ $retry -lt $max_retries ]; do
        http_code=$(curl -s -o /dev/null -w "%{http_code}" http://172.28.0.56:3000 2>/dev/null)
        
        if [[ "$http_code" =~ ^(200|302|303)$ ]]; then
            return 0
        fi
        sleep 2
        retry=$((retry + 1))
    done
    return 1
}

check_prometheus() {
    local max_retries=5
    local retry=0
    local http_code=""
    
    while [ $retry -lt $max_retries ]; do
        http_code=$(curl -s -o /dev/null -w "%{http_code}" http://172.28.0.51:9090 2>/dev/null)
        
        # Acepta cualquier código 2xx, 3xx
        if [[ "$http_code" =~ ^[2-3][0-9]{2}$ ]]; then
            return 0
        fi
        sleep 2
        retry=$((retry + 1))
    done
    return 1
}

check_cadvisor() {
    local max_retries=5
    local retry=0
    local http_code=""
    
    while [ $retry -lt $max_retries ]; do
        # Probar diferentes endpoints que cAdvisor acepta
        http_code=$(curl -s -o /dev/null -w "%{http_code}" http://172.28.0.52:8080/ 2>/dev/null)
        
        # cAdvisor responde con 200, 301, 302, 303, 304, 307
        if [[ "$http_code" =~ ^(200|301|302|303|304|307)$ ]]; then
            return 0
        fi
        
        # Probar también el endpoint /containers/
        http_code=$(curl -s -o /dev/null -w "%{http_code}" http://172.28.0.52:8080/containers/ 2>/dev/null)
        if [[ "$http_code" =~ ^(200|301|302|303|304|307)$ ]]; then
            return 0
        fi
        
        sleep 3
        retry=$((retry + 1))
    done
    return 1
}

check_blackbox() {
    local max_retries=5
    local retry=0
    local http_code=""
    
    while [ $retry -lt $max_retries ]; do
        http_code=$(curl -s -o /dev/null -w "%{http_code}" http://172.28.0.53:9115 2>/dev/null)
        
        if [[ "$http_code" =~ ^(200|302)$ ]]; then
            return 0
        fi
        sleep 2
        retry=$((retry + 1))
    done
    return 1
}

# =============================================================================
# VERIFICAR CONTENEDORES
# =============================================================================
info "Verificando estado de los contenedores..."

containers=(
    "ud05-salt-master"
    "odoo-pg1"
    "odoo-minion-1"
    "odoo-prometheus"
    "odoo-grafana"
    "odoo-cadvisor"
    "odoo-blackbox"
)

for container in "${containers[@]}"; do
    if docker ps --format '{{.Names}}' | grep -q "^${container}$"; then
        ok "Contenedor $container esta corriendo"
    else
        warn "Contenedor $container no esta ejecutandose"
    fi
done

echo ""

# =============================================================================
# VERIFICACION CON REINTENTOS
# =============================================================================
verify_service_with_retry() {
    local name=$1
    local check_func=$2
    local wait_time=$3
    local max_attempts=3
    local attempt=1
    
    echo -e "\n${CYAN}────────────────────────────────────────────────────────────────${NC}"
    echo -e "${CYAN}  🔍 Verificando: ${name}${NC}"
    echo -e "${CYAN}────────────────────────────────────────────────────────────────${NC}"
    
    while [ $attempt -le $max_attempts ]; do
        echo -e "${YELLOW}📌 Intento $attempt de $max_attempts${NC}"
        
        # Barra de progreso con tiempo específico por servicio
        progress_bar $wait_time "  ⏳ Esperando respuesta de ${name}"
        
        if eval $check_func; then
            echo -e "${GREEN}✓ ${name} esta listo!${NC}"
            return 0
        else
            echo -e "${RED}✗ ${name} no responde${NC}"
            if [ $attempt -lt $max_attempts ]; then
                echo -e "${YELLOW}🔄 Reintentando en 10 segundos...${NC}"
                sleep 10
            fi
        fi
        attempt=$((attempt + 1))
    done
    
    # Mensaje específico por servicio cuando falla
    case $name in
        "Salt Master")
            echo -e "${YELLOW}⚠ ${name} puede estar instalándose. Los minions se conectarán en unos minutos.${NC}"
            echo -e "${YELLOW}   Para ver logs: docker logs ud05-salt-master --tail 30${NC}"
            ;;
        "cAdvisor")
            echo -e "${YELLOW}⚠ ${name} puede estar iniciando. Verifica con: docker logs odoo-cadvisor --tail 20${NC}"
            ;;
        "Prometheus")
            echo -e "${YELLOW}⚠ ${name} puede estar iniciando. Verifica con: docker logs odoo-prometheus --tail 20${NC}"
            ;;
        "Grafana")
            echo -e "${YELLOW}⚠ ${name} puede estar iniciando. Verifica con: docker logs odoo-grafana --tail 20${NC}"
            ;;
        *)
            echo -e "${YELLOW}⚠ ${name} puede estar funcionando pero continuamos...${NC}"
            ;;
    esac
    return 0
}

# Verificar cada servicio con tiempos conservadores
verify_service_with_retry "PostgreSQL" "check_postgres" 30
verify_service_with_retry "Odoo 17" "check_odoo" 45
verify_service_with_retry "Salt Master" "check_salt_master" 35
verify_service_with_retry "Grafana" "check_grafana" 20
verify_service_with_retry "Prometheus" "check_prometheus" 20
verify_service_with_retry "cAdvisor" "check_cadvisor" 20
verify_service_with_retry "Blackbox Exporter" "check_blackbox" 15

# =============================================================================
# RESUMEN FINAL
# =============================================================================
echo ""
echo -e "${GREEN}╔════════════════════════════════════════════════════════════════╗${NC}"
echo -e "${GREEN}║                    🎉 DEPLOYMENT COMPLETADO 🎉                 ║${NC}"
echo -e "${GREEN}╚════════════════════════════════════════════════════════════════╝${NC}"
echo ""
echo -e "${CYAN}📍 Servicios desplegados:${NC}"
echo -e "   • ${GREEN}Salt Master${NC}:     172.28.0.50"
echo -e "   • ${GREEN}PostgreSQL${NC}:      172.28.0.59"
echo -e "   • ${GREEN}Odoo${NC}:             http://172.28.0.57:8069"
echo -e "   • ${GREEN}Grafana${NC}:          http://172.28.0.56:3000 (usuario: admin / contraseña: admin)"
echo -e "   • ${GREEN}Prometheus${NC}:       http://172.28.0.51:9090"
echo -e "   • ${GREEN}cAdvisor${NC}:         http://172.28.0.52:8080"
echo -e "   • ${GREEN}Blackbox Exporter${NC}: http://172.28.0.53:9115"
echo ""
echo -e "${CYAN}🔑 Credenciales:${NC}"
echo -e "   • Odoo:     admin / admin"
echo -e "   • Grafana:  admin / admin"
echo ""
echo -e "${YELLOW}📝 Notas importantes:${NC}"
echo -e "   • Los Salt Minions se conectarán automáticamente al Master (172.28.0.50)"
echo -e "   • Los exporters de métricas están integrados en Odoo"
echo -e "   • La base de datos se crea automáticamente (script 04-init-odoo-db.sh)"
echo -e "   • Si algún servicio no responde, espera 1-2 minutos más"
echo ""
echo -e "${GREEN}✅ ¡Listo para trabajar!${NC}"
echo ""