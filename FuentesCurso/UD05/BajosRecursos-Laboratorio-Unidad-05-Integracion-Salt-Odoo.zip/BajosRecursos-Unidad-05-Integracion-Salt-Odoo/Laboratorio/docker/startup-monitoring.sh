#!/bin/sh
# startup-monitoring.sh - UD05 (Versión Debug Total)
# Redirigir salida a log interno para poder leerlo con docker exec
exec > /tmp/startup.log 2>&1
set -u

NOMBRE_SERVICIO=$1
COMANDO=$2

echo "--- INICIO ARRANQUE $NOMBRE_SERVICIO ---"
date

# 1. Lanzar servicio principal
echo "[1/3] Lanzando servicio principal..."
eval "$COMANDO" &

# 2. Lanzar Node Exporter (Ruta absoluta y flags explícitos)
echo "[2/3] Configurando Node Exporter..."
if [ -f "/usr/local/bin/node_exporter" ]; then
    chmod +x /usr/local/bin/node_exporter
    /usr/local/bin/node_exporter --web.listen-address=:9100 > /tmp/node_exporter.log 2>&1 &
    echo "✓ Node Exporter ejecutado en puerto 9100"
else
    echo "✗ ERROR: Binario /usr/local/bin/node_exporter no encontrado"
fi

# 3. Salt Minion (Solo si existe apt-get)
echo "[3/3] Comprobando Salt Minion..."
if command -v apt-get >/dev/null 2>&1; then
    (
        apt-get update -qq && apt-get install -y -qq curl gnupg >/dev/null 2>&1
        curl -L https://bootstrap.saltstack.com -o /tmp/install_salt.sh
        sh /tmp/install_salt.sh -X stable 3006.2 >/dev/null 2>&1
        mkdir -p /etc/salt
        echo "master: 172.28.0.50" > /etc/salt/minion
        echo "id: $(hostname)" >> /etc/salt/minion
        salt-minion -d
        echo "✓ Salt Minion instalado y lanzado"
    ) &
else
    echo "! Salt Minion omitido (Imagen no compatible)"
fi

echo "--- ARRANQUE FINALIZADO ---"
tail -f /dev/null
