#!/bin/bash
# 01-setup-network.sh - Configura el bridge LabCEFIRE en el Host
set -e

# Colores
RED='\033[0;31m'; GREEN='\033[0;32m'; BLUE='\033[0;34m'; YELLOW='\033[1;33m'; NC='\033[0m'

echo -e "${BLUE}╔═══════════════════════════════════════════════════════╗${NC}"
echo -e "${BLUE}║     UD04 - Configuración de Red Bridge (LabCEFIRE)  ║${NC}"
echo -e "${BLUE}╚═══════════════════════════════════════════════════════╝${NC}"

BRIDGE_NAME="LabCEFIRE"
BRIDGE_IP="172.28.0.1"
NETMASK="24"
NETWORK="172.28.0.0/24"

# 1. Limpieza de residuos
if ip link show $BRIDGE_NAME > /dev/null 2>&1; then
    echo -e "${YELLOW}[RED]${NC} El bridge '${BRIDGE_NAME}' ya existe. Limpiando para reconfigurar..."
    sudo ip link set $BRIDGE_NAME down >/dev/null 2>&1
    sudo ip link delete $BRIDGE_NAME >/dev/null 2>&1
fi

echo -e "${BLUE}[RED]${NC} Creando bridge '${BRIDGE_NAME}'..."
sudo ip link add name $BRIDGE_NAME type bridge
sudo ip addr add $BRIDGE_IP/$NETMASK dev $BRIDGE_NAME
sudo ip link set $BRIDGE_NAME up

echo -e "${BLUE}[RED]${NC} Configurando forwarding y firewall..."
echo 1 | sudo tee /proc/sys/net/ipv4/ip_forward > /dev/null
sudo iptables -I FORWARD -m physdev --physdev-is-bridged -j ACCEPT > /dev/null 2>&1 || true

echo -e "${GREEN}✓${NC} Red configurada con éxito."
echo -e "  IP del Host (Gateway): ${GREEN}${BRIDGE_IP}${NC}"
echo -e "  Red del Laboratorio:   ${GREEN}${NETWORK}${NC}"
echo -e "  Estado: $(ip addr show $BRIDGE_NAME | grep -oP 'state \K\w+' || echo "UP")"
echo ""
