#!/bin/bash
# 02-install-falkon.sh - Instalar entorno navegador Falkon
set -e

echo "=========================================="
echo "🖥️  [GOLDEN] Instalando navegador Falkon..."
echo "=========================================="

apt-get install -y falkon

echo "✅ [GOLDEN] LXDE y Falkon instalados correctamente"
