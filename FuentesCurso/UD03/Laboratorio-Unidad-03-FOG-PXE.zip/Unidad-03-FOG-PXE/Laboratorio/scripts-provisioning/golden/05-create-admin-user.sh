#!/bin/bash
# 05-create-admin-user.sh - Crear usuario admin para la Golden Image
set -e

echo "=========================================="
echo "👤 [GOLDEN] Creando usuario 'admin'..."
echo "=========================================="

if ! id "admin" &>/dev/null; then
    useradd -m -s /bin/bash admin
    echo "admin:AdminCEFIRE1234" | chpasswd
    usermod -aG sudo admin
    # Permitir sudo sin contraseña para facilitar el laboratorio
    echo "admin ALL=(ALL) NOPASSWD:ALL" > /etc/sudoers.d/admin
    chmod 440 /etc/sudoers.d/admin
    echo "✅ [GOLDEN] Usuario 'admin' creado correctamente (con SUDO sin password)"
    echo "   Usuario: admin"
    echo "   Contraseña: AdminCEFIRE1234"
else
    echo "✅ [GOLDEN] Usuario 'admin' ya existe"
fi

echo "=========================================="
echo "✅ [GOLDEN] Usuario configurado"
echo "=========================================="
