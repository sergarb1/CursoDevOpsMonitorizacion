#!/bin/bash
# 04-deploy-target.sh - Despliega la Target-VM (Vacía)
set -e
RED='\033[0;31m'; GREEN='\033[0;32m'; BLUE='\033[0;34m'; YELLOW='\033[1;33m'; NC='\033[0m'

echo -e "${BLUE}╔═══════════════════════════════════════════════════════╗${NC}"
echo -e "${BLUE}║     UD03 - Despliegue de Target-VM (Objetivo)       ║${NC}"
echo -e "${BLUE}╚═══════════════════════════════════════════════════════╝${NC}"

cd "$(dirname "${BASH_SOURCE[0]}")/../Taller-FOG"
vagrant up Target-VM

echo -e "\n${GREEN}✓ Target-VM desplegada.${NC}"
echo -e "Esta máquina está lista para recibir la imagen por PXE."
