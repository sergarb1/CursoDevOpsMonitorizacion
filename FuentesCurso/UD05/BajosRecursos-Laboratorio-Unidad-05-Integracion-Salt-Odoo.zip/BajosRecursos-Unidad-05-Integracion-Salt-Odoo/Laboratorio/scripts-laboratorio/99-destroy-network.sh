#!/bin/bash
# 99-destroy-network.sh - Destruye la red LabCEFIRE
set -uo pipefail

RED='\033[0;31m'; GREEN='\033[0;32m'; YELLOW='\033[1;33m'; BLUE='\033[0;34m'; NC='\033[0m'

echo -e "${RED}╔═══════════════════════════════════════════════════════╗${NC}"
echo -e "${RED}║     ⚠️  UD05 - ELIMINACIÓN DE RED CEFIRE             ║${NC}"
echo -e "${RED}╚═══════════════════════════════════════════════════════╝${NC}"

read -p "  ¿Eliminar la red LabCEFIRE? (s/N): " confirm

# Aceptar s, S, y, Y como afirmativo
if [[ "$confirm" =~ ^[sSyY]$ ]]; then
    NETWORK_NAME="LabCEFIRE"
    if docker network inspect "$NETWORK_NAME" >/dev/null 2>&1; then
        echo -e "${BLUE}[RED]${NC} Eliminando red '${NETWORK_NAME}'..."
        docker network rm "$NETWORK_NAME"
        echo -e "${GREEN}✓${NC} Red eliminada."
    else
        echo -e "${YELLOW}!${NC} La red '${NETWORK_NAME}' no existe."
    fi
else
    echo "  Operación cancelada."
    exit 0
fi