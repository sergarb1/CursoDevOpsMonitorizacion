#!/bin/bash
# startup-odoo.sh - Arranque ordenado para Odoo 17 + Exporters (usa binario local)
# La base de datos NO se crea automáticamente. Se puede crear manualmente o con 04-create-odoo-database.sh
set -euo pipefail

# ------------------------------------------------------------------
# Variables de entorno
# ------------------------------------------------------------------
POSTGRES_HOST="${POSTGRES_HOST:-172.28.0.59}"
POSTGRES_USER="${POSTGRES_USER:-odoo}"
POSTGRES_PASSWORD="${POSTGRES_PASSWORD:-odoo}"
ODOO_ADMIN_USER="${ODOO_ADMIN_USER:-admin}"
ODOO_ADMIN_PASSWORD="${ODOO_ADMIN_PASSWORD:-admin}"
ODOO_DB_NAME="${ODOO_DB_NAME:-odoo_db}"
EXPORTER_PORT="${EXPORTER_PORT:-9090}"

HOSTNAME=$(hostname)
LOCAL_IP=$(hostname -I | awk '{print $1}')

# Colores
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m'

log()   { echo -e "${BLUE}[${HOSTNAME}]${NC} $1"; }
ok()    { echo -e "${GREEN}[✓]${NC} $1"; }
warn()  { echo -e "${YELLOW}[!]${NC} $1"; }
error() { echo -e "${RED}[✗]${NC} $1"; }

# ------------------------------------------------------------------
# 1. Esperar PostgreSQL
# ------------------------------------------------------------------
log "Esperando PostgreSQL en ${POSTGRES_HOST}..."
for i in {1..30}; do
    if PGPASSWORD="$POSTGRES_PASSWORD" psql -h "$POSTGRES_HOST" -U "$POSTGRES_USER" -d postgres -c "SELECT 1" >/dev/null 2>&1; then
        ok "PostgreSQL listo"
        break
    fi
    sleep 2
done

# Permisos CREATEDB (necesarios para creación manual o script)
PGPASSWORD="$POSTGRES_PASSWORD" psql -h "$POSTGRES_HOST" -U "$POSTGRES_USER" -d postgres \
    -c "ALTER USER ${POSTGRES_USER} CREATEDB;" 2>/dev/null

# ------------------------------------------------------------------
# 2. Iniciar Node Exporter (binario local) - Versión robusta
# ------------------------------------------------------------------
NODE_BIN="/usr/local/bin/node_exporter"
if [ -f "$NODE_BIN" ]; then
    chmod 755 "$NODE_BIN" 2>/dev/null || true
    if ! pgrep -x "node_exporter" >/dev/null 2>&1; then
        log "Iniciando Node Exporter desde binario local..."
        # Usamos nohup y redirigimos toda la salida a un log
        nohup "$NODE_BIN" --web.listen-address=:9100 > /tmp/node_exporter.log 2>&1 &
        NODE_PID=$!
        sleep 3
        # Verificar que el proceso sigue vivo
        if kill -0 $NODE_PID 2>/dev/null && pgrep -x "node_exporter" >/dev/null; then
            ok "Node Exporter activo (puerto 9100, PID $NODE_PID)"
        else
            warn "Node Exporter no se inició correctamente. Revisa /tmp/node_exporter.log"
        fi
    else
        ok "Node Exporter ya está corriendo"
    fi
else
    warn "Node Exporter no encontrado en $NODE_BIN"
fi

# ------------------------------------------------------------------
# 3. Iniciar Odoo (sin crear BD)
# ------------------------------------------------------------------
log "Iniciando Odoo 17..."
odoo --config=/etc/odoo/odoo.conf \
    --db_host="$POSTGRES_HOST" \
    --db_user="$POSTGRES_USER" \
    --db_password="$POSTGRES_PASSWORD" \
    --db-filter=".*" \
    --log-level=info &
ODOO_PID=$!

# ------------------------------------------------------------------
# 4. Esperar a que Odoo esté disponible (HTTP)
# ------------------------------------------------------------------
log "Esperando Odoo (http://localhost:8069)..."
for i in {1..60}; do
    if curl -sf http://localhost:8069/web/login >/dev/null 2>&1; then
        ok "Odoo responde (puedes crear la BD manualmente)"
        break
    fi
    sleep 3
done

# ------------------------------------------------------------------
# 5. Iniciar Odoo Exporter (con instalación automática de dependencia)
# ------------------------------------------------------------------
if [ -f /opt/odoo-exporter.py ]; then
    # Verificar e instalar prometheus_client si es necesario
    if ! pip3 list 2>/dev/null | grep -q prometheus_client; then
        log "Instalando prometheus_client (dependencia del exporter)..."
        pip3 install --no-cache-dir prometheus-client > /tmp/pip_install.log 2>&1
        if [ $? -eq 0 ]; then
            ok "prometheus_client instalado correctamente"
        else
            warn "Fallo la instalación de prometheus_client. Revisa /tmp/pip_install.log"
        fi
    fi

    pkill -f "odoo-exporter.py" 2>/dev/null || true
    log "Iniciando Odoo Exporter (puerto ${EXPORTER_PORT})..."
    python3 /opt/odoo-exporter.py \
        --odoo-url "http://localhost:8069" \
        --db "$ODOO_DB_NAME" \
        --user "$ODOO_ADMIN_USER" \
        --password "$ODOO_ADMIN_PASSWORD" \
        --port "$EXPORTER_PORT" \
        > /tmp/odoo_exporter.log 2>&1 &
    sleep 2
    if pgrep -f "odoo-exporter.py" >/dev/null; then
        ok "Odoo Exporter activo"
    else
        warn "Fallo Odoo Exporter. Revisa /tmp/odoo_exporter.log"
    fi
fi

# ------------------------------------------------------------------
# Instalar y configurar Salt Minion
# ------------------------------------------------------------------
log "Instalando Salt Minion..."
# Asegurar que curl está disponible (ya debería estarlo)
apt-get update -qq && apt-get install -y -qq curl gnupg

# Añadir repositorio de Salt (versión 3006 LTS)
mkdir -p /etc/apt/keyrings
curl -fsSL https://packages.broadcom.com/artifactory/api/security/keypair/SaltProjectKey/public | gpg --dearmor -o /etc/apt/keyrings/salt-archive-keyring.pgp
curl -fsSL https://github.com/saltstack/salt-install-guide/releases/latest/download/salt.sources | tee /etc/apt/sources.list.d/salt.sources > /dev/null
echo 'Package: salt-*
Pin: version 3006.*
Pin-Priority: 1001' | tee /etc/apt/preferences.d/salt-pin-1001 > /dev/null

apt-get update -qq && apt-get install -y -qq salt-minion

# Configurar minion para conectar al master
mkdir -p /etc/salt
cat > /etc/salt/minion << EOF
master: 172.28.0.50
id: ${HOSTNAME}
EOF

# Iniciar salt-minion (como daemon)
salt-minion -d

ok "Salt Minion configurado y conectándose a 172.28.0.50"


# ------------------------------------------------------------------
# 6. Resumen
# ------------------------------------------------------------------
echo ""
log "════════════════════════════════════════════════════════════════"
log "  SERVICIOS INICIADOS EN ${HOSTNAME}"
log "════════════════════════════════════════════════════════════════"
echo "  Odoo:              http://${LOCAL_IP}:8069"
echo "  Odoo Exporter:     http://${LOCAL_IP}:${EXPORTER_PORT}/metrics"
pgrep -x "node_exporter" >/dev/null && echo "  Node Exporter:     http://${LOCAL_IP}:9100/metrics"
echo "  DB Host:           ${POSTGRES_HOST}"
echo ""
echo "  NOTA: La base de datos NO se ha creado automáticamente."
echo "  Puedes crearla desde la web (Master Password: admin) o ejecutando:"
echo "  ./04-create-odoo-database.sh"
log "════════════════════════════════════════════════════════════════"
echo ""

wait $ODOO_PID