#!/bin/bash
# 08-node-exporter.sh - Instalación de Prometheus Node Exporter.
# Didáctica: Este agente traduce métricas del sistema operativo (Linux)
# a un formato que Prometheus puede leer. No tiene base de datos.

set -euo pipefail

# Colores para feedback visual
BLUE='\033[0;34m'; GREEN='\033[0;32m'; YELLOW='\033[1;33m'; NC='\033[0m'

echo -e "${BLUE}--- [NODE-EXPORTER] Configurando agente de métricas ---${NC}"

# Función para mostrar progreso
progress() { echo -e "${YELLOW}  [→]${NC} $1..."; }

# 1. Preparación (Solo si es necesario)
if ! command -v curl &>/dev/null; then
    progress "Instalando dependencias de sistema"
    export DEBIAN_FRONTEND=noninteractive
    apt-get update  && apt-get install -y  curl gnupg net-tools ca-certificates > /dev/null
fi

# 2. Instalación
if command -v prometheus-node-exporter &>/dev/null; then
    echo -e "  ${GREEN}✓${NC} Node Exporter ya está presente."
else
    progress "Instalando paquete prometheus-node-exporter"
    apt-get install -y  prometheus-node-exporter > /dev/null
fi

# 3. Configuración del puerto
# Didáctica: El puerto estándar para Node Exporter es el 9100.
progress "Asegurando escucha en puerto 9100"
if [ -f /etc/default/prometheus-node-exporter ]; then
    sed -i 's/#ARGS="/ARGS="--web.listen-address=:9100 "/' /etc/default/prometheus-node-exporter 2>/dev/null || true
fi

# 4. Arranque del proceso
pkill -9 -f 'prometheus-node-exporter' 2>/dev/null || true
sleep 1
nohup /usr/bin/prometheus-node-exporter --web.listen-address=:9100 > /var/log/node-exporter.log 2>&1 &

# 5. Verificación con feedback de espera
echo -ne "  ${YELLOW}[WAIT]${NC} Verificando exposición de métricas "
for i in $(seq 1 10); do
    if curl -sf http://localhost:9100/metrics > /dev/null 2>&1; then
        echo -e "\n  ${GREEN}✓${NC} Agente activo en http://localhost:9100/metrics"
        break
    fi
    echo -n "."
    sleep 1
done

echo -e "${GREEN}--- [NODE-EXPORTER] Listo ---${NC}"
