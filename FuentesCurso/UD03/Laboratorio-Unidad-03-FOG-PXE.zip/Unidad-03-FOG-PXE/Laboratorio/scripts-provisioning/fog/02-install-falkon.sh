#!/bin/bash
# 02-install-falkon.sh - Instalar navegador Falkon
set -e

echo "=========================================="
echo "🖥️  [FOG] Instalando navegador Falkon..."
echo "=========================================="

apt-get install -y falkon

echo "✅ [FOG] LXDE y Falkon instalados correctamente"
