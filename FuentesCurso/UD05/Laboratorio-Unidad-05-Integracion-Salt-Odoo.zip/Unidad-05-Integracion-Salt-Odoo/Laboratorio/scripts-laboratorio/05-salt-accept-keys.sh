#!/bin/bash
# 05-salt-accept-keys.sh - Acepta todas las llaves pendientes de los minions

RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
CYAN='\033[0;36m'
NC='\033[0m'

echo -e "${BLUE}╔════════════════════════════════════════════════════════════════╗${NC}"
echo -e "${BLUE}║              UD05 - Aceptación de Claves Salt                  ║${NC}"
echo -e "${BLUE}╚════════════════════════════════════════════════════════════════╝${NC}"
echo ""

if ! docker ps --format '{{.Names}}' | grep -q "ud05-salt-master"; then
    echo -e "${RED}✗${NC} El contenedor ud05-salt-master no está corriendo"
    exit 1
fi

echo -e "${BLUE}[SALT]${NC} Verificando estado actual del Salt Master..."
echo ""

KEY_LIST=$(docker exec ud05-salt-master salt-key --list-all 2>/dev/null)
PENDING_COUNT=$(echo "$KEY_LIST" | sed -n '/Unaccepted Keys:/,/Accepted Keys:/p' | grep -E '^[[:space:]]+\w' | wc -l)
ACCEPTED_COUNT=$(echo "$KEY_LIST" | sed -n '/Accepted Keys:/,/Denied Keys:/p' | grep -E '^[[:space:]]+\w' | wc -l)

echo -e "${CYAN}📊 Estado actual:${NC}"
echo -e "   • Llaves aceptadas: ${GREEN}${ACCEPTED_COUNT}${NC}"
echo -e "   • Llaves pendientes: ${YELLOW}${PENDING_COUNT}${NC}"
echo ""

if [ "$PENDING_COUNT" -gt 0 ]; then
    echo -e "${YELLOW}⚠${NC} Se encontraron $PENDING_COUNT llaves pendientes. Aceptando..."
    echo ""

    PENDING_KEYS=$(echo "$KEY_LIST" | sed -n '/Unaccepted Keys:/,/Accepted Keys:/p' | grep -E '^[[:space:]]+\w' | awk '{print $1}')

    for key in $PENDING_KEYS; do
        echo -e "  Aceptando: ${CYAN}$key${NC}"
        docker exec ud05-salt-master salt-key -a "$key" -y >/dev/null 2>&1
    done

    echo ""
    echo -e "${GREEN}✓${NC} Llaves aceptadas correctamente."
else
    echo -e "${GREEN}✓${NC} No hay llaves pendientes. Todos los minions ya están aceptados."
fi

echo ""
echo -e "${BLUE}[SALT]${NC} Lista actual de minions:"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
docker exec ud05-salt-master salt-key -L
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"

if [ "$ACCEPTED_COUNT" -gt 0 ]; then
    echo ""
    echo -e "${CYAN}🖥️  Minions conectados (test.ping):${NC}"
    docker exec ud05-salt-master salt '*' test.ping 2>/dev/null | sed 's/^/   /' || echo "   ⚠ No responden aún"
fi

echo -e "${BLUE}[SALT]${NC} Probando conectividad con los minions (test.ping)..."
docker exec ud05-salt-master salt '*' test.ping

if [ $? -eq 0 ]; then
    echo -e "${GREEN}✓${NC} Prueba de ping completada."
else
    echo -e "${RED}✗${NC} Error: Algunos minions no responden. Asegúrate de haber aceptado las llaves con este script."
fi
echo ""
echo -e "${GREEN}✅ Proceso completado.${NC}"
