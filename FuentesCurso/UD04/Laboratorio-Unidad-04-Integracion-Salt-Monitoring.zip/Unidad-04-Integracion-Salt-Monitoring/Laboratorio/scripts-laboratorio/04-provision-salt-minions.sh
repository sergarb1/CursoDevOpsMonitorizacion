#!/bin/bash
# 04-provision-salt-minions.sh - Instala Salt Minion y Node Exporter en los nodos esclavos.
# Los minions son los agentes que reciben órdenes del Master. Además, instalamos
# Node Exporter para que Prometheus pueda recolectar métricas de estos nodos.
set -e

# Colores y Formato
RED='\033[0;31m'; GREEN='\033[0;32m'; BLUE='\033[0;34m'; YELLOW='\033[1;33m'; NC='\033[0m'

echo -e "${BLUE}╔═══════════════════════════════════════════════════════╗${NC}"
echo -e "${BLUE}║     UD04 - Provisión de Salt Minions                 ║${NC}"
echo -e "${BLUE}║     (Agentes de Configuración y Métricas)           ║${NC}"
echo -e "${BLUE}╚═══════════════════════════════════════════════════════╝${NC}"

MINIONS="vm-minion-1 vm-minion-2"

for m in $MINIONS; do
    echo -e "${BLUE}[STEP]${NC} Provisionando nodo: ${YELLOW}${m}${NC}"
    docker inspect "$m" >/dev/null 2>&1 || { echo -e "${RED}✗ Error: $m no encontrado.${NC}"; exit 1; }

    # Instalación de dependencias: curl para descargar llaves, net-tools para info de red.
    echo -e "  - Instalando herramientas de sistema..."
    docker exec "$m" bash -c '
        export DEBIAN_FRONTEND=noninteractive
        apt-get update 2>&1
        apt-get install -y  curl gnupg net-tools apt-utils
    '

    # Instalación de Salt Minion: Se configura para apuntar a la IP del Master (172.28.0.40).
    echo -e "  - Configurando Salt Minion (Agente Salt)..."
    docker exec "$m" bash -c '
        export DEBIAN_FRONTEND=noninteractive
        bash /opt/scripts/lib/05-salt-minion-ubuntu.sh 2>&1
    '

    # Instalación de Node Exporter: Expone métricas de hardware (CPU, RAM) en el puerto 9100.
    echo -e "  - Instalando Node Exporter (Agente Métricas)..."
    docker exec "$m" bash -c '
        export DEBIAN_FRONTEND=noninteractive
        bash /opt/scripts/lib/08-node-exporter.sh 2>&1
    '
    echo -e "  ${GREEN}✓${NC} ${m}: Configuración base completada."
done

# Seguridad: El Master debe aceptar la llave pública de cada Minion para establecer un canal cifrado.
echo -e "${BLUE}[STEP]${NC} Gestionando llaves criptográficas en el Master..."
sleep 5
echo -e "  - Aceptando llaves pendientes en vm-master (salt-key -A)..."
docker exec vm-master salt-key -A -y >/dev/null 2>&1 || echo -e "${YELLOW}  ! Claves ya aceptadas o no disponibles aún.${NC}"

# Prueba de comunicación: test.ping no es un ping de red (ICMP), es un comando Salt que verifica
# que el agente está vivo y autenticado.
echo -e "${BLUE}[STEP]${NC} Verificando comunicación Master <-> Minion..."
echo -e "${BLUE}[STEP]${NC} Usaremos docker exec vm-master salt '*' test.ping"

sleep 15
docker exec vm-master salt '*' test.ping 2> /dev/null
echo -e "\n${YELLOW}Nota Didáctica:${NC} Node Exporter es un 'exportador' que traduce estadísticas del SO a un formato que Prometheus entiende (HTTP plaintext)."
echo ""
