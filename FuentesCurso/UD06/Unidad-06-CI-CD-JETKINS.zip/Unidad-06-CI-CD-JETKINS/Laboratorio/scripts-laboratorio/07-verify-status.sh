#!/bin/bash
# 07-verify-status.sh - Comparador Visual Staging vs Produccion
# ============================================================
set -euo pipefail

BOLD='\033[1m'
RED='\033[0;31m'; GREEN='\033[0;32m'; YELLOW='\033[1;33m'; BLUE='\033[0;34m'; CYAN='\033[0;36m'; NC='\033[0m'
CHECK="${GREEN}✓${NC}"; CROSS="${RED}✗${NC}"; INFO="${CYAN}ℹ${NC}"

echo -e "${BLUE}${BOLD}"
echo "╔══════════════════════════════════════════════════════════════╗"
echo "║   🔍 UD06 - Paso 7: Verificar Staging vs Produccion       ║"
echo "╚══════════════════════════════════════════════════════════════╝"
echo -e "${NC}"

echo -e "${YELLOW}${BOLD}📘 ¿Qué vamos a hacer?${NC}"
echo "  Vamos a comparar los dos entornos donde se ejecuta la app:"
echo "  Staging (pruebas) y Producción (usuarios). Veremos si están"
echo "  sincronizados o si el pipeline está esperando aprobación."
echo ""
echo -e "${YELLOW}${BOLD}🏗️  Los dos entornos:${NC}"
echo -e "  ${CYAN}Staging${NC}    172.28.0.62:3000  →  código NUEVO (pruebas)"
echo -e "  ${CYAN}Producción${NC} 172.28.0.63:3000  →  código ESTABLE (usuarios)"
echo -e ""
echo -e "  ${YELLOW}El pipeline despliega primero en Staging, ejecuta un"
echo -e "  smoke test automático, y luego se PAUSA esperando tu"
echo -e "  aprobación manual antes de ir a Producción.${NC}"
echo ""

get_info() {
    local url=$1
    local html=$(curl -s --connect-timeout 2 "$url")
    local version=$(echo "$html" | grep -o "Versi[oó]n [0-9.]*" || echo "Página de Bienvenida")
    local color="Gris"
    if echo "$html" | grep -q "e3f2fd"; then color="Azul (Suma)"; fi
    if echo "$html" | grep -q "e8f5e9"; then color="Verde (Multiplicaci[oó]n)"; fi
    echo -e "$version | Tema: $color"
}

echo -e "${YELLOW}${BOLD}🔍 Analizando servidores...${NC}"
echo ""

echo -e "  🧪 ${CYAN}${BOLD}STAGING${NC}   (172.28.0.62:3000) — pruebas"
echo -e "     $(get_info "http://172.28.0.62:3000")"
echo ""
echo -e "  🌐 ${GREEN}${BOLD}PRODUCCIÓN${NC} (172.28.0.63:3000) — usuarios reales"
echo -e "     $(get_info "http://172.28.0.63:3000")"
echo ""

echo -e "${BLUE}════════════════════════════════════════════════════════${NC}"
STAG_V=$(get_info "http://172.28.0.62:3000")
PROD_V=$(get_info "http://172.28.0.63:3000")

if echo "$STAG_V" | grep -q "Bienvenida" || echo "$PROD_V" | grep -q "Bienvenida"; then
    echo -e "  ${YELLOW}⚠ Uno de los entornos no responde o no tiene la app.${NC}"
    echo -e "     Asegúrate de haber ejecutado 05-launch-example-app-v1.sh"
    echo -e "     y que Jenkins completó el pipeline."
elif [ "$STAG_V" == "$PROD_V" ]; then
    echo -e "  ✅ ${GREEN}${BOLD}SINCRONIZADO${NC}"
    echo -e "  Ambos entornos tienen la misma versión. El pipeline"
    echo -e "  completó todo el ciclo incluyendo la aprobación manual."
else
    echo -e "  ⚠️  ${YELLOW}${BOLD}DESFASADO${NC}"
    echo -e "  Staging tiene cambios que aún no han llegado a Producción."
    echo -e "  Causa: ${BOLD}el pipeline está pausado${NC} esperando tu aprobación."
    echo -e "  Solución: Ve a Jenkins y haz clic en ${BOLD}\"Proceed\"${NC}."
fi
echo -e "${BLUE}════════════════════════════════════════════════════════${NC}"
echo ""

echo -e "${YELLOW}${BOLD}📘 ¿Qué acabamos de ver?${NC}"
echo -e "  ${BOLD}Staging${NC} es el entorno donde Jenkins despliega automáticamente"
echo -e "  cada cambio del repositorio. Es tu \"zona de pruebas\"."
echo -e "  ${BOLD}Producción${NC} es el entorno que ven los usuarios reales."
echo -e "  Solo se actualiza cuando tú lo apruebas manualmente."
echo ""
echo -e "  Este flujo (staging → ⏸️ aprobar → producción) se llama"
echo -e "  ${BOLD}\"deployment gate\"${NC} y es una práctica recomendada en CI/CD."
echo -e "  Evita que código no verificado llegue a los usuarios."
echo ""

echo -e "${YELLOW}${BOLD}🔐 Credenciales del laboratorio:${NC}"
echo -e "    ${BOLD}Jenkins:${NC} admin / admin"
echo -e "    ${BOLD}Gitea:${NC}   gitea-admin / admin"
echo -e "    ${BOLD}Grafana:${NC} admin / admin"
echo ""

echo -e "${YELLOW}${BOLD}🐳 Contenedores activos:${NC}"
docker ps --format "table {{.Names}}\t{{.Status}}\t{{.Ports}}" 2>/dev/null | grep -E "ud06-(staging|production|gitea|jenkins)" || true
echo ""

echo -e "${YELLOW}${BOLD}🔍 PRÓXIMOS PASOS:${NC}"
echo -e "  • Si ves diferencias → Ve a Jenkins http://172.28.0.61:8080"
echo -e "    y pulsa ${BOLD}\"Proceed\"${NC} para desplegar a producción."
echo -e "  • Para ver el estado detallado → ${BOLD}bash 08-monitor-jenkins-gitea.sh${NC}"
echo -e "  • Para ver métricas → ${BOLD}Grafana:${NC} http://172.28.0.66:3000 (admin/admin)"
echo -e "  • Para ver métricas → ${BOLD}Prometheus:${NC} http://172.28.0.65:9090"
echo ""
