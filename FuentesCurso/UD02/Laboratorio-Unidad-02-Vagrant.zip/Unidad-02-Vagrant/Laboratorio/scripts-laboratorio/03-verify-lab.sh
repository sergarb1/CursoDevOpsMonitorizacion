#!/bin/bash
# 03-verify-lab.sh - Verifica el estado del laboratorio
set -e

RED='\033[0;31m'; GREEN='\033[0;32m'; BLUE='\033[0;34m'; YELLOW='\033[1;33m'; NC='\033[0m'

echo -e "\n${BLUE}╔═══════════════════════════════════════════════════════╗${NC}"
echo -e "${BLUE}║     UD02 - FASE 3: Verificación del Laboratorio     ║${NC}"
echo -e "${BLUE}╚═══════════════════════════════════════════════════════╝${NC}"

# Ir a la raíz de Vagrant (estamos en scripts-laboratorio/)
DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" >/dev/null 2>&1 && pwd )"
cd "$DIR/.."

echo -e "\n${BLUE}═══ 1. ESTADO DE LAS MÁQUINAS VIRTUALES ═══${NC}"
vagrant status | grep -E "webserver|client"

echo -e "\n${BLUE}═══ 2. ESTADO DE LA RED (BRIDGE) ═══${NC}"
if ip link show LabCEFIRE >/dev/null 2>&1; then
    echo -e "${GREEN}✓${NC} Red LabCEFIRE: ACTIVA"
    ip addr show LabCEFIRE | grep "inet "
else
    echo -e "${RED}✗${NC} Error: La red LabCEFIRE no existe."
fi

echo -e "\n${BLUE}═══ 3. VERIFICACIÓN DE SERVICIOS (HTTP) ═══${NC}"
if curl -s -L --connect-timeout 2 http://172.28.0.20 > /dev/null; then
    echo -e "${GREEN}✓${NC} Servidor Web (172.28.0.20): RESPONDE"
else
    echo -e "${RED}✗${NC} Servidor Web (172.28.0.20): SIN RESPUESTA"
fi

echo -e "\n${BLUE}═══ 4. PRUEBA DE CONECTIVIDAD (PING) ═══${NC}"
if vagrant ssh client -c "ping -c 1 172.28.0.20" > /dev/null 2>&1; then
    echo -e "${GREEN}✓${NC} Ping Cliente -> Servidor: EXITOSO"
else
    echo -e "${RED}✗${NC} Ping Cliente -> Servidor: FALLIDO"
fi

echo -e "\n${GREEN}═══════════════════════════════════════════════════════════${NC}"
echo -e "${GREEN}✅ Verificación finalizada con éxito${NC}"
echo -e "${GREEN}═══════════════════════════════════════════════════════════${NC}\n"
