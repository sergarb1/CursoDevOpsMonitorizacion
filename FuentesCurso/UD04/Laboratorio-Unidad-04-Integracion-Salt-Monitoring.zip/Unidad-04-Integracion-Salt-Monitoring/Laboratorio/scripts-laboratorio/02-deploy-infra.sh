#!/bin/bash
# 02-deploy-infra.sh - Despliega infraestructura Docker via Terraform
set -e

# Colores
RED='\033[0;31m'; GREEN='\033[0;32m'; BLUE='\033[0;34m'; YELLOW='\033[1;33m'; NC='\033[0m'

echo -e "${BLUE}╔═══════════════════════════════════════════════════════╗${NC}"
echo -e "${BLUE}║     UD04 - Despliegue de Infraestructura              ║${NC}"
echo -e "${BLUE}╚═══════════════════════════════════════════════════════╝${NC}"

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
LAB_DIR="$(dirname "$SCRIPT_DIR")"
TERRAFORM_DIR="$LAB_DIR/salt-master-lab"

echo -e "${BLUE}[INFRA]${NC} Verificando prerrequisitos..."
for cmd in docker terraform; do
    command -v "$cmd" >/dev/null 2>&1 || { echo -e "${RED}✗ Error: $cmd no encontrado.${NC}"; exit 1; }
done

cd "$TERRAFORM_DIR"

# 1. Limpieza de residuos
if docker ps -a --format '{{.Names}}' | grep -qE "vm-master|vm-minion-1|vm-minion-2|cadvisor|blackbox-exporter"; then
    echo -e "${YELLOW}[INFRA]${NC} Limpiando despliegue anterior..."
    terraform destroy -auto-approve >/dev/null 2>&1 || true
    for c in vm-master vm-minion-1 vm-minion-2 cadvisor blackbox-exporter; do
        docker rm -f "$c" >/dev/null 2>&1 || true
    done
    docker network rm devops_lab_net_ud04 >/dev/null 2>&1 || true
    echo -e "${GREEN}✓${NC} Limpieza completada."
fi

# 2. Despliegue con Terraform
echo -e "${BLUE}[INFRA]${NC} Inicializando Terraform..."
terraform init -upgrade >/dev/null 2>&1
echo -e "${GREEN}✓${NC} Terraform inicializado."

echo -e "${BLUE}[INFRA]${NC} Aplicando configuración de Terraform..."
terraform apply -auto-approve >/dev/null 2>&1
echo -e "${GREEN}✓${NC} Contenedores creados con éxito."

# 3. Verificación
echo -e "${BLUE}[INFRA]${NC} Verificando estado de los contenedores..."
sleep 3
all_ok=true
for c in vm-master vm-minion-1 vm-minion-2 cadvisor blackbox-exporter; do
    if docker inspect "$c" --format='{{.State.Running}}' 2>/dev/null | grep -q "true"; then
        echo -e "  - ${GREEN}${c}${NC}: En ejecución"
    else
        echo -e "  - ${RED}${c}${NC}: Error al arrancar"
        all_ok=false
    fi
done

if [ "$all_ok" = false ]; then
    echo -e "${RED}✗ Algunos contenedores no arrancaron correctamente.${NC}"
    exit 1
fi

echo -e "${GREEN}✓${NC} Despliegue completado."
echo -e "  Red Docker: ${BLUE}devops_lab_net_ud04${NC}"
echo ""
