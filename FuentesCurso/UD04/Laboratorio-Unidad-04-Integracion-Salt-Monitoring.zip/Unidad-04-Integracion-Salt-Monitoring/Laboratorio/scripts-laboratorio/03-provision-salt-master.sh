#!/bin/bash
# 03-provision-salt-master.sh - Instala y configura Salt Master en el nodo central (vm-master).
# En esta fase, transformamos un contenedor base de Ubuntu en un servidor de control SaltStack.
set -e

# Colores y Formato
RED='\033[0;31m'; GREEN='\033[0;32m'; BLUE='\033[0;34m'; YELLOW='\033[1;33m'; NC='\033[0m'

echo -e "${BLUE}╔═══════════════════════════════════════════════════════╗${NC}"
echo -e "${BLUE}║     UD04 - Provisión de Salt Master                   ║${NC}"
echo -e "${BLUE}║     (Infraestructura como Código con SaltStack)       ║${NC}"
echo -e "${BLUE}╚═══════════════════════════════════════════════════════╝${NC}"

echo -e "${BLUE}[STEP]${NC} 1. Verificando disponibilidad del nodo vm-master..."
docker inspect vm-master >/dev/null 2>&1 || { echo -e "${RED}✗ Error: vm-master no encontrado. Ejecuta 02-deploy-infra.sh primero.${NC}"; exit 1; }

# El Master necesita herramientas de red básicas para las pruebas de conectividad iniciales.
echo -e "${BLUE}[STEP]${NC} 2. Preparando entorno (actualización de repositorios e instalación de herramientas)..."
docker exec vm-master bash -c '
    export DEBIAN_FRONTEND=noninteractive
    apt-get update
    apt-get install -y  --no-install-recommends curl gnupg net-tools iputils-ping apt-utils 2>&1
'
echo -e "${GREEN}✓${NC} Herramientas base instaladas (curl, gnupg, net-tools, ping)."

# Llamamos al script de librería que contiene la lógica específica de instalación para Ubuntu 24.04.
echo -e "${BLUE}[STEP]${NC} 3. Instalando Salt Master (vía repositorio oficial)..."
docker exec vm-master bash -c '
    export DEBIAN_FRONTEND=noninteractive
    bash /opt/scripts/lib/04-salt-master-ubuntu.sh 2>&1
'
sleep 3 # Damos tiempo al servicio para estabilizarse

# Verificación de que el proceso principal está corriendo.
if docker exec vm-master pgrep -f '/usr/bin/salt-master' > /dev/null; then
    VERSION=$(docker exec vm-master salt-master --version 2>/dev/null | head -1)
    echo -e "${GREEN}✓${NC} Salt Master operativo y escuchando en el puerto 4505/4506."
    echo -e "  Estado: ${GREEN}Activo${NC}"
    echo -e "  Detalle: ${GREEN}${VERSION}${NC}"
else
    echo -e "${RED}✗ Error: El servicio salt-master no arrancó. Revisa los logs con 'docker logs vm-master'.${NC}"
    exit 1
fi

echo -e "\n${YELLOW}Nota Didáctica:${NC} El Master es el servidor que guarda los archivos de estado (SLS) y gestiona las llaves criptográficas de los Minions."
echo ""

# Instalación de Node Exporter: Expone métricas de hardware (CPU, RAM) en el puerto 9100.
echo -e "${GREEN}✓${NC} Instalando Node Exporter (Agente Métricas)..."
docker exec vm-master bash -c '
    export DEBIAN_FRONTEND=noninteractive
    bash /opt/scripts/lib/08-node-exporter.sh 2>&1
'