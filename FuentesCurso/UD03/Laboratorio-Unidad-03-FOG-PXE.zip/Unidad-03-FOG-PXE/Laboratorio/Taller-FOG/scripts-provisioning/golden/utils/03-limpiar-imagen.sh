#!/bin/bash
# ======================================================================
# 🧹 limpiar-imagen.sh - Limpiar Golden Image antes de capturar
# Propósito: Eliminar datos temporales y sensibles antes de la captura
# ======================================================================

echo "╔═══════════════════════════════════════════════════════════╗"
echo "║  🧹 Limpiando Golden Image antes de capturar             ║"
echo "╚═══════════════════════════════════════════════════════════╝"
echo ""

# Confirmar
read -p "⚠️  ¿Seguro que quieres limpiar la imagen? [s/N]: " CONFIRM
if [[ ! $CONFIRM =~ ^[Ss]$ ]]; then
    echo "❌ Operación cancelada."
    exit 0
fi

echo "🔄 Iniciando limpieza..."
echo ""

# 1. Limpiar paquetes APT
echo "📦 Limpiando paquetes APT..."
apt-get clean
apt-get autoremove -y
rm -rf /var/cache/apt/archives/*.deb
echo "   ✅ APT limpio"
echo ""

# 2. Limpiar logs
echo "📋 Limpiando logs del sistema..."
rm -rf /var/log/*.gz
rm -rf /var/log/*.[0-9]
rm -rf /var/log/journal/*
truncate -s 0 /var/log/*.log 2>/dev/null || true
echo "   ✅ Logs limpiados"
echo ""

# 3. Limpiar temporales
echo "🗑️  Limpiando archivos temporales..."
rm -rf /tmp/*
rm -rf /var/tmp/*
rm -rf /var/cache/*
echo "   ✅ Temporales limpiados"
echo ""

# 4. Limpiar caché de usuarios
echo "👤 Limpiando caché de usuarios..."
for user in /home/*; do
    if [ -d "$user" ]; then
        rm -rf "$user/.cache/"* 2>/dev/null || true
        rm -rf "$user/.local/share/Trash/"* 2>/dev/null || true
        rm -rf "$user/.bash_history" 2>/dev/null || true
        rm -rf "$user/.viminfo" 2>/dev/null || true
    fi
done
echo "   ✅ Caché de usuarios limpiado"
echo ""

# 5. Eliminar claves SSH (IMPORTANTE para clonación)
echo "🔑 Eliminando claves SSH del host..."
rm -f /etc/ssh/ssh_host_*
rm -f /root/.ssh/known_hosts
rm -f /home/*/.ssh/known_hosts 2>/dev/null || true
echo "   ✅ Claves SSH eliminadas (se regenerarán al arrancar)"
echo ""

# 6. Limpiar historial de comandos
echo "📜 Limpiando historial de comandos..."
history -c
cat /dev/null > ~/.bash_history
for user in /home/*; do
    if [ -d "$user" ]; then
        cat /dev/null > "$user/.bash_history" 2>/dev/null || true
    fi
done
echo "   ✅ Historial limpio"
echo ""

# 7. Limpiar máquina Vagrant (si existe)
echo "🏠 Limpiando configuración Vagrant..."
rm -rf /home/*/.vagrant.d 2>/dev/null || true
rm -f /etc/machine-id
dbus-uuidgen --ensure=/etc/machine-id 2>/dev/null || true
echo "   ✅ Configuración Vagrant limpiada"
echo ""

# 8. Reiniciar ZRAM
echo "⚡ Reiniciando ZRAM..."
systemctl restart zramswap.service 2>/dev/null || true
echo "   ✅ ZRAM reiniciado"
echo ""

# 9. Mostrar resumen
echo "╔═══════════════════════════════════════════════════════════╗"
echo "║  ✅ ¡Limpieza completada!                                 ║"
echo "╠═══════════════════════════════════════════════════════════╣"
echo "║  📋 SIGUIENTES PASOS:                                     ║"
echo "║                                                           ║"
echo "║  1. Apaga la Golden-VM:                                   ║"
echo "║     sudo poweroff                                         ║"
echo "║                                                           ║"
echo "║  2. Desde el panel de FOG:                                ║"
echo "║     • Registra la Golden-VM (MAC de eth1)                ║"
echo "║     • Crea tarea de CAPTURA                              ║"
echo "║                                                           ║"
echo "║  3. Enciende la Golden-VM:                                ║"
echo "║     Arrancará por PXE y comenzará la captura             ║"
echo "║                                                           ║"
echo "║  ⚠️  IMPORTANTE:                                          ║"
echo "║  La imagen capturada NO tendrá:                           ║"
echo "║    • Claves SSH (se generarán nuevas)                     ║"
echo "║    • Historial de comandos                                ║"
echo "║    • Archivos temporales                                  ║"
echo "║    • Machine-ID (se generará nuevo)                       ║"
echo "╚═══════════════════════════════════════════════════════════╝"
