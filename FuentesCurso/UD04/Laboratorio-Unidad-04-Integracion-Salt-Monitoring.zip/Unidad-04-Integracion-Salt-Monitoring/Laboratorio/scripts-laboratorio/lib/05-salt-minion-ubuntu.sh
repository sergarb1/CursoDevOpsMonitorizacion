#!/bin/bash
# 05-salt-minion-ubuntu.sh - Instalación de Salt Minion para Ubuntu 24.04
# Este script configura el agente 'Minion' para que se conecte al 'Master' centralizado.

set -euo pipefail

echo "--- [SALT-MINION-UBUNTU] Instalando Salt Minion (Ubuntu 24.04) ---"

# Instalación de requisitos básicos para el contenedor
export DEBIAN_FRONTEND=noninteractive
apt-get update  &>/dev/null
apt-get install -y  --no-install-recommends curl gnupg net-tools ca-certificates 2>&1

# Limpieza de procesos previos para asegurar un arranque limpio
pkill -9 -f '/usr/bin/salt-minion' 2>/dev/null || true
sleep 1

# Registro del repositorio oficial de Salt Project (Broadcom)
mkdir -m 755 -p /etc/apt/keyrings
curl -fsSL https://packages.broadcom.com/artifactory/api/security/keypair/SaltProjectKey/public | gpg --dearmor | tee /etc/apt/keyrings/salt-archive-keyring.pgp > /dev/null
curl -fsSL https://github.com/saltstack/salt-install-guide/releases/latest/download/salt.sources | tee /etc/apt/sources.list.d/salt.sources

apt-get update 

# Instalación del paquete salt-minion
apt-get install -y  salt-minion

# Configuración del Master: Aquí le decimos al Minion a qué IP debe conectarse.
# La IP se ha actualizado de 172.28.0.10 a 172.28.0.40.
echo "master: ${SALT_MASTER:-172.28.0.40}" > /etc/salt/minion

# Limpieza de llaves PKI previas: Importante para evitar conflictos si se reinstala el minion.
rm -rf /etc/salt/pki/minion/minion_master.pub

# Arranque del servicio en segundo plano (modo demonio '-d')
nohup /usr/bin/salt-minion -d > /var/log/salt-minion.log 2>&1 &

# Verificación de que el proceso ha arrancado correctamente
echo "Esperando a que el proceso Salt Minion se estabilice..."
for i in $(seq 1 15); do
    pgrep -f '/usr/bin/salt-minion' > /dev/null && break
    sleep 1
done

if pgrep -f '/usr/bin/salt-minion' > /dev/null; then
    echo "✅ Salt Minion (Ubuntu) configurado y conectado a ${SALT_MASTER:-172.28.0.40}"
else
    echo "❌ ERROR: El Minion no pudo arrancar. Revisando log:"; cat /var/log/salt-minion.log 2>/dev/null | tail -10; exit 1
fi
