#!/bin/bash
# 98-clean-infra.sh - Limpieza de infraestructura Vagrant
set -e

RED='\033[0;31m'; GREEN='\033[0;32m'; YELLOW='\033[1;33m'; BLUE='\033[0;34m'; NC='\033[0m'

echo -e "${RED}╔═══════════════════════════════════════════════════════╗${NC}"
echo -e "${RED}║     ⚠️  UD02 - DESTRUCCIÓN DE INFRAESTRUCTURA      ║${NC}"
echo -e "${RED}╚═══════════════════════════════════════════════════════╝${NC}"

DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" >/dev/null 2>&1 && pwd )"
cd "$DIR/.."

echo -e "${RED}[VAGRANT]${NC} Destruyendo máquinas virtuales..."
vagrant destroy -f > /dev/null 2>&1

echo -e "${RED}[VAGRANT]${NC} Limpiando archivos de estado (.vagrant)..."
rm -rf .vagrant/

echo -e "${GREEN}✓${NC} Entorno de infraestructura limpio."
echo -e "${YELLOW}NOTA: La red 'LabCEFIRE' sigue activa. Usa 99-clean-network.sh para borrarla.${NC}\n"
